import { test } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { createWebhookIngestApp } from "../src/webhookIngestApp.mjs";
import { MemoryCallbackStore } from "../src/lib/storage/memoryCallbackStore.mjs";
import { FakeSigningSecretSource, FailingStore, startEphemeral } from "./fakes.mjs";

const SECRET = "quarterly-rotated-signing-secret";
const silentLogger = { warn() {}, error() {}, info() {} };

function sign(secret, body) {
  return createHmac("sha256", secret).update(body).digest("hex");
}

async function post(url, body, signature) {
  const headers = { "content-type": "application/json" };
  if (signature !== undefined) headers["x-provider-signature"] = signature;
  return fetch(url, { method: "POST", headers, body });
}

function buildApp(store = new MemoryCallbackStore(), secretSource = new FakeSigningSecretSource(SECRET)) {
  const app = createWebhookIngestApp({ signingSecretSource: secretSource, store, logger: silentLogger });
  return { app, store, secretSource };
}

test("GET /healthz needs no credential and returns 200", async () => {
  const { app } = buildApp();
  const { server, url } = startEphemeral(app);
  try {
    const res = await fetch(url("/healthz"));
    assert.equal(res.status, 200);
  } finally {
    server.close();
  }
});

test("a genuine callback, correctly signed, is accepted and recorded", async () => {
  const { app, store } = buildApp();
  const { server, url } = startEphemeral(app);
  try {
    const body = JSON.stringify({ event_id: "evt_genuine_1", amount: 4200 });
    const res = await post(url("/webhooks/payment-provider"), body, sign(SECRET, body));
    assert.equal(res.status, 201);
    const json = await res.json();
    assert.equal(json.status, "recorded");

    const stored = await store.getByEventId("evt_genuine_1");
    assert.ok(stored, "the record must actually be in the store");
    assert.equal(Buffer.from(stored.rawBodyBase64, "base64").toString("utf8"), body);
  } finally {
    server.close();
  }
});

test("a forged callback (wrong secret) is rejected with 401 and never recorded", async () => {
  const { app, store } = buildApp();
  const { server, url } = startEphemeral(app);
  try {
    const body = JSON.stringify({ event_id: "evt_forged_1", amount: 999999 });
    const forgedSignature = sign("attackers-guessed-secret", body);
    const res = await post(url("/webhooks/payment-provider"), body, forgedSignature);
    assert.equal(res.status, 401);

    assert.equal(await store.getByEventId("evt_forged_1"), null);
  } finally {
    server.close();
  }
});

test("a callback with no signature header at all is rejected with 401", async () => {
  const { app } = buildApp();
  const { server, url } = startEphemeral(app);
  try {
    const body = JSON.stringify({ event_id: "evt_no_sig", amount: 1 });
    const res = await post(url("/webhooks/payment-provider"), body, undefined);
    assert.equal(res.status, 401);
  } finally {
    server.close();
  }
});

test("a repeated delivery of the same event id does not overwrite the first record", async () => {
  const { app, store } = buildApp();
  const { server, url } = startEphemeral(app);
  try {
    const originalBody = JSON.stringify({ event_id: "evt_dup_1", amount: 100, note: "original" });
    const firstRes = await post(url("/webhooks/payment-provider"), originalBody, sign(SECRET, originalBody));
    assert.equal(firstRes.status, 201);
    assert.equal((await firstRes.json()).status, "recorded");

    // A second, genuinely signed delivery for the SAME event id but DIFFERENT contents — exactly
    // what an attacker replaying a captured request, or a confused retry with a rebuilt payload,
    // would produce. The stored record must still be the first one.
    const replayBody = JSON.stringify({ event_id: "evt_dup_1", amount: 999999999, note: "replay" });
    const secondRes = await post(url("/webhooks/payment-provider"), replayBody, sign(SECRET, replayBody));
    assert.equal(secondRes.status, 200);
    assert.equal((await secondRes.json()).status, "already_recorded");

    const stored = await store.getByEventId("evt_dup_1");
    const storedBody = Buffer.from(stored.rawBodyBase64, "base64").toString("utf8");
    assert.equal(storedBody, originalBody, "the stored record must be exactly the first one received");
    assert.notEqual(storedBody, replayBody);
  } finally {
    server.close();
  }
});

test("a genuinely signed but malformed JSON body is a bad request, not a fault", async () => {
  const { app } = buildApp();
  const { server, url } = startEphemeral(app);
  try {
    const body = "{ this is not valid json";
    const res = await post(url("/webhooks/payment-provider"), body, sign(SECRET, body));
    assert.equal(res.status, 400);
  } finally {
    server.close();
  }
});

test("a genuinely signed body with no event_id is a bad request, not a fault", async () => {
  const { app } = buildApp();
  const { server, url } = startEphemeral(app);
  try {
    const body = JSON.stringify({ amount: 100 });
    const res = await post(url("/webhooks/payment-provider"), body, sign(SECRET, body));
    assert.equal(res.status, 400);
  } finally {
    server.close();
  }
});

test("an infrastructure failure while storing a genuine callback is reported as 500, not 4xx", async () => {
  const { app } = buildApp(new FailingStore());
  const { server, url } = startEphemeral(app);
  try {
    const body = JSON.stringify({ event_id: "evt_fault_1", amount: 1 });
    const res = await post(url("/webhooks/payment-provider"), body, sign(SECRET, body));
    assert.equal(res.status, 500);
    const json = await res.json();
    assert.doesNotMatch(json.error, /simulated DynamoDB outage/, "internal fault detail must not leak to the caller");
  } finally {
    server.close();
  }
});

test("a callback signed with the previous (recently rotated-out) secret is still accepted", async () => {
  const secretSource = new FakeSigningSecretSource("new-secret-after-rotation", "old-secret-before-rotation");
  const { app, store } = buildApp(new MemoryCallbackStore(), secretSource);
  const { server, url } = startEphemeral(app);
  try {
    const body = JSON.stringify({ event_id: "evt_rotation_grace", amount: 1 });
    const res = await post(url("/webhooks/payment-provider"), body, sign("old-secret-before-rotation", body));
    assert.equal(res.status, 201);
    assert.ok(await store.getByEventId("evt_rotation_grace"));
  } finally {
    server.close();
  }
});
