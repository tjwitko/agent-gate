// The support-facing app: looks up a past callback by the provider's event id. Its IAM role
// grants GetItem and Query only — it cannot write, so even a fully compromised copy of this
// service cannot alter or remove a record, only read one. Every route requires the support team's
// API key; there is no route here the provider is ever meant to call.

import express from "express";
import { verifyCredential } from "./lib/signature.mjs";
import { NotFoundError, UnauthorizedError } from "./lib/errors.mjs";
import { asyncHandler } from "./lib/httpHelpers.mjs";
import { errorMiddleware, notFoundMiddleware, consoleLogger } from "./lib/errorMiddleware.mjs";

const API_KEY_HEADER = "x-support-api-key";

/**
 * @param {{ supportApiKeySource: import("./lib/singleSecretSource.mjs").SingleSecretSource,
 *           store: { getByEventId(eventId): Promise<object|null> },
 *           logger?: typeof consoleLogger }} deps
 */
export function createSupportApiApp(deps) {
  const logger = deps.logger ?? consoleLogger;
  const app = express();

  app.get("/healthz", (req, res) => res.status(200).json({ status: "ok" }));

  app.get(
    "/support/callbacks/:eventId",
    asyncHandler(async (req, res) => {
      const providedKey = req.get(API_KEY_HEADER);

      // Authentication happens here, in the route itself: check against the cached key, and if
      // it does not match, refresh once (we may simply not have noticed our own key change yet)
      // before rejecting.
      let expectedKey = providedKey ? await deps.supportApiKeySource.getValue() : null;
      let keyVerified = Boolean(providedKey) && verifyCredential(expectedKey, providedKey);
      if (!keyVerified && providedKey) {
        deps.supportApiKeySource.refresh();
        expectedKey = await deps.supportApiKeySource.getValue();
        keyVerified = verifyCredential(expectedKey, providedKey);
      }
      if (!keyVerified) {
        throw new UnauthorizedError("missing or invalid support API key");
      }

      const record = await deps.store.getByEventId(req.params.eventId);
      if (!record) {
        throw new NotFoundError(`no callback recorded for event id ${req.params.eventId}`);
      }

      logger.info({ eventId: req.params.eventId }, "support lookup");
      res.status(200).json(record);
    })
  );

  app.use(notFoundMiddleware);
  app.use(errorMiddleware(logger));
  return app;
}
