import { test } from "node:test";
import assert from "node:assert/strict";
import { TtlCache } from "../src/lib/ttlCache.mjs";

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

test("a value is served from cache without re-fetching within the TTL", async () => {
  const cache = new TtlCache(10_000);
  let calls = 0;
  const fetchFn = async () => {
    calls++;
    return "secret-value";
  };

  assert.equal(await cache.get("k", fetchFn), "secret-value");
  assert.equal(await cache.get("k", fetchFn), "secret-value");
  assert.equal(calls, 1);
});

test("a stale entry (past its TTL) is re-fetched", async () => {
  const cache = new TtlCache(5);
  let calls = 0;
  const fetchFn = async () => {
    calls++;
    return `value-${calls}`;
  };

  assert.equal(await cache.get("k", fetchFn), "value-1");
  await delay(20);
  assert.equal(await cache.get("k", fetchFn), "value-2");
  assert.equal(calls, 2);
});

test("invalidate forces a re-fetch even well within the TTL", async () => {
  const cache = new TtlCache(60_000);
  let calls = 0;
  const fetchFn = async () => {
    calls++;
    return `value-${calls}`;
  };

  assert.equal(await cache.get("k", fetchFn), "value-1");
  cache.invalidate("k");
  assert.equal(await cache.get("k", fetchFn), "value-2");
  assert.equal(calls, 2);
});
