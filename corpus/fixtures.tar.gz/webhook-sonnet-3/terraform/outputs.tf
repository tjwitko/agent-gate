output "eks_cluster_name" {
  value = aws_eks_cluster.this.name
}

output "eks_cluster_endpoint" {
  value = aws_eks_cluster.this.endpoint
}

output "ecr_repository_url" {
  value = aws_ecr_repository.webhook_receiver.repository_url
}

output "dynamodb_table_name" {
  value = aws_dynamodb_table.callbacks.name
}

output "signing_secret_arn" {
  value = aws_secretsmanager_secret.signing_secret.arn
}

output "support_token_secret_arn" {
  value = aws_secretsmanager_secret.support_token.arn
}

output "webhook_app_role_arn" {
  value = aws_iam_role.webhook_app.arn
}
