# Security Controls

## Immutability

Webhook records are made immutable through multiple layers of protection:

### 1. Database-Level Triggers (Primary Control)
PostgreSQL triggers prevent any UPDATE or DELETE operations on webhook records:
- `prevent_webhook_update`: Raises exception on UPDATE attempt
- `prevent_webhook_delete`: Raises exception on DELETE attempt
- Enforced in `src/db/database.ts` during schema initialization

### 2. Database Constraints
- Primary key (`id`) ensures record uniqueness
- UNIQUE constraint on (event_id, provider_id) prevents duplicates
- All fields are NOT NULL to prevent null-based tampering

### 3. Application Layer
- No UPDATE or DELETE endpoints exposed via REST API
- Webhook storage is append-only
- Idempotency on insert prevents duplicate processing

### 4. Audit Trail
- `webhook_audit_log` table records all operations
- Tracks webhook creation timestamps
- Maintains compliance trail for 7-year retention

## Authentication & Authorization

### Provider Authentication
- Providers must authenticate with X-Provider-API-Key header
- API keys are hashed with SHA-256 before storage
- Validation uses crypto.timingSafeEqual to prevent timing attacks
- Keys stored in `provider_api_keys` table
- Supports key revocation via soft-delete

### Support Team Authentication  
- Support team must authenticate with X-API-Key header
- API keys are hashed with SHA-256 before storage
- Validation uses crypto.timingSafeEqual to prevent timing attacks
- Keys stored in `support_team_api_keys` table
- Supports key revocation via soft-delete

### Timing-Safe Comparison
All credential comparisons use `crypto.timingSafeEqual()` to prevent timing-attack leaks:
- Compares all active keys rather than short-circuiting on first match
- Constant-time algorithm prevents attackers from recovering credentials through response timing
- Implements in both `validateSupportTeamApiKey()` and `validateProviderApiKey()` methods

## Signature Verification

### HMAC-SHA256 Signature Verification
- Webhook callbacks must be signed by provider with HMAC-SHA256
- Signature provided in X-Signature header
- Payload is hashed and compared using constant-time comparison
- Prevents forgery and tampering of webhook content

### Secret Rotation
- Quarterly secret rotation supported via `provider_secrets` table
- Multiple secrets can be active simultaneously during rotation transition
- Both old and new secrets accepted during 24-hour transition period
- `is_active` flag controls which secrets are used

## Data Protection

### Encryption at Rest
- RDS encryption enabled with AWS KMS
- All data encrypted in storage
- Separate KMS key for database encryption

### Encryption in Transit
- TLS required for all communication
- ALB terminates HTTPS (443) traffic
- Application communicates over encrypted channels

### Secure Configuration
- Database credentials passed via environment variables
- Secrets stored in Kubernetes Secrets
- No credentials in code or configuration files

## Access Control

### Principle of Least Privilege
- Provider: Can only POST to /webhook endpoint (verify signature + store)
- Support Team: Can only GET webhooks by event ID (read-only)
- Health check: No authentication required (load balancer probe)

### Network Isolation
- EKS nodes isolated in private subnets
- RDS accessible only from EKS security group
- ALB in public subnet, but traffic encrypted

## Compliance

### 7-Year Retention
- RDS automatic backups retained for 35 days
- Snapshots retained per compliance policy
- Immutable records guarantee no accidental deletion

### Audit Trail
- webhook_audit_log table records creation events
- Database triggers log all modification attempts
- CloudWatch logs capture application-level events

### Error Handling
- Errors distinguished between client errors (4xx) and server errors (5xx)
- Bad requests (malformed JSON, missing headers) return 400/401
- Internal errors return 500
- No information leakage in error messages

## Threat Model

### Threats Addressed
1. **Forgery**: HMAC-SHA256 signature verification prevents fake webhooks
2. **Tampering**: Signature verification + immutability prevents content changes
3. **Replay**: Idempotency ensures duplicate events don't override existing records
4. **Timing Attacks**: Constant-time comparison for credentials and signatures
5. **Unauthorized Access**: Authentication on all endpoints
6. **Data Breach**: Encryption at rest and in transit
7. **Accidental Deletion**: Database triggers prevent all webhook deletions

### Out of Scope
- Provider compromise (signature would be invalid)
- Denial of service (mitigated by rate limiting, not shown here)
- Physical/infrastructure attacks (AWS responsibility)
