import { GetCommand, PutCommand } from '@aws-sdk/lib-dynamodb';

export const DUPLICATE = 'duplicate';
export const STORED = 'stored';

/**
 * The callback store. Every write goes through a ConditionExpression of
 * attribute_not_exists(event_id): PutItem otherwise REPLACES an item whose key already exists, so
 * without this condition anyone who can write can erase a previously-recorded callback simply by
 * resending its event id. There is no update or delete path anywhere in this module — the running
 * service has no operation that can change or remove a record once it is written. That guarantee
 * is reinforced at the IAM layer: the role this service runs as is granted only PutItem and
 * GetItem, never UpdateItem, DeleteItem or BatchWriteItem.
 */
export function createStore(docClient, tableName) {
  async function recordCallback({ eventId, receivedAt, headers, rawBody }) {
    const item = {
      event_id: eventId,
      received_at: receivedAt,
      headers,
      // Stored exactly as received, byte for byte, so a dispute raised years later can be
      // settled by what was actually delivered rather than by a re-serialized interpretation of it.
      raw_body: rawBody.toString('utf8'),
    };

    try {
      await docClient.send(
        new PutCommand({
          TableName: tableName,
          Item: item,
          ConditionExpression: 'attribute_not_exists(event_id)',
        })
      );
      return STORED;
    } catch (err) {
      if (err.name === 'ConditionalCheckFailedException') {
        // Already recorded. Not an error: a payment provider retries a delivery it did not get a
        // clean response for, and the record from the first delivery is the one that stays.
        return DUPLICATE;
      }
      throw err;
    }
  }

  async function getCallback(eventId) {
    const result = await docClient.send(
      new GetCommand({
        TableName: tableName,
        Key: { event_id: eventId },
      })
    );
    return result.Item ?? null;
  }

  return { recordCallback, getCallback };
}
