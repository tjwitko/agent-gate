aws_region     = "us-east-1"
environment    = "testing"

# Supply db_master_username and db_master_password via environment variables:
# export TF_VAR_db_master_username=admin
# export TF_VAR_db_master_password=YourSecurePassword
