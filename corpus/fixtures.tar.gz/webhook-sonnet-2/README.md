# webhook-receiver

Receives event notification callbacks from our payment provider, verifies each one genuinely
came from the provider, and keeps an unalterable record of every callback received so a
chargeback dispute raised months or years later can be settled against what was actually
received at the time.

## How it works

- `POST /webhooks/payment-provider` -- the provider's callback endpoint. The raw request body
  must be signed with the header `X-Webhook-Signature: sha256=<hex hmac-sha256 of the raw body>`.
  A callback with a missing or invalid signature is rejected with `401` and never recorded. A
  genuine callback is recorded with a conditional write keyed on the payload's `id` field: the
  first delivery of a given event id returns `201`, a redelivery of the same event id returns
  `200` with `duplicate: true` and never overwrites what was already stored.
- `GET /callbacks/:eventId` -- lets the support team look up a past callback by the provider's
  event id. Requires `Authorization: Bearer <support token>`; returns `401`/`403` otherwise. Not
  exposed on the public Ingress (see k8s/ingress.yaml) -- reachable only from inside the cluster's
  network, as a second layer behind the token check.
- `GET /healthz` -- unauthenticated liveness/readiness target for the load balancer and
  Kubernetes probes.

Assumptions made where the task didn't specify a wire format: the provider signs with
`sha256=<hex>` over the raw body (the same scheme Stripe and GitHub use), and each callback's
JSON payload carries the provider's event id in a top-level `id` field. Adjust
`src/lib/signature.js` and the `eventIdField` passed into `createWebhookService` in
`src/server.js` if the real provider's contract differs.

## Why it's immutable

Two independent layers, so a bug in either one doesn't undo the guarantee:

1. **Application code** (`src/lib/dynamoEventStore.js`) writes with
   `ConditionExpression: attribute_not_exists(event_id)`. A second write for an event id already
   on file is rejected by DynamoDB itself and reported back as a duplicate, not applied.
2. **IAM** (`terraform/iam.tf`) grants the running service `dynamodb:PutItem`, `GetItem` and
   `Query` only -- no `UpdateItem`, `DeleteItem` or `BatchWriteItem`. Even a compromised or buggy
   deployment cannot obtain credentials that would let it alter or remove a recorded callback.

Retention (`terraform/dynamodb.tf`) has no TTL attribute configured, so nothing here expires a
record early -- the seven-year requirement is met by never scheduling a deletion, backstopped by
an AWS Backup plan (`terraform/backup.tf`) that keeps recovery points for at least seven years
even against a mistaken `terraform destroy` of the table.

## Secret rotation

The provider rotates its signing secret quarterly. Rather than build a parallel
current/previous scheme, this uses AWS Secrets Manager's own version staging: rotating the
secret moves `AWSCURRENT` to the new value and leaves the outgoing value reachable as
`AWSPREVIOUS`. `src/lib/secretStore.js` fetches both stages (cached with an explicit TTL, not
cached forever) and `src/lib/signature.js` accepts a signature from either, so a callback signed
in the moments just before a rotation completes still verifies.

## Errors vs. faults

`src/lib/errors.js` defines `ClientError` for anything the caller did wrong (bad signature,
malformed JSON, missing event id, bad/missing support credential) -- these map to `4xx` and are
logged as `kind: "client_error"`. Anything else thrown is a fault in this service, maps to `500`,
is logged as `kind: "fault"`, and never leaks its internal message to the caller. See
`src/app.js`'s central error handler and the corresponding tests in `test/webhook.test.js`.

## Running it

```sh
npm install
npm test              # node's built-in test runner; no other tooling needed
npm start              # requires AWS_REGION, DYNAMODB_TABLE_NAME, SIGNING_SECRET_ID,
                        # SUPPORT_TOKEN_SECRET_ID in the environment (see src/config.js)
```

The test suite (`test/*.test.js`) never imports the AWS SDK -- `src/lib/webhookService.js`,
`src/lib/supportAuth.js`, `src/lib/signature.js` and `src/app.js` take their dependencies
(secret lookup, storage) as plain injected functions/objects, so `npm test` runs standalone. The
AWS-backed adapters (`src/lib/dynamoEventStore.js`, `src/lib/secretStore.js`) and the composition
root (`src/server.js`) are only exercised by the real deployment.

## Deploying

1. `cd terraform && terraform init && terraform apply` -- needs `eks_oidc_provider_url` and
   `eks_oidc_thumbprint` for the target EKS cluster (see `terraform/variables.tf`); everything
   else has a sane default. This provisions the DynamoDB table, the two Secrets Manager secret
   containers (values are set out-of-band -- see the comment in `terraform/secrets.tf`), the
   IRSA role, the AWS Backup plan, and the ECR repository. Nothing here creates the EKS cluster
   itself; it's assumed to already exist.
2. Set the initial secret values:
   ```sh
   aws secretsmanager put-secret-value \
     --secret-id "$(terraform output -raw webhook_signing_secret_id)" \
     --secret-string "<the provider's signing secret>"
   aws secretsmanager put-secret-value \
     --secret-id "$(terraform output -raw support_api_token_secret_id)" \
     --secret-string "$(openssl rand -hex 32)"
   ```
3. Build and push the image: `docker build -t <ecr_repository_url>:<version> . && docker push
   <ecr_repository_url>:<version>`. The repository is tag-immutable, so each release needs a new
   tag, never a reused `:latest`.
4. Fill in `k8s/serviceaccount.yaml`'s `eks.amazonaws.com/role-arn` with
   `terraform output -raw app_iam_role_arn`, and `k8s/deployment.yaml`'s `image` with the
   repository URL and the tag just pushed.
5. `kubectl apply -f k8s/`.

## Network model

The webhook path and the health check are the only routes on the public Ingress
(`k8s/ingress.yaml`). The support-read path is deliberately absent from it -- support tooling
reaches the Service from inside the cluster's network (VPN, a private ALB, or
`kubectl port-forward`), so an attacker without network access to the cluster can't even attempt
the endpoint, on top of the bearer-token check the application itself enforces.
