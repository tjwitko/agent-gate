import { v4 as uuidv4 } from 'uuid';
import { Database } from '../db/database';

export interface WebhookData {
  eventId: string;
  providerId: string;
  payload: string;
  signature: string;
  receivedAt: Date;
}

export interface StoredWebhook {
  id: string;
  eventId: string;
  providerId: string;
  payload: string;
  signature: string;
  receivedAt: Date;
}

export class WebhookService {
  constructor(private db: Database) {}

  async storeWebhook(data: WebhookData): Promise<string> {
    const id = uuidv4();

    // Check if we already have this event to ensure idempotency
    const existing = await this.db.getWebhookByEventId(data.eventId, data.providerId);
    if (existing) {
      // Event already recorded, return the existing ID
      return existing.id;
    }

    // Store the webhook - this is immutable once written
    await this.db.storeWebhook({
      id,
      ...data
    });

    return id;
  }

  async getWebhookByEventId(eventId: string): Promise<StoredWebhook | null> {
    return this.db.getWebhookByEventId(eventId);
  }
}
