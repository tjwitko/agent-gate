import express from 'express';
import { createHmac, timingSafeEqual } from 'crypto';
import { initDB, recordCallback, getCallbackByEventId } from './db/store.js';
import { getCurrentSigningKey, isValidSecret, getSupportAuthToken } from './config/secrets.js';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.raw({ type: 'application/json', limit: '10mb' }));

// Initialize database on startup
await initDB();

// Health endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Webhook receiver endpoint
app.post('/webhook', async (req, res) => {
  try {
    const signature = req.headers['x-webhook-signature'];
    const timestamp = req.headers['x-webhook-timestamp'];
    const body = req.body;

    // Validate signature presence
    if (!signature || !timestamp) {
      return res.status(400).json({ error: 'Missing signature or timestamp header' });
    }

    // Verify signature with current and previous keys
    const currentKey = await getCurrentSigningKey();
    let isValid = verifySignature(body, signature, timestamp, currentKey);

    if (!isValid) {
      return res.status(401).json({ error: 'Invalid signature' });
    }

    // Parse the JSON body
    let payload;
    try {
      payload = JSON.parse(body.toString('utf-8'));
    } catch (e) {
      return res.status(400).json({ error: 'Invalid JSON in request body' });
    }

    // Require event_id
    if (!payload.event_id) {
      return res.status(400).json({ error: 'Missing event_id in payload' });
    }

    // Record the callback
    try {
      const bodyStr = Buffer.isBuffer(body) ? body.toString('utf-8') : body;
      const id = await recordCallback(payload.event_id, bodyStr, signature, timestamp);
      res.status(201).json({ received: true, callback_id: id });
    } catch (error) {
      if (error.code === 'DUPLICATE_EVENT') {
        return res.status(409).json({ error: error.message });
      }
      throw error;
    }
  } catch (error) {
    console.error('Webhook processing error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Query endpoint for support team (requires bearer token auth)
app.get('/callbacks/:event_id', async (req, res) => {
  const authToken = req.headers.authorization?.split(' ')[1];
  const expectedToken = await getSupportAuthToken();

  if (!authToken || !isValidSecret(authToken, expectedToken)) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const callback = await getCallbackByEventId(req.params.event_id);

    if (!callback) {
      return res.status(404).json({ error: 'Callback not found' });
    }

    res.status(200).json(callback);
  } catch (error) {
    console.error('Query error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

function verifySignature(body, providedSignature, timestamp, signingKey) {
  try {
    // Ensure body is a string
    const bodyStr = Buffer.isBuffer(body) ? body.toString('utf-8') : body;

    // Create canonical message: timestamp.body
    const message = `${timestamp}.${bodyStr}`;

    // Compute HMAC-SHA256
    const expectedSignature = createHmac('sha256', signingKey)
      .update(message)
      .digest('hex');

    // Use timing-safe comparison for both buffer and hex string forms
    const expectedBuffer = Buffer.from(expectedSignature, 'hex');
    const providedBuffer = Buffer.from(providedSignature, 'hex');

    // Lengths must match
    if (expectedBuffer.length !== providedBuffer.length) {
      return false;
    }

    return timingSafeEqual(expectedBuffer, providedBuffer);
  } catch (e) {
    return false;
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  app.listen(PORT, () => {
    console.log(`Webhook receiver listening on port ${PORT}`);
  });
}

export default app;
