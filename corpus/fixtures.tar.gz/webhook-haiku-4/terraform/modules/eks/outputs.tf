output "cluster_name" {
  description = "EKS cluster name"
  value       = aws_eks_cluster.webhook_receiver.name
}

output "cluster_endpoint" {
  description = "EKS cluster API endpoint"
  value       = aws_eks_cluster.webhook_receiver.endpoint
}

output "cluster_certificate_authority_data" {
  description = "Base64 encoded certificate data required to communicate with the cluster"
  value       = aws_eks_cluster.webhook_receiver.certificate_authority[0].data
  sensitive   = true
}

output "cluster_arn" {
  description = "EKS cluster ARN"
  value       = aws_eks_cluster.webhook_receiver.arn
}

output "node_group_id" {
  description = "EKS node group ID"
  value       = aws_eks_node_group.webhook_receiver.id
}

output "cluster_iam_role_arn" {
  description = "EKS cluster IAM role ARN"
  value       = aws_iam_role.cluster.arn
}
