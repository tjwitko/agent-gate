import { Callback } from "./types.js";

export interface CallbackStore {
  // Immutability enforcement: save() MUST use conditional writes
  // For DynamoDB: use PutItem with ConditionExpression: attribute_not_exists(eventId)
  // This ensures records cannot be overwritten once created, enforcing write-once semantics
  save(callback: Callback): Promise<void>;
  getByEventId(eventId: string): Promise<Callback | null>;
  exists(eventId: string): Promise<boolean>;
}

export class InMemoryStore implements CallbackStore {
  private callbacks: Map<string, Callback> = new Map();

  async save(callback: Callback): Promise<void> {
    // Enforce write-once semantics: prevents record overwrites
    // DynamoDB implementation MUST use: PutItem with ConditionExpression: attribute_not_exists(eventId)
    if (this.callbacks.has(callback.eventId)) {
      throw new Error(`Callback with event id ${callback.eventId} already exists`);
    }
    this.callbacks.set(callback.eventId, callback);
  }

  async getByEventId(eventId: string): Promise<Callback | null> {
    return this.callbacks.get(eventId) || null;
  }

  async exists(eventId: string): Promise<boolean> {
    return this.callbacks.has(eventId);
  }

  async clear(): Promise<void> {
    this.callbacks.clear();
  }
}

/*
 * DynamoDB implementation template (production use):
 *
 * export class DynamoDBStore implements CallbackStore {
 *   private dynamodb = new DynamoDBClient({});
 *   private tableName = process.env.DYNAMODB_TABLE || "webhook-callbacks";
 *
 *   async save(callback: Callback): Promise<void> {
 *     // IMMUTABLE: use ConditionExpression to enforce write-once semantics
 *     await dynamodb.send(
 *       new PutItemCommand({
 *         TableName: this.tableName,
 *         Item: {
 *           eventId: { S: callback.eventId },
 *           id: { S: callback.id },
 *           receivedAt: { S: callback.receivedAt.toISOString() },
 *           body: { S: JSON.stringify(callback.body) },
 *         },
 *         ConditionExpression: "attribute_not_exists(eventId)",
 *       })
 *     );
 *   }
 *
 *   async getByEventId(eventId: string): Promise<Callback | null> {
 *     const result = await dynamodb.send(
 *       new GetItemCommand({
 *         TableName: this.tableName,
 *         Key: { eventId: { S: eventId } },
 *       })
 *     );
 *     if (!result.Item) return null;
 *     return {
 *       id: result.Item.id.S!,
 *       eventId: result.Item.eventId.S!,
 *       receivedAt: new Date(result.Item.receivedAt.S!),
 *       body: JSON.parse(result.Item.body.S!),
 *     };
 *   }
 *
 *   async exists(eventId: string): Promise<boolean> {
 *     const result = await dynamodb.send(
 *       new GetItemCommand({
 *         TableName: this.tableName,
 *         Key: { eventId: { S: eventId } },
 *       })
 *     );
 *     return !!result.Item;
 *   }
 * }
 */
