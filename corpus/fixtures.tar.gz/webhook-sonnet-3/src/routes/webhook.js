import { Router } from 'express';
import express from 'express';
import { randomUUID } from 'node:crypto';

import { verifySignature, SIGNATURE_HEADER } from '../signature.js';
import { badRequest, unauthorized } from '../errors.js';
import { STORED } from '../store.js';

/**
 * Accepts callbacks from the payment provider. Every request must carry a valid signature before
 * anything is written; a genuine callback is stored exactly as received and a repeated delivery of
 * one already on file is acknowledged without touching what is already there.
 */
export function createWebhookRouter({ store, secretsProvider, signingSecretId }) {
  const router = Router();

  // Raw bytes, not a parsed-and-reserialized body: the signature is computed over exactly what
  // the provider sent, and the record we keep has to be exactly what we received too.
  const rawBodyParser = express.raw({ type: '*/*', limit: '1mb' });

  router.post('/webhooks/payment-provider', rawBodyParser, handleWebhook);

  async function handleWebhook(req, res, next) {
    try {
      const rawBody = Buffer.isBuffer(req.body) ? req.body : Buffer.from([]);
      const signatureHeader = req.get(SIGNATURE_HEADER);

      if (!signatureHeader) {
        next(badRequest(`missing ${SIGNATURE_HEADER} header`));
        return;
      }
      if (rawBody.length === 0) {
        next(badRequest('empty request body'));
        return;
      }

      let secrets = await secretsProvider.getSigningSecrets(signingSecretId);
      let verified = verifySignature(rawBody, signatureHeader, secrets);
      if (!verified) {
        // The secret in hand may be stale relative to a rotation that just happened. Refetch once
        // and try again before concluding the callback is forged, so a rotation on the provider's
        // side does not read as an attack on ours.
        secrets = await secretsProvider.getSigningSecrets(signingSecretId, { forceRefresh: true });
        verified = verifySignature(rawBody, signatureHeader, secrets);
      }
      if (!verified) {
        next(unauthorized('signature verification failed'));
        return;
      }

      let payload;
      try {
        payload = JSON.parse(rawBody.toString('utf8'));
      } catch {
        next(badRequest('body is not valid JSON'));
        return;
      }

      const eventId = payload && typeof payload.event_id === 'string' ? payload.event_id : null;
      if (!eventId) {
        next(badRequest('payload is missing a string event_id'));
        return;
      }

      const outcome = await store.recordCallback({
        eventId,
        receivedAt: new Date().toISOString(),
        headers: sanitizeHeaders(req.headers),
        rawBody,
      });

      res.status(outcome === STORED ? 201 : 200).json({
        event_id: eventId,
        status: outcome === STORED ? 'recorded' : 'already recorded',
        request_id: randomUUID(),
      });
    } catch (err) {
      next(err);
    }
  }

  return router;
}

// Header values are stored for dispute resolution too, but the raw Buffer form Express gives us
// for the connection itself does not belong in a persisted record.
function sanitizeHeaders(headers) {
  const { host, connection, ...rest } = headers;
  return rest;
}
