import { getPool } from './database.js';
import { v4 as uuidv4 } from 'uuid';

const RETENTION_YEARS = 7;

export async function storeWebhook(eventId, payload, signature, timestamp) {
  const pool = await getPool();
  const id = uuidv4();

  // Calculate retention date (7 years from now)
  const retentionUntil = new Date();
  retentionUntil.setFullYear(retentionUntil.getFullYear() + RETENTION_YEARS);

  try {
    const result = await pool.query(
      `INSERT INTO webhooks (id, event_id, payload, signature, timestamp, retention_until)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, event_id, received_at`,
      [id, eventId, JSON.stringify(payload), signature, timestamp, retentionUntil]
    );

    return result.rows[0];
  } catch (error) {
    if (error.code === '23505') {
      // Unique constraint violation - webhook with this event_id already exists
      const existing = await getWebhookByEventId(eventId);
      return existing; // Return existing record instead of failing
    }
    throw error;
  }
}

export async function getWebhookByEventId(eventId) {
  const pool = await getPool();

  const result = await pool.query(
    `SELECT id, event_id, payload, signature, timestamp, received_at
     FROM webhooks
     WHERE event_id = $1`,
    [eventId]
  );

  if (result.rows.length === 0) {
    return null;
  }

  const row = result.rows[0];
  return {
    id: row.id,
    event_id: row.event_id,
    payload: row.payload,
    signature: row.signature,
    timestamp: row.timestamp,
    received_at: row.received_at
  };
}
