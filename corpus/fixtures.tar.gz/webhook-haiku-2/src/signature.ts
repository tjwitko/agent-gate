import crypto from "crypto";
import { SigningSecret } from "./types.js";

export class SignatureVerificationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SignatureVerificationError";
  }
}

export class SignatureVerifier {
  private secrets: Map<string, SigningSecret> = new Map();

  addSecret(secret: string, activeFrom: Date): void {
    const id = this.generateSecretId(secret);
    this.secrets.set(id, { secret, activeFrom });
  }

  verify(
    eventId: string,
    timestamp: string,
    signature: string,
    body: Record<string, unknown>
  ): void {
    const payload = `${eventId}.${timestamp}.${JSON.stringify(body)}`;

    let verified = false;
    let latestSecret: SigningSecret | null = null;

    for (const secret of this.secrets.values()) {
      if (latestSecret === null || secret.activeFrom > latestSecret.activeFrom) {
        latestSecret = secret;
      }

      const computed = this.computeSignature(payload, secret.secret);
      // timingSafeEqual requires buffers of equal length
      if (computed.length === signature.length) {
        try {
          if (crypto.timingSafeEqual(Buffer.from(computed), Buffer.from(signature))) {
            verified = true;
            break;
          }
        } catch {
          // Ignore comparison errors and continue
        }
      }
    }

    if (!verified) {
      throw new SignatureVerificationError(
        "Signature verification failed: no matching secret"
      );
    }
  }

  private computeSignature(payload: string, secret: string): string {
    return crypto.createHmac("sha256", secret).update(payload).digest("hex");
  }

  private generateSecretId(secret: string): string {
    return crypto.createHash("sha256").update(secret).digest("hex");
  }
}
