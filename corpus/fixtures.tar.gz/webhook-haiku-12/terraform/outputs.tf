output "eks_cluster_name" {
  description = "EKS cluster name"
  value       = aws_eks_cluster.main.name
}

output "eks_cluster_endpoint" {
  description = "EKS cluster endpoint"
  value       = aws_eks_cluster.main.endpoint
}

output "alb_dns_name" {
  description = "Application Load Balancer DNS name"
  value       = aws_lb.main.dns_name
}

output "alb_arn" {
  description = "Application Load Balancer ARN"
  value       = aws_lb.main.arn
}

output "s3_backup_bucket" {
  description = "S3 bucket for callback backups"
  value       = aws_s3_bucket.callback_backup.id
}

output "cloudwatch_log_group" {
  description = "CloudWatch log group for webhook receiver"
  value       = aws_cloudwatch_log_group.webhook_receiver.name
}

output "webhook_receiver_irsa_role_arn" {
  description = "IAM role ARN for webhook receiver IRSA"
  value       = aws_iam_role.webhook_receiver_irsa.arn
}
