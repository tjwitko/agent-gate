# Backend configuration for production deployment
# To use S3 backend, uncomment the following and provide AWS credentials

# terraform {
#   backend "s3" {
#     bucket         = "webhook-receiver-terraform-state"
#     key            = "prod/terraform.tfstate"
#     region         = "us-east-1"
#     encrypt        = true
#     dynamodb_table = "webhook-receiver-terraform-locks"
#   }
# }

# For local development, Terraform will use local state file by default
