// The provider-facing app: accepts a callback, proves it genuinely came from the provider, and
// records it exactly once. This is the only app whose identity can write to the callback store —
// its IAM role grants PutItem and nothing else — and app-layer signature verification is the only
// gate in front of that write.

import express from "express";
import { verifySignature } from "./lib/signature.mjs";
import { BadRequestError, UnauthorizedError } from "./lib/errors.mjs";
import { asyncHandler, pickHeaders } from "./lib/httpHelpers.mjs";
import { errorMiddleware, notFoundMiddleware, consoleLogger } from "./lib/errorMiddleware.mjs";

const SIGNATURE_HEADER = "x-provider-signature";
const MAX_BODY_BYTES = 1024 * 1024;

/**
 * @param {{ signingSecretSource: import("./lib/signingSecretSource.mjs").SigningSecretSource,
 *           store: { recordIfNew(eventId, record): Promise<{isNew: boolean}> },
 *           logger?: typeof consoleLogger }} deps
 */
export function createWebhookIngestApp(deps) {
  const logger = deps.logger ?? consoleLogger;
  const app = express();

  // Health check for the load balancer. Exempt from authentication by convention — a probe that
  // requires a credential is a probe that always fails.
  app.get("/healthz", (req, res) => res.status(200).json({ status: "ok" }));

  app.post(
    "/webhooks/payment-provider",
    express.raw({ type: "*/*", limit: MAX_BODY_BYTES }),
    asyncHandler(async (req, res) => {
      const rawBody = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
      const signatureHeader = req.get(SIGNATURE_HEADER);

      // Authentication happens here, in the route itself, deliberately not behind an indirection
      // a later refactor could drop without anyone noticing at the route: verify against whatever
      // is cached, and if every candidate fails, refresh once (the cache may simply not have
      // noticed a rotation yet) and try again before rejecting.
      let candidates = signatureHeader ? await deps.signingSecretSource.getCandidates() : [];
      let signatureVerified = candidates.some((secret) => verifySignature(secret, rawBody, signatureHeader));
      if (!signatureVerified && signatureHeader) {
        deps.signingSecretSource.refresh();
        candidates = await deps.signingSecretSource.getCandidates();
        signatureVerified = candidates.some((secret) => verifySignature(secret, rawBody, signatureHeader));
      }
      if (!signatureVerified) {
        throw new UnauthorizedError("request signature did not verify against any known signing secret");
      }

      let payload;
      try {
        payload = JSON.parse(rawBody.toString("utf8"));
      } catch {
        throw new BadRequestError("request body is not valid JSON");
      }
      const eventId = payload && typeof payload.event_id === "string" ? payload.event_id : null;
      if (!eventId) {
        throw new BadRequestError("request body has no string event_id field");
      }

      const record = {
        receivedAt: new Date().toISOString(),
        rawBodyBase64: rawBody.toString("base64"),
        headers: pickHeaders(req.headers),
      };
      const { isNew } = await deps.store.recordIfNew(eventId, record);

      logger.info({ eventId, isNew }, "callback processed");
      res.status(isNew ? 201 : 200).json({
        status: isNew ? "recorded" : "already_recorded",
        eventId,
      });
    })
  );

  app.use(notFoundMiddleware);
  app.use(errorMiddleware(logger));
  return app;
}
