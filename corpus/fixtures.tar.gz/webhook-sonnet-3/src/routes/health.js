import { Router } from 'express';

/** Liveness/readiness target for the load balancer. Deliberately open to anyone who can reach it. */
export function createHealthRouter() {
  const router = Router();
  router.get('/healthz', (req, res) => {
    res.status(200).json({ status: 'ok' });
  });
  return router;
}
