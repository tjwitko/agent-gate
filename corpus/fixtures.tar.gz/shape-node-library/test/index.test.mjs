import test from "node:test";
import assert from "node:assert/strict";

import { breakdown, humanize } from "../src/index.mjs";

test("breaks a duration into units", () => {
  assert.deepEqual(breakdown(90_061_000), { days: 1, hours: 1, minutes: 1, seconds: 1 });
});

test("zero is zero seconds, not an empty string", () => {
  assert.equal(humanize(0), "0s");
});

test("omits leading zero units", () => {
  assert.equal(humanize(3_600_000), "1h");
});

test("rejects a negative duration", () => {
  assert.throws(() => breakdown(-1), RangeError);
});
