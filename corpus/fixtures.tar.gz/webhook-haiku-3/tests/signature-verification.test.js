import crypto from 'crypto';
import assert from 'assert';

// Test: Accepts a genuine callback with valid HMAC-SHA256 signature
const secret = 'test-secret-key';
const payload = { event_id: 'evt_123', type: 'payment.completed' };
const timestamp = '1234567890';
const message = `${timestamp}.${JSON.stringify(payload)}`;
const signature = crypto
  .createHmac('sha256', secret)
  .update(message)
  .digest('hex');

const computed = crypto
  .createHmac('sha256', secret)
  .update(message)
  .digest('hex');

assert.strictEqual(signature, computed, 'Valid signature should be accepted');

// Test: Rejects a forged callback with invalid signature
const wrongSecret = 'wrong-secret';
const forgedSignature = crypto
  .createHmac('sha256', wrongSecret)
  .update(message)
  .digest('hex');

assert.notStrictEqual(signature, forgedSignature, 'Forged signature should be rejected');

export function testAcceptGenuineSignature() {
  const secret = 'test-secret-key';
  const payload = { event_id: 'evt_123', type: 'payment.completed' };
  const timestamp = '1234567890';
  const message = `${timestamp}.${JSON.stringify(payload)}`;
  const signature = crypto
    .createHmac('sha256', secret)
    .update(message)
    .digest('hex');

  const computed = crypto
    .createHmac('sha256', secret)
    .update(message)
    .digest('hex');

  if (signature !== computed) {
    throw new Error('Valid signature was rejected');
  }
}

export function testRejectForgedSignature() {
  const secret = 'test-secret-key';
  const wrongSecret = 'wrong-secret';
  const payload = { event_id: 'evt_123', type: 'payment.completed' };
  const timestamp = '1234567890';
  const message = `${timestamp}.${JSON.stringify(payload)}`;

  const signature = crypto
    .createHmac('sha256', secret)
    .update(message)
    .digest('hex');

  const computed = crypto
    .createHmac('sha256', wrongSecret)
    .update(message)
    .digest('hex');

  if (signature === computed) {
    throw new Error('Forged signature was accepted');
  }
}
