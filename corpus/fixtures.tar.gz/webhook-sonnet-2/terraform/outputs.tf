output "dynamodb_table_name" {
  description = "Value for the DYNAMODB_TABLE_NAME env var in k8s/deployment.yaml."
  value       = aws_dynamodb_table.webhook_events_log.name
}

output "app_iam_role_arn" {
  description = "Value for the eks.amazonaws.com/role-arn annotation in k8s/serviceaccount.yaml."
  value       = aws_iam_role.app.arn
}

output "webhook_signing_secret_id" {
  description = "Value for the SIGNING_SECRET_ID env var in k8s/deployment.yaml."
  value       = aws_secretsmanager_secret.webhook_signing_secret.id
}

output "support_api_token_secret_id" {
  description = "Value for the SUPPORT_TOKEN_SECRET_ID env var in k8s/deployment.yaml."
  value       = aws_secretsmanager_secret.support_api_token.id
}

output "ecr_repository_url" {
  description = "Push the built image here; reference it (with a version tag, not :latest -- the repository is tag-immutable) in k8s/deployment.yaml."
  value       = aws_ecr_repository.app.repository_url
}
