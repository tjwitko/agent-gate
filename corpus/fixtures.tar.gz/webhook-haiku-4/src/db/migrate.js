const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

async function migrate() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    await client.query(`
      CREATE TABLE IF NOT EXISTS signing_secrets (
        id SERIAL PRIMARY KEY,
        secret TEXT NOT NULL UNIQUE,
        active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT NOW(),
        rotated_at TIMESTAMP
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS webhook_events (
        id BIGSERIAL PRIMARY KEY,
        event_id TEXT NOT NULL UNIQUE,
        payload TEXT NOT NULL,
        signature TEXT NOT NULL,
        received_at TIMESTAMP DEFAULT NOW() NOT NULL,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await client.query(`
      CREATE OR REPLACE FUNCTION prevent_webhook_events_update() RETURNS TRIGGER AS $$
      BEGIN
        RAISE EXCEPTION 'webhook_events records are immutable and cannot be updated';
      END;
      $$ LANGUAGE plpgsql;
    `);

    await client.query(`
      CREATE OR REPLACE FUNCTION prevent_webhook_events_delete() RETURNS TRIGGER AS $$
      BEGIN
        RAISE EXCEPTION 'webhook_events records are immutable and cannot be deleted';
      END;
      $$ LANGUAGE plpgsql;
    `);

    await client.query(`
      DROP TRIGGER IF EXISTS webhook_events_update_trigger ON webhook_events;
      CREATE TRIGGER webhook_events_update_trigger
      BEFORE UPDATE ON webhook_events
      FOR EACH ROW
      EXECUTE FUNCTION prevent_webhook_events_update();
    `);

    await client.query(`
      DROP TRIGGER IF EXISTS webhook_events_delete_trigger ON webhook_events;
      CREATE TRIGGER webhook_events_delete_trigger
      BEFORE DELETE ON webhook_events
      FOR EACH ROW
      EXECUTE FUNCTION prevent_webhook_events_delete();
    `);

    await client.query(`
      CREATE OR REPLACE FUNCTION prevent_signing_secrets_delete() RETURNS TRIGGER AS $$
      BEGIN
        RAISE EXCEPTION 'signing_secrets records are immutable and cannot be deleted';
      END;
      $$ LANGUAGE plpgsql;
    `);

    await client.query(`
      DROP TRIGGER IF EXISTS signing_secrets_delete_trigger ON signing_secrets;
      CREATE TRIGGER signing_secrets_delete_trigger
      BEFORE DELETE ON signing_secrets
      FOR EACH ROW
      EXECUTE FUNCTION prevent_signing_secrets_delete();
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_webhook_events_event_id ON webhook_events(event_id)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_webhook_events_received_at ON webhook_events(received_at)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_signing_secrets_active ON signing_secrets(active)
    `);

    // Create application role if it doesn't exist
    const roleCheckResult = await client.query(
      "SELECT 1 FROM pg_roles WHERE rolname = 'webhook_app'"
    );
    if (roleCheckResult.rows.length === 0) {
      await client.query('CREATE ROLE webhook_app WITH LOGIN NOCREATEDB NOCREATEROLE');
    }

    // Grant SELECT and INSERT only, revoke UPDATE, DELETE, TRUNCATE
    await client.query('GRANT SELECT, INSERT ON webhook_events TO webhook_app');
    await client.query('REVOKE UPDATE, DELETE, TRUNCATE ON webhook_events FROM webhook_app');

    await client.query('GRANT SELECT ON signing_secrets TO webhook_app');
    await client.query('REVOKE UPDATE, DELETE, TRUNCATE ON signing_secrets FROM webhook_app');

    await client.query('COMMIT');
    console.log('Database migration completed successfully');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Migration failed:', err);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

migrate();
