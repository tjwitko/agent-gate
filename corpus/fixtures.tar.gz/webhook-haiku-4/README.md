# Webhook Receiver

A secure webhook receiver service for payment provider event notifications, with cryptographic signature verification, immutable event storage, and role-based access control.

## Features

- **Signature Verification**: HMAC-SHA256 based webhook signature verification with support for key rotation
- **Immutable Storage**: Once recorded, webhook events cannot be modified or deleted
- **Access Control**: Role-based access - provider can submit, support team can read
- **Health Endpoint**: Load balancer health check support
- **Audit Ready**: Full event logging and request tracing
- **7-Year Retention**: Long-term storage for chargeback dispute resolution
- **Multi-region Capable**: AWS-based deployment with Kubernetes orchestration

## Project Structure

```
.
├── src/
│   ├── server.js              # Express webhook server
│   ├── server.test.js         # Comprehensive test suite
│   └── db/
│       └── migrate.js         # Database migration script
├── k8s/                        # Kubernetes manifests
│   ├── deployment.yaml
│   ├── service.yaml
│   ├── network-policy.yaml
│   └── rbac.yaml
├── terraform/                  # Infrastructure as Code
│   ├── main.tf
│   ├── variables.tf
│   └── modules/
│       ├── vpc/
│       ├── security_groups/
│       ├── rds/
│       └── eks/
├── Dockerfile                  # Container image definition
├── package.json
└── README.md
```

## Prerequisites

- Node.js 18+
- PostgreSQL 15+
- Docker (for containerization)
- Terraform 1.0+ (for infrastructure)
- kubectl (for Kubernetes deployment)
- AWS CLI configured with appropriate credentials

## Development Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your configuration
```

### 3. Database Setup

For development, create a local PostgreSQL database:

```bash
createdb webhook_receiver
```

Then run migrations:

```bash
npm run migrate
```

### 4. Seed Signing Secret

```bash
# In PostgreSQL
INSERT INTO signing_secrets (secret, active) 
VALUES ('your-test-secret-key', true);
```

### 5. Start the Server

```bash
npm start
```

The server will be available at `http://localhost:3000`

## Testing

### Prerequisites

First, install dependencies:

```bash
npm install
```

Then set up a test database:

```bash
createdb webhook_receiver_test
export TEST_DATABASE_URL="postgresql://postgres@localhost/webhook_receiver_test"
```

Run the comprehensive test suite:

```bash
npm test
```

The tests cover:
- Valid and invalid webhook signatures
- Duplicate webhook handling
- Authorization and access control
- Error handling (distinguishing client vs server errors)
- Health endpoint

## Building

### Docker Image

```bash
docker build -t webhook-receiver:latest .
```

## Deployment

### Prerequisites

- AWS account with appropriate permissions
- Terraform configured
- kubectl configured to target your EKS cluster

### 1. Infrastructure Setup

```bash
cd terraform

# Create terraform.tfvars from template
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your values

# Review planned changes
terraform plan

# Apply infrastructure
terraform apply
```

### 2. Database Initialization

After RDS is created:

```bash
# Get the RDS endpoint from terraform output
RDS_ENDPOINT=$(terraform output rds_endpoint)

# Connect and run migrations
DATABASE_URL="postgresql://webhookadmin:${DB_PASSWORD}@${RDS_ENDPOINT}:5432/webhook_receiver" \
  npm run migrate
```

### 3. Kubernetes Deployment

```bash
# Create namespace
kubectl create namespace payment-webhooks

# Create secrets
kubectl create secret generic webhook-receiver-secrets \
  -n payment-webhooks \
  --from-literal=database-url="postgresql://webhookadmin:password@your-rds-host:5432/webhook_receiver" \
  --from-literal=support-token="your-secret-support-token"

# Apply manifests
kubectl apply -f k8s/rbac.yaml
kubectl apply -f k8s/network-policy.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml

# Verify deployment
kubectl get pods -n payment-webhooks
kubectl get svc -n payment-webhooks
```

## API Usage

### Submit a Webhook

```bash
# Generate signature
PAYLOAD='{"event_type":"payment.completed","transaction_id":"txn_123"}'
SECRET='your-signing-secret'
SIGNATURE=$(echo -n "$PAYLOAD" | openssl dgst -sha256 -hmac "$SECRET" -hex | cut -d' ' -f2)

# Submit webhook
curl -X POST https://webhook-receiver.example.com/webhook \
  -H "Content-Type: application/json" \
  -H "x-provider-signature: $SIGNATURE" \
  -H "x-event-id: evt_123" \
  -d "$PAYLOAD"
```

### Read a Webhook Event (Support Team)

```bash
SUPPORT_TOKEN="your-support-token"
curl -X GET https://webhook-receiver.example.com/webhook/evt_123 \
  -H "Authorization: Bearer $SUPPORT_TOKEN"
```

### Health Check

```bash
curl https://webhook-receiver.example.com/health
```

## Architecture

### Security

- **Signature Verification**: All incoming webhooks are verified using HMAC-SHA256
- **Key Rotation**: Support for rotating signing secrets without service interruption
- **Immutability**: Database constraints prevent modification/deletion of recorded events
- **Access Control**: RBAC and bearer token authentication for read operations
- **Network Isolation**: Kubernetes network policies restrict traffic

### Data Retention

- Events are retained for 7 years (2555 days)
- Automated daily backups with point-in-time recovery
- RDS Multi-AZ for production deployments

### High Availability

- 3 replicas of the webhook receiver service
- Multi-AZ RDS database
- Load balancer with health checks
- Horizontal auto-scaling capability

## Monitoring and Logging

The service exports logs to CloudWatch:
- API access logs
- Audit trail
- Database logs

## Troubleshooting

### Signature Verification Failures

- Verify the webhook payload hasn't been modified
- Check that the correct signing secret is being used
- Ensure the secret hasn't expired (check `signing_secrets` table)

### Database Connection Issues

- Verify DATABASE_URL environment variable
- Check security group rules allow pod-to-RDS traffic
- Confirm RDS instance is running and accepting connections

### Deployment Issues

```bash
# Check pod status
kubectl describe pod -n payment-webhooks <pod-name>

# View logs
kubectl logs -n payment-webhooks <pod-name>

# Check events
kubectl get events -n payment-webhooks
```

## Contributing

All code changes should include tests. Run the full test suite before submitting:

```bash
npm test
npm run lint
```

## License

MIT
