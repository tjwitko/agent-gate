# shape-python-service

A small Flask event receiver. It exists as an agent-gate corpus fixture covering the Python project
shape, which the corpus otherwise has none of: decorator routes that do not authenticate, a
`requirements.txt` with no lockfile, and source that exercises the Python half of `build_check`
(`py_compile` and `ruff`).

It deliberately ships no test suite. `pytest` must be importable by the `python3` on PATH for the
gate to run one, and requiring that of every machine running the corpus would make this fixture
unmeasurable wherever it was absent — recorded as an unmeasured verdict rather than a real one,
which is the failure this corpus was hardened against.
