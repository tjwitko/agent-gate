import sqlite3 from 'sqlite3';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = process.env.DB_PATH || path.join(__dirname, '../../data/callbacks.db');

let db;

export async function initDB() {
  return new Promise((resolve, reject) => {
    db = new sqlite3.Database(dbPath, (err) => {
      if (err) reject(err);
      else {
        db.run(`
          CREATE TABLE IF NOT EXISTS callbacks (
            id TEXT PRIMARY KEY,
            event_id TEXT NOT NULL UNIQUE,
            payload TEXT NOT NULL,
            signature TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            received_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `, (err) => {
          if (err) {
            reject(err);
            return;
          }

          // Create immutability triggers
          db.run(`
            CREATE TRIGGER IF NOT EXISTS callbacks_prevent_update
            BEFORE UPDATE ON callbacks
            BEGIN
              SELECT RAISE(ABORT, 'Callbacks are immutable and cannot be updated');
            END
          `, (err) => {
            if (err) console.error('Error creating update trigger:', err);

            db.run(`
              CREATE TRIGGER IF NOT EXISTS callbacks_prevent_delete
              BEFORE DELETE ON callbacks
              BEGIN
                SELECT RAISE(ABORT, 'Callbacks are immutable and cannot be deleted');
              END
            `, (err) => {
              if (err) {
                console.error('Error creating delete trigger:', err);
                reject(err);
              } else {
                resolve();
              }
            });
          });
        });
      }
    });
  });
}

export function recordCallback(eventId, payload, signature, timestamp) {
  return new Promise((resolve, reject) => {
    const id = uuidv4();
    db.run(
      'INSERT INTO callbacks (id, event_id, payload, signature, timestamp) VALUES (?, ?, ?, ?, ?)',
      [id, eventId, payload, signature, timestamp],
      function(err) {
        if (err) {
          if (err.message.includes('UNIQUE constraint failed')) {
            reject({ code: 'DUPLICATE_EVENT', message: 'Event already recorded' });
          } else {
            reject(err);
          }
        } else {
          resolve(id);
        }
      }
    );
  });
}

export function getCallbackByEventId(eventId) {
  return new Promise((resolve, reject) => {
    db.get(
      'SELECT * FROM callbacks WHERE event_id = ?',
      [eventId],
      (err, row) => {
        if (err) reject(err);
        else resolve(row);
      }
    );
  });
}

export function getAllCallbacks() {
  return new Promise((resolve, reject) => {
    db.all('SELECT * FROM callbacks ORDER BY received_at DESC', (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
}
