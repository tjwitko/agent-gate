import { test } from 'node:test';
import assert from 'node:assert/strict';

import { mockClient } from 'aws-sdk-client-mock';
import { DynamoDBDocumentClient, PutCommand, GetCommand } from '@aws-sdk/lib-dynamodb';

import { createStore, STORED, DUPLICATE } from '../src/store.js';

function fakeConditionalFailure() {
  const err = new Error('The conditional request failed');
  err.name = 'ConditionalCheckFailedException';
  return err;
}

test('recordCallback writes a new record with a conditional PutItem', async () => {
  const ddb = mockClient(DynamoDBDocumentClient);
  ddb.on(PutCommand).resolves({});
  const store = createStore(ddb, 'webhook-callbacks');

  const outcome = await store.recordCallback({
    eventId: 'evt_1',
    receivedAt: '2026-01-01T00:00:00.000Z',
    headers: { 'x-provider-signature': 'sha256=abc' },
    rawBody: Buffer.from('{"event_id":"evt_1"}'),
  });

  assert.equal(outcome, STORED);
  const calls = ddb.commandCalls(PutCommand);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].args[0].input.ConditionExpression, 'attribute_not_exists(event_id)');
  assert.equal(calls[0].args[0].input.Item.event_id, 'evt_1');
  ddb.restore();
});

test('recordCallback does not overwrite an already-recorded event', async () => {
  const ddb = mockClient(DynamoDBDocumentClient);
  ddb.on(PutCommand).rejects(fakeConditionalFailure());
  const store = createStore(ddb, 'webhook-callbacks');

  const outcome = await store.recordCallback({
    eventId: 'evt_2',
    receivedAt: '2026-01-01T00:00:00.000Z',
    headers: {},
    rawBody: Buffer.from('{"event_id":"evt_2","amount":999}'),
  });

  assert.equal(outcome, DUPLICATE);
  // The write path never falls back to a plain, unconditional PutItem when the conditional one is
  // rejected -- it always attempts the same conditional write and only interprets the result.
  const calls = ddb.commandCalls(PutCommand);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].args[0].input.ConditionExpression, 'attribute_not_exists(event_id)');
  ddb.restore();
});

test('recordCallback lets an unrelated DynamoDB fault propagate rather than swallowing it', async () => {
  const ddb = mockClient(DynamoDBDocumentClient);
  const fault = new Error('ProvisionedThroughputExceededException');
  fault.name = 'ProvisionedThroughputExceededException';
  ddb.on(PutCommand).rejects(fault);
  const store = createStore(ddb, 'webhook-callbacks');

  await assert.rejects(
    () =>
      store.recordCallback({
        eventId: 'evt_3',
        receivedAt: '2026-01-01T00:00:00.000Z',
        headers: {},
        rawBody: Buffer.from('{"event_id":"evt_3"}'),
      }),
    /ProvisionedThroughputExceededException/
  );
  ddb.restore();
});

test('getCallback returns null when nothing is recorded for that event id', async () => {
  const ddb = mockClient(DynamoDBDocumentClient);
  ddb.on(GetCommand).resolves({});
  const store = createStore(ddb, 'webhook-callbacks');

  const record = await store.getCallback('does-not-exist');
  assert.equal(record, null);
  ddb.restore();
});

test('getCallback returns the stored record', async () => {
  const ddb = mockClient(DynamoDBDocumentClient);
  ddb.on(GetCommand).resolves({ Item: { event_id: 'evt_4', raw_body: '{"event_id":"evt_4"}' } });
  const store = createStore(ddb, 'webhook-callbacks');

  const record = await store.getCallback('evt_4');
  assert.equal(record.event_id, 'evt_4');
  ddb.restore();
});
