# Webhook Receiver

A secure webhook receiver for payment provider event notifications with immutable storage and support team audit capabilities.

## Features

- **Signature Verification**: HMAC-SHA256 signature verification to ensure webhooks are from the payment provider
- **Immutable Storage**: Once recorded, webhook contents cannot be modified or deleted
- **Event Deduplication**: Repeated callbacks with the same event_id are handled without overwriting
- **7-Year Retention**: Webhooks are retained for seven years to support chargeback disputes
- **Admin Access**: Support team can look up past callbacks by event ID
- **Health Endpoint**: Load balancer compatibility with `/health` endpoint
- **Secret Rotation**: Supports provider secret rotation (quarterly)

## Architecture

- **Application**: Node.js Express server
- **Database**: PostgreSQL for immutable webhook storage
- **Container**: Docker containerization for consistent deployment
- **Orchestration**: Kubernetes for container management
- **Infrastructure**: AWS with Terraform for reproducible infrastructure
- **Load Balancing**: Application Load Balancer (ALB) for distributing traffic

## Project Structure

```
.
├── src/
│   ├── index.js           # Express app and endpoint definitions
│   ├── signature.js       # HMAC signature verification
│   ├── secrets.js         # Secrets management and caching
│   ├── database.js        # Database initialization and connection
│   └── storage.js         # Webhook storage and retrieval
├── tests/
│   └── webhook.test.js    # Test suite for webhooks
├── k8s/
│   └── deployment.yaml    # Kubernetes deployment manifests
├── terraform/
│   ├── main.tf            # AWS infrastructure definition
│   └── variables.tf       # Terraform variables
├── Dockerfile             # Container image definition
├── package.json           # Node.js dependencies
├── .env.example           # Environment variable template
└── README.md              # This file
```

## Development Setup

### Prerequisites

- Node.js 20+
- PostgreSQL 15+
- Docker (optional, for local containerization)
- Terraform 1.0+ (for AWS deployment)

### Local Setup

1. Clone the repository and install dependencies:
```bash
npm install
```

2. Copy environment file and configure:
```bash
cp .env.example .env
```

3. Set up PostgreSQL:
```bash
createdb webhook_db
```

4. Run tests:
```bash
npm test
```

5. Start the development server:
```bash
npm run dev
```

The server will be available at `http://localhost:3000`

## API Endpoints

### POST /webhook

Accepts webhook callbacks from the payment provider.

**Headers:**
- `x-signature`: HMAC-SHA256 signature of the request
- `x-timestamp`: Unix timestamp of the request

**Request Body:**
```json
{
  "event_id": "evt_123456",
  "type": "payment.completed",
  "amount": 10000,
  "currency": "USD"
}
```

**Response:**
```json
{
  "success": true,
  "id": "webhook_id_uuid"
}
```

**Status Codes:**
- `200`: Successfully stored webhook
- `400`: Missing required fields or invalid request format
- `401`: Invalid or missing signature
- `500`: Server error

### GET /health

Health check endpoint for load balancers.

**Response:**
```json
{
  "status": "ok"
}
```

### GET /admin/webhook/:eventId

Retrieve a webhook by event ID (admin only).

**Headers:**
- `Authorization`: Bearer token for admin authentication

**Response:**
```json
{
  "id": "webhook_id_uuid",
  "event_id": "evt_123456",
  "payload": { ... },
  "signature": "...",
  "timestamp": "1234567890",
  "received_at": "2026-09-02T19:30:00Z"
}
```

**Status Codes:**
- `200`: Webhook found
- `403`: Unauthorized
- `404`: Webhook not found
- `500`: Server error

## Testing

The test suite covers:

1. **Signature Verification**
   - Accepting valid signatures
   - Rejecting forged signatures
   - Rejecting invalid signatures

2. **Event Handling**
   - Storing new webhooks
   - Handling duplicate events without overwriting
   - Proper error responses for malformed requests

3. **Access Control**
   - Authorization for admin endpoints
   - Rejection of unauthorized access

Run tests with:
```bash
npm test
```

## Docker Deployment

Build the container image:
```bash
docker build -t webhook-receiver:latest .
```

Run the container:
```bash
docker run -p 3000:3000 \
  -e DATABASE_URL="postgresql://user:password@db/webhook_db" \
  -e PROVIDER_SECRET="your-secret" \
  -e ADMIN_TOKEN="your-token" \
  webhook-receiver:latest
```

## Kubernetes Deployment

Deploy to Kubernetes:
```bash
kubectl apply -f k8s/deployment.yaml
```

This creates:
- Deployment with 3 replicas
- ClusterIP Service
- ServiceAccount for RBAC
- Pod anti-affinity to spread across nodes

## AWS Terraform Deployment

### Prerequisites

- AWS account with appropriate permissions
- Terraform installed
- AWS CLI configured

### Deployment Steps

1. Configure variables in `terraform/terraform.tfvars`:
```hcl
aws_region       = "us-east-1"
db_password      = "secure-password-here"
provider_secret  = "payment-provider-secret"
admin_token      = "admin-auth-token"
ecr_repository   = "123456789012.dkr.ecr.us-east-1.amazonaws.com/webhook-receiver"
```

2. Initialize Terraform:
```bash
cd terraform
terraform init
```

3. Plan deployment:
```bash
terraform plan
```

4. Apply infrastructure:
```bash
terraform apply
```

### Infrastructure Components

- **VPC**: Custom VPC with public and private subnets
- **RDS**: Multi-AZ PostgreSQL database with automated backups
- **ECS**: Fargate cluster with auto-scaling
- **ALB**: Application Load Balancer with health checks
- **Secrets Manager**: Encrypted secret storage
- **CloudWatch**: Logs and monitoring

## Security Considerations

1. **Signature Verification**: All incoming webhooks are verified using HMAC-SHA256
2. **Immutable Storage**: Database constraints prevent modification/deletion of stored records
3. **Access Control**: Only authorized support team members can retrieve stored webhooks
4. **Secret Rotation**: Application supports rotating provider secrets without downtime
5. **Encryption**: Secrets stored in AWS Secrets Manager are encrypted at rest
6. **Network**: ECS tasks run in private subnets, accessible only through ALB
7. **Non-root User**: Container runs as non-root user with minimal privileges

## Monitoring

- Health endpoint at `/health` for load balancer checks
- CloudWatch Logs for application logging
- CloudWatch Metrics for ECS service monitoring
- Auto-scaling based on CPU and memory utilization

## Maintenance

### Secret Rotation

The application supports rotating the provider's signing secret without downtime:

1. Add new secret to Secrets Manager
2. Application automatically tries current and previous secrets
3. Old secret can be removed after verification period

### Database Maintenance

- Automated backups: Daily
- Backup retention: 30 days
- Multi-AZ for high availability
- Read replicas can be added for scaling read operations

### Data Retention

- Webhooks retained for 7 years
- Automatic cleanup via retention_until timestamp
- Regular data audits for compliance

## Error Handling

The application distinguishes between:

- **Client Errors (4xx)**: Bad requests from provider (400, 401, 403)
- **Server Errors (5xx)**: Internal service failures (500)

This distinction allows monitoring systems to properly alert on actual issues vs. expected validation failures.

## Development Workflow

1. Make changes to source code
2. Run tests: `npm test`
3. Build Docker image: `docker build -t webhook-receiver:latest .`
4. Push to ECR (for AWS deployment)
5. Update Kubernetes or ECS deployment

## License

Proprietary - For internal use only
