package signature

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

type Verifier struct {
	current string // Current signing secret
	old     string // Previous secret for rotation grace period
}

func NewVerifier(current, old string) *Verifier {
	return &Verifier{
		current: current,
		old:     old,
	}
}

// Verify checks if the signature matches the body using HMAC-SHA256.
// Uses hmac.Equal for constant-time comparison on raw digest bytes to prevent timing attacks.
// Accepts signatures created with either current or previous secret (hex-encoded).
func (v *Verifier) Verify(body []byte, signatureHex string) error {
	if signatureHex == "" {
		return fmt.Errorf("missing signature")
	}

	providedSig, err := hex.DecodeString(signatureHex)
	if err != nil {
		return fmt.Errorf("invalid signature format")
	}

	currentDigest := v.computeDigest(body, v.current)
	if hmac.Equal(currentDigest, providedSig) {
		return nil
	}

	// Try previous secret (for rotation grace period)
	if v.old != "" {
		oldDigest := v.computeDigest(body, v.old)
		if hmac.Equal(oldDigest, providedSig) {
			return nil
		}
	}

	return fmt.Errorf("invalid signature")
}

func (v *Verifier) computeDigest(body []byte, secret string) []byte {
	h := hmac.New(sha256.New, []byte(secret))
	h.Write(body)
	return h.Sum(nil)
}
