// Test doubles matching the real sources' interface, so the apps under test never need a live
// AWS account. Kept in one file since several test files need the same shapes.

export class FakeSigningSecretSource {
  constructor(current, previous = null) {
    this.current = current;
    this.previous = previous;
    this.refreshCount = 0;
  }
  async getCandidates() {
    return [this.current, this.previous].filter(Boolean);
  }
  refresh() {
    this.refreshCount++;
  }
}

export class FakeSingleSecretSource {
  constructor(value) {
    this.value = value;
    this.refreshCount = 0;
  }
  async getValue() {
    return this.value;
  }
  refresh() {
    this.refreshCount++;
  }
}

/** A store whose recordIfNew always throws, standing in for a real infrastructure fault. */
export class FailingStore {
  async recordIfNew() {
    throw new Error("simulated DynamoDB outage");
  }
  async getByEventId() {
    throw new Error("simulated DynamoDB outage");
  }
}

export function startEphemeral(app) {
  const server = app.listen(0);
  const port = server.address().port;
  return { server, url: (path) => `http://127.0.0.1:${port}${path}` };
}
