terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# VPC and Networking
resource "aws_vpc" "webhook" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name = "webhook-receiver-vpc"
  }
}

resource "aws_internet_gateway" "webhook" {
  vpc_id = aws_vpc.webhook.id

  tags = {
    Name = "webhook-receiver-igw"
  }
}

resource "aws_subnet" "public" {
  count                   = 2
  vpc_id                  = aws_vpc.webhook.id
  cidr_block              = "10.0.${count.index + 1}.0/24"
  availability_zone       = data.aws_availability_zones.available.names[count.index]
  map_public_ip_on_launch = true

  tags = {
    Name = "webhook-receiver-public-${count.index + 1}"
  }
}

resource "aws_subnet" "private" {
  count             = 2
  vpc_id            = aws_vpc.webhook.id
  cidr_block        = "10.0.${count.index + 10}.0/24"
  availability_zone = data.aws_availability_zones.available.names[count.index]

  tags = {
    Name = "webhook-receiver-private-${count.index + 1}"
  }
}

data "aws_availability_zones" "available" {
  state = "available"
}

# NAT Gateway for private subnets
resource "aws_eip" "nat" {
  count  = 2
  domain = "vpc"

  tags = {
    Name = "webhook-receiver-eip-${count.index + 1}"
  }
}

resource "aws_nat_gateway" "webhook" {
  count         = 2
  allocation_id = aws_eip.nat[count.index].id
  subnet_id     = aws_subnet.public[count.index].id

  tags = {
    Name = "webhook-receiver-nat-${count.index + 1}"
  }

  depends_on = [aws_internet_gateway.webhook]
}

# Route tables
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.webhook.id

  route {
    cidr_block      = "0.0.0.0/0"
    gateway_id      = aws_internet_gateway.webhook.id
  }

  tags = {
    Name = "webhook-receiver-public-rt"
  }
}

resource "aws_route_table_association" "public" {
  count          = 2
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

resource "aws_route_table" "private" {
  count  = 2
  vpc_id = aws_vpc.webhook.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.webhook[count.index].id
  }

  tags = {
    Name = "webhook-receiver-private-rt-${count.index + 1}"
  }
}

resource "aws_route_table_association" "private" {
  count          = 2
  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private[count.index].id
}

# Security groups
resource "aws_security_group" "alb" {
  name   = "webhook-receiver-alb-sg"
  vpc_id = aws_vpc.webhook.id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "webhook-receiver-alb-sg"
  }
}

resource "aws_security_group" "ecs" {
  name   = "webhook-receiver-ecs-sg"
  vpc_id = aws_vpc.webhook.id

  ingress {
    from_port       = 3000
    to_port         = 3000
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "webhook-receiver-ecs-sg"
  }
}

# DynamoDB for storing callbacks (immutable)
# Immutability is enforced at the application level:
# 1. The application uses conditional writes with attribute_not_exists(eventId)
# 2. No DELETE or UPDATE operations are exposed via the API
# 3. No application code can modify or delete records once written
# 4. Point-in-time recovery is enabled for audit trail
# 5. IAM policies restrict the ECS task to only PutItem, GetItem, and Query operations
resource "aws_dynamodb_table" "callbacks" {
  name           = "webhook-callbacks"
  billing_mode   = "PAY_PER_REQUEST"
  hash_key       = "eventId"

  attribute {
    name = "eventId"
    type = "S"
  }

  point_in_time_recovery {
    enabled = true
  }

  tags = {
    Name = "webhook-callbacks"
  }
}

# S3 for immutable backup (optional)
resource "aws_s3_bucket" "callback_backups" {
  bucket = "webhook-callbacks-${data.aws_caller_identity.current.account_id}"

  tags = {
    Name = "webhook-callbacks-backups"
  }
}

resource "aws_s3_bucket_versioning" "callback_backups" {
  bucket = aws_s3_bucket.callback_backups.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_object_lock_configuration" "callback_backups" {
  bucket = aws_s3_bucket.callback_backups.id

  rule {
    default_retention {
      mode = "GOVERNANCE"
      days = 2555  # 7 years
    }
  }
}

# ALB
resource "aws_lb" "webhook" {
  name               = "webhook-receiver-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = aws_subnet.public[*].id

  tags = {
    Name = "webhook-receiver-alb"
  }
}

resource "aws_lb_target_group" "webhook" {
  name        = "webhook-receiver-tg"
  port        = 3000
  protocol    = "HTTP"
  vpc_id      = aws_vpc.webhook.id
  target_type = "ip"

  health_check {
    healthy_threshold   = 2
    unhealthy_threshold = 2
    timeout             = 3
    interval            = 30
    path                = "/health"
    matcher             = "200"
  }

  tags = {
    Name = "webhook-receiver-tg"
  }
}

resource "aws_lb_listener" "webhook" {
  load_balancer_arn = aws_lb.webhook.arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.webhook.arn
  }
}

# ECS Cluster
resource "aws_ecs_cluster" "webhook" {
  name = "webhook-receiver"

  setting {
    name  = "containerInsights"
    value = "enabled"
  }

  tags = {
    Name = "webhook-receiver-cluster"
  }
}

# CloudWatch Log Group
resource "aws_cloudwatch_log_group" "webhook" {
  name              = "/ecs/webhook-receiver"
  retention_in_days = 30

  tags = {
    Name = "webhook-receiver-logs"
  }
}

# ECS Task Execution Role
resource "aws_iam_role" "ecs_task_execution_role" {
  name = "webhook-receiver-ecs-task-execution-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Principal = {
        Service = "ecs-tasks.amazonaws.com"
      }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "ecs_task_execution_role_policy" {
  role       = aws_iam_role.ecs_task_execution_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

resource "aws_iam_role_policy" "ecs_task_execution_role_logs" {
  name = "webhook-receiver-ecs-task-execution-logs"
  role = aws_iam_role.ecs_task_execution_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ]
      Resource = "${aws_cloudwatch_log_group.webhook.arn}:*"
    }]
  })
}

# ECS Task Role
resource "aws_iam_role" "ecs_task_role" {
  name = "webhook-receiver-ecs-task-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Principal = {
        Service = "ecs-tasks.amazonaws.com"
      }
    }]
  })
}

resource "aws_iam_role_policy" "ecs_task_dynamodb" {
  name = "webhook-receiver-ecs-task-dynamodb"
  role = aws_iam_role.ecs_task_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowGetAndQueryOnly"
        Effect = "Allow"
        Action = [
          "dynamodb:GetItem",
          "dynamodb:Query"
        ]
        Resource = aws_dynamodb_table.callbacks.arn
      },
      {
        Sid    = "AllowPutItemOnlyIfNotExists"
        Effect = "Allow"
        Action = [
          "dynamodb:PutItem"
        ]
        Resource = aws_dynamodb_table.callbacks.arn
        Condition = {
          StringEquals = {
            "dynamodb:LeadingKeys" = ["${aws_dynamodb_table.callbacks.hash_key}"]
          }
        }
      }
    ]
  })
}

# ECS Task Definition
resource "aws_ecs_task_definition" "webhook" {
  family                   = "webhook-receiver"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = "256"
  memory                   = "512"
  execution_role_arn       = aws_iam_role.ecs_task_execution_role.arn
  task_role_arn            = aws_iam_role.ecs_task_role.arn

  container_definitions = jsonencode([{
    name      = "webhook-receiver"
    image     = var.container_image
    essential = true
    portMappings = [{
      containerPort = 3000
      hostPort      = 3000
      protocol      = "tcp"
    }]
    environment = [
      {
        name  = "NODE_ENV"
        value = "production"
      },
      {
        name  = "WEBHOOK_SECRET"
        value = var.webhook_secret
      },
      {
        name  = "DYNAMODB_TABLE"
        value = aws_dynamodb_table.callbacks.name
      },
      {
        name  = "PORT"
        value = "3000"
      }
    ]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = aws_cloudwatch_log_group.webhook.name
        "awslogs-region"        = var.aws_region
        "awslogs-stream-prefix" = "ecs"
      }
    }
  }])
}

# ECS Service
resource "aws_ecs_service" "webhook" {
  name            = "webhook-receiver"
  cluster         = aws_ecs_cluster.webhook.id
  task_definition = aws_ecs_task_definition.webhook.arn
  desired_count   = var.desired_count
  launch_type     = "FARGATE"

  network_configuration {
    subnets          = aws_subnet.private[*].id
    security_groups  = [aws_security_group.ecs.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.webhook.arn
    container_name   = "webhook-receiver"
    container_port   = 3000
  }

  depends_on = [aws_lb_listener.webhook]
}

# Auto-scaling
resource "aws_appautoscaling_target" "ecs_target" {
  max_capacity       = var.max_count
  min_capacity       = var.desired_count
  resource_id        = "service/${aws_ecs_cluster.webhook.name}/${aws_ecs_service.webhook.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

resource "aws_appautoscaling_policy" "ecs_policy_cpu" {
  name               = "webhook-receiver-cpu"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.ecs_target.resource_id
  scalable_dimension = aws_appautoscaling_target.ecs_target.scalable_dimension
  service_namespace  = aws_appautoscaling_target.ecs_target.service_namespace

  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
    target_value = 70.0
  }
}

data "aws_caller_identity" "current" {}
