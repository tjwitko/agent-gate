# The provider's HMAC signing secret. Terraform declares the secret's existence and access
# control but never its value: the value has to match a third party's secret and is rotated by
# them on their own quarterly schedule, so Terraform managing it would mean either putting a
# secret we do not control into state, or fighting the provider's own rotations on every apply.
# Populate the first version out of band once, e.g.:
#   aws secretsmanager put-secret-value --secret-id webhook-receiver/provider-signing-secret \
#     --secret-string '<value the provider gave you>'
# Every later rotation is another put-secret-value call, which is exactly what promotes the
# previous version to AWSPREVIOUS — the stage src/lib/signingSecretSource.mjs also accepts during
# the grace window right after a rotation.
resource "aws_secretsmanager_secret" "signing_secret" {
  name                    = "webhook-receiver/provider-signing-secret"
  description             = "HMAC-SHA256 signing secret shared with the payment provider. Rotated quarterly by the provider; value is populated out of band, not by Terraform."
  recovery_window_in_days = 30
  kms_key_id              = aws_kms_key.app.arn
}

# The support team's own API key, by contrast, is ours to generate and Terraform can own its
# value end to end.
resource "random_password" "support_api_key" {
  length           = 48
  special          = true
  override_special = "-_"
}

resource "aws_secretsmanager_secret" "support_api_key" {
  name                    = "webhook-receiver/support-api-key"
  description             = "Credential the support team's tooling presents to the support-api service."
  recovery_window_in_days = 30
  kms_key_id              = aws_kms_key.app.arn
}

resource "aws_secretsmanager_secret_version" "support_api_key" {
  secret_id     = aws_secretsmanager_secret.support_api_key.id
  secret_string = random_password.support_api_key.result
}
