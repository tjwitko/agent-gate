import sqlite3 from 'sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = process.env.DB_PATH || path.join(__dirname, '../../data/callbacks.db');

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error opening database:', err);
    process.exit(1);
  }

  // Create table if it doesn't exist
  db.run(`
    CREATE TABLE IF NOT EXISTS callbacks (
      id TEXT PRIMARY KEY,
      event_id TEXT NOT NULL UNIQUE,
      payload TEXT NOT NULL,
      signature TEXT NOT NULL,
      timestamp TEXT NOT NULL,
      received_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `, (err) => {
    if (err) {
      console.error('Error creating table:', err);
      process.exit(1);
    }

    // Add immutability triggers
    // Prevent UPDATE operations
    db.run(`
      CREATE TRIGGER IF NOT EXISTS callbacks_prevent_update
      BEFORE UPDATE ON callbacks
      BEGIN
        SELECT RAISE(ABORT, 'Callbacks are immutable and cannot be updated');
      END
    `, (err) => {
      if (err) console.error('Error creating update trigger:', err);
    });

    // Prevent DELETE operations
    db.run(`
      CREATE TRIGGER IF NOT EXISTS callbacks_prevent_delete
      BEFORE DELETE ON callbacks
      BEGIN
        SELECT RAISE(ABORT, 'Callbacks are immutable and cannot be deleted');
      END
    `, (err) => {
      if (err) console.error('Error creating delete trigger:', err);
    });

    console.log('Database initialized with immutability triggers');
    db.close();
  });
});
