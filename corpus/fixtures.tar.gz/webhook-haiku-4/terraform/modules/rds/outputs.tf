output "db_instance_endpoint" {
  description = "RDS instance endpoint"
  value       = aws_db_instance.webhook_receiver.endpoint
}

output "db_instance_port" {
  description = "RDS instance port"
  value       = aws_db_instance.webhook_receiver.port
}

output "db_instance_resource_id" {
  description = "RDS instance resource ID"
  value       = aws_db_instance.webhook_receiver.resource_id
}

output "db_instance_arn" {
  description = "RDS instance ARN"
  value       = aws_db_instance.webhook_receiver.arn
}
