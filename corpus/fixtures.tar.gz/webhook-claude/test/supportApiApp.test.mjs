import { test } from "node:test";
import assert from "node:assert/strict";
import { createSupportApiApp } from "../src/supportApiApp.mjs";
import { MemoryCallbackStore } from "../src/lib/storage/memoryCallbackStore.mjs";
import { FakeSingleSecretSource, startEphemeral } from "./fakes.mjs";

const API_KEY = "a-generated-support-team-api-key";
const silentLogger = { warn() {}, error() {}, info() {} };

async function seededStore() {
  const store = new MemoryCallbackStore();
  await store.recordIfNew("evt_lookup_1", {
    receivedAt: "2026-01-15T00:00:00.000Z",
    rawBodyBase64: Buffer.from(JSON.stringify({ event_id: "evt_lookup_1" })).toString("base64"),
    headers: {},
  });
  return store;
}

function buildApp(store, keySource = new FakeSingleSecretSource(API_KEY)) {
  return createSupportApiApp({ supportApiKeySource: keySource, store, logger: silentLogger });
}

test("support lookup with a valid API key returns the stored callback", async () => {
  const store = await seededStore();
  const { server, url } = startEphemeral(buildApp(store));
  try {
    const res = await fetch(url("/support/callbacks/evt_lookup_1"), {
      headers: { "x-support-api-key": API_KEY },
    });
    assert.equal(res.status, 200);
    const json = await res.json();
    assert.equal(json.eventId, "evt_lookup_1");
  } finally {
    server.close();
  }
});

test("support lookup with no API key is rejected with 401, not treated as a fault", async () => {
  const store = await seededStore();
  const { server, url } = startEphemeral(buildApp(store));
  try {
    const res = await fetch(url("/support/callbacks/evt_lookup_1"));
    assert.equal(res.status, 401);
  } finally {
    server.close();
  }
});

test("support lookup with a wrong API key is rejected with 401", async () => {
  const store = await seededStore();
  const { server, url } = startEphemeral(buildApp(store));
  try {
    const res = await fetch(url("/support/callbacks/evt_lookup_1"), {
      headers: { "x-support-api-key": "not-the-right-key" },
    });
    assert.equal(res.status, 401);
  } finally {
    server.close();
  }
});

test("support lookup for an event id that was never recorded is a 404, not a fault", async () => {
  const store = await seededStore();
  const { server, url } = startEphemeral(buildApp(store));
  try {
    const res = await fetch(url("/support/callbacks/evt_never_seen"), {
      headers: { "x-support-api-key": API_KEY },
    });
    assert.equal(res.status, 404);
  } finally {
    server.close();
  }
});
