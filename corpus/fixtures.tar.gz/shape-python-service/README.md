# shape-python-service

A small Flask event receiver. It exists as an agent-gate corpus fixture covering the Python project
shape, which the corpus otherwise has none of: decorator routes that do not authenticate, a
`requirements.txt` with no lockfile, and source that exercises the Python half of `build_check`
(`py_compile` and `ruff`).

Its test suite imports only the standard library, so it runs with nothing installed — the gate
never installs a project's dependencies, and a test importing Flask could not run on any machine
that had not already installed it. Three Go deliverables in this corpus shipped suites that fell
into exactly that trap.
