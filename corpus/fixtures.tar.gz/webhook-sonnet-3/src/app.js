import express from 'express';

import { createWebhookRouter } from './routes/webhook.js';
import { createCallbacksRouter } from './routes/callbacks.js';
import { createHealthRouter } from './routes/health.js';
import { errorHandler, notFoundHandler } from './errorHandler.js';

/**
 * Builds the Express application from its dependencies rather than reaching for real AWS clients
 * itself, so tests can supply fakes and the wiring to real infrastructure lives in one place
 * (server.js).
 */
export function createApp({ store, secretsProvider, signingSecretId, supportTokenSecretId }) {
  const app = express();
  app.disable('x-powered-by');

  app.use(createHealthRouter());
  app.use(createWebhookRouter({ store, secretsProvider, signingSecretId }));
  app.use(createCallbacksRouter({ store, secretsProvider, supportTokenSecretId }));

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
