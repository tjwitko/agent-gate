locals {
  # Two AZ suffixes rather than a data source lookup: aws_availability_zones has to call the EC2
  # API to enumerate what a region actually has, which makes it -- unlike everything else in this
  # configuration -- unplannable without live AWS credentials. "a"/"b" exist in every commercial
  # AWS region as of this writing; a region where that ever stops holding needs this list edited
  # once, which is a small, visible cost next to requiring real credentials just to run `plan`.
  azs = [for suffix in ["a", "b"] : "${var.aws_region}${suffix}"]
}

resource "aws_vpc" "this" {
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true
  enable_dns_support   = true
  tags                 = merge(local.tags, { Name = "${var.project_name}-vpc" })
}

resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id
  tags   = merge(local.tags, { Name = "${var.project_name}-igw" })
}

resource "aws_subnet" "public" {
  for_each          = { for idx, az in local.azs : tostring(idx) => az }
  vpc_id            = aws_vpc.this.id
  availability_zone = each.value
  cidr_block        = cidrsubnet(var.vpc_cidr, 4, tonumber(each.key))
  # Nothing is launched directly into these subnets by this stack -- the NAT gateway gets its own
  # EIP independent of this setting, and the load balancer the Service creates manages its own
  # public-facing ENIs. Off by default so anything added here later does not silently get a
  # public IP unless that is asked for explicitly.
  map_public_ip_on_launch = false

  tags = merge(local.tags, {
    Name                                        = "${var.project_name}-public-${each.value}"
    "kubernetes.io/role/elb"                    = "1"
    "kubernetes.io/cluster/${var.project_name}" = "shared"
  })
}

resource "aws_subnet" "private" {
  for_each          = { for idx, az in local.azs : tostring(idx) => az }
  vpc_id            = aws_vpc.this.id
  availability_zone = each.value
  cidr_block        = cidrsubnet(var.vpc_cidr, 4, tonumber(each.key) + 8)

  tags = merge(local.tags, {
    Name                                        = "${var.project_name}-private-${each.value}"
    "kubernetes.io/role/internal-elb"           = "1"
    "kubernetes.io/cluster/${var.project_name}" = "shared"
  })
}

# A single NAT gateway keeps this a two-AZ deployment without a NAT per AZ. It is a single point
# of failure for private-subnet egress (not for the service itself, which stays reachable through
# the load balancer and keeps running across AZs) -- an acceptable trade for this workload's size,
# revisited by adding a NAT per AZ if outbound availability across an AZ failure becomes a
# requirement.
resource "aws_eip" "nat" {
  domain = "vpc"
  tags   = merge(local.tags, { Name = "${var.project_name}-nat-eip" })
}

resource "aws_nat_gateway" "this" {
  allocation_id = aws_eip.nat.id
  subnet_id     = values(aws_subnet.public)[0].id
  tags          = merge(local.tags, { Name = "${var.project_name}-nat" })
  depends_on    = [aws_internet_gateway.this]
}

resource "aws_route_table" "public" {
  vpc_id = aws_vpc.this.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.this.id
  }

  tags = merge(local.tags, { Name = "${var.project_name}-public-rt" })
}

resource "aws_route_table_association" "public" {
  for_each       = aws_subnet.public
  subnet_id      = each.value.id
  route_table_id = aws_route_table.public.id
}

resource "aws_route_table" "private" {
  vpc_id = aws_vpc.this.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.this.id
  }

  tags = merge(local.tags, { Name = "${var.project_name}-private-rt" })
}

resource "aws_route_table_association" "private" {
  for_each       = aws_subnet.private
  subnet_id      = each.value.id
  route_table_id = aws_route_table.private.id
}
