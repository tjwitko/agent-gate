import express, { Request, Response } from "express";
import { randomUUID } from "crypto";
import { SignatureVerifier, SignatureVerificationError } from "./signature.js";
import { CallbackStore, InMemoryStore } from "./database.js";
import { SecretManager } from "./secrets.js";
import { Callback } from "./types.js";

const app = express();
app.use(express.json());

const store: CallbackStore = new InMemoryStore();
const verifier = new SignatureVerifier();
const secretManager = new SecretManager(verifier);

// Load secrets from environment (supports rotation via comma-separated list)
// Skip error on load if in test mode (secrets will be set by test setup)
try {
  secretManager.loadFromEnvironment();
} catch (error) {
  if (process.env.NODE_ENV !== "test") {
    console.error("Failed to load secrets:", error);
    process.exit(1);
  }
}

// Middleware to authenticate the provider via HMAC-SHA256 signature
function requireAuth(req: Request, res: Response, next: Function): void {
  const eventId = req.headers["x-event-id"] as string;
  const timestamp = req.headers["x-timestamp"] as string;
  const signature = req.headers["x-signature"] as string;

  // Validate required headers
  if (!eventId || !timestamp || !signature) {
    res.status(400).json({
      error: "Missing required headers: x-event-id, x-timestamp, x-signature",
    });
    return;
  }

  // Authenticate provider via HMAC-SHA256 signature verification
  try {
    verifier.verify(eventId, timestamp, signature, req.body);
    next();
  } catch (error) {
    if (error instanceof SignatureVerificationError) {
      res.status(401).json({ error: error.message });
    } else {
      console.error("Unexpected error in signature verification:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  }
}

// Middleware to authenticate support team access via bearer token
function requireAuth_SupportTeam(req: Request, res: Response, next: Function): void {
  const authHeader = req.headers.authorization as string;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

// Health endpoint (public, for load balancer)
app.get("/health", (req: Request, res: Response) => {
  res.json({ status: "healthy" });
});

// Webhook callback endpoint (authenticated provider)
app.post("/webhook", requireAuth, async (req: Request, res: Response) => {
  try {
    const eventId = req.headers["x-event-id"] as string;

    // Check if already received
    if (await store.exists(eventId)) {
      return res.status(409).json({
        error: "Callback with this event id already recorded",
      });
    }

    // Store callback
    const callback: Callback = {
      id: randomUUID(),
      eventId,
      receivedAt: new Date(),
      body: req.body,
    };

    await store.save(callback);

    res.status(202).json({ id: callback.id, eventId });
  } catch (error) {
    console.error("Error processing webhook:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Lookup endpoint for support team (authenticated)
app.get("/callbacks/:eventId", requireAuth_SupportTeam, async (req: Request, res: Response) => {
  const { eventId } = req.params;

  const callback = await store.getByEventId(eventId);
  if (!callback) {
    return res.status(404).json({ error: "Callback not found" });
  }
  res.json(callback);
});

function start(): void {
  const PORT = parseInt(process.env.PORT || "3000", 10);
  return app.listen(PORT, () => {
    console.log(`Webhook receiver listening on port ${PORT}`);
  }) as unknown as void;
}

// Start server if running directly (not imported for testing)
const isDirectRun = process.argv[1]?.endsWith("server.js");
if (isDirectRun) {
  start();
}

export { app, store, verifier, start };
