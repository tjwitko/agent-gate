import pkg from 'pg';
const { Pool } = pkg;

const connectionString = process.env.DATABASE_URL;
if (!connectionString && process.env.NODE_ENV !== 'test') {
  throw new Error('DATABASE_URL environment variable is required');
}

const pool = new Pool({
  connectionString: connectionString || 'postgresql://user:password@localhost/webhook_db'
});

export async function initDatabase() {
  const client = await pool.connect();
  try {
    // Create webhooks table with immutable constraints
    await client.query(`
      CREATE TABLE IF NOT EXISTS webhooks (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        event_id VARCHAR(255) UNIQUE NOT NULL,
        payload JSONB NOT NULL,
        signature VARCHAR(255) NOT NULL,
        timestamp VARCHAR(255) NOT NULL,
        received_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
        retention_until TIMESTAMP WITH TIME ZONE NOT NULL
      );
    `);

    // Create index for event_id lookups
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_event_id ON webhooks(event_id);
    `);

    // Create immutable constraint - prevent updates
    await client.query(`
      CREATE OR REPLACE FUNCTION prevent_webhook_update()
      RETURNS TRIGGER AS $$
      BEGIN
        RAISE EXCEPTION 'Webhooks are immutable and cannot be updated';
      END;
      $$ LANGUAGE plpgsql;
    `);

    await client.query(`
      DROP TRIGGER IF EXISTS webhook_update_trigger ON webhooks;
    `);

    await client.query(`
      CREATE TRIGGER webhook_update_trigger
      BEFORE UPDATE ON webhooks
      FOR EACH ROW
      EXECUTE FUNCTION prevent_webhook_update();
    `);

    // Create immutable constraint - prevent deletes
    await client.query(`
      CREATE OR REPLACE FUNCTION prevent_webhook_delete()
      RETURNS TRIGGER AS $$
      BEGIN
        RAISE EXCEPTION 'Webhooks are immutable and cannot be deleted';
      END;
      $$ LANGUAGE plpgsql;
    `);

    await client.query(`
      DROP TRIGGER IF EXISTS webhook_delete_trigger ON webhooks;
    `);

    await client.query(`
      CREATE TRIGGER webhook_delete_trigger
      BEFORE DELETE ON webhooks
      FOR EACH ROW
      EXECUTE FUNCTION prevent_webhook_delete();
    `);

    // Revoke dangerous permissions from application role
    await client.query(`
      DO $$
      BEGIN
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'webhook') THEN
          REVOKE UPDATE ON webhooks FROM webhook;
          REVOKE DELETE ON webhooks FROM webhook;
          REVOKE TRUNCATE ON webhooks FROM webhook;
        END IF;
      END
      $$;
    `);
  } finally {
    client.release();
  }
}

export async function getPool() {
  return pool;
}

export async function closePool() {
  await pool.end();
}
