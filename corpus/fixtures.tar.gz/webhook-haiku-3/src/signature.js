import crypto from 'crypto';
import { getCurrentSecrets } from './secrets.js';

export async function verifySignature(body, providedSignature, timestamp) {
  const bodyString = JSON.stringify(body);
  const message = `${timestamp}.${bodyString}`;

  const secrets = await getCurrentSecrets();

  // Try current and previous secrets (in case of rotation)
  for (const secret of secrets) {
    const computed = crypto
      .createHmac('sha256', secret)
      .update(message)
      .digest('hex');

    if (crypto.timingSafeEqual(computed, providedSignature)) {
      return true;
    }
  }

  return false;
}
