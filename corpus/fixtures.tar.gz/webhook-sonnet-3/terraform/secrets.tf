# Bootstrap values only. Terraform creates each secret and gives it an initial version so the
# application has something to read on first deploy; actual rotation is performed out-of-band
# (whatever process the provider relationship uses to hand over a new signing secret each quarter)
# by writing a new version directly, moving the current value to `previous`. The `ignore_changes`
# below is what keeps Terraform from stomping that on the next apply.

resource "random_password" "initial_signing_secret" {
  length  = 64
  special = false
}

resource "aws_secretsmanager_secret" "signing_secret" {
  name        = "${var.project_name}/signing-secret"
  description = "Current and previous HMAC signing secrets used to verify payment provider callbacks. The provider rotates this quarterly."
  kms_key_id  = aws_kms_key.app.id

  recovery_window_in_days = 30
  tags                    = local.tags
}

resource "aws_secretsmanager_secret_version" "signing_secret" {
  secret_id = aws_secretsmanager_secret.signing_secret.id
  secret_string = jsonencode({
    current  = random_password.initial_signing_secret.result
    previous = null
  })

  lifecycle {
    ignore_changes = [secret_string]
  }
}

resource "random_password" "initial_support_token" {
  length  = 48
  special = false
}

resource "aws_secretsmanager_secret" "support_token" {
  name        = "${var.project_name}/support-token"
  description = "Bearer token the support team's tooling presents to look up a past callback by event id."
  kms_key_id  = aws_kms_key.app.id

  recovery_window_in_days = 30
  tags                    = local.tags
}

resource "aws_secretsmanager_secret_version" "support_token" {
  secret_id     = aws_secretsmanager_secret.support_token.id
  secret_string = random_password.initial_support_token.result

  lifecycle {
    ignore_changes = [secret_string]
  }
}
