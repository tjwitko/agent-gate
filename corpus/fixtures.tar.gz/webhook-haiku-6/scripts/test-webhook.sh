#!/bin/bash

# Test script for webhook receiver
# Tests signature verification, immutability, and error handling

set -e

BASE_URL="${1:-http://localhost:8080}"
SECRET="${2:-test-secret}"
SUPPORT_TOKEN="${3:-test-support-token}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${YELLOW}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

log_error() {
    echo -e "${RED}[FAIL]${NC} $1"
}

# Helper to compute HMAC-SHA256 signature
compute_signature() {
    local payload="$1"
    local secret="$2"
    echo -n "$payload" | openssl dgst -sha256 -hmac "$secret" | awk '{print $2}'
}

# Test 1: Health endpoint
test_health() {
    log_info "Testing health endpoint..."
    response=$(curl -s -w "\n%{http_code}" "$BASE_URL/health")
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | head -n-1)

    if [ "$http_code" = "200" ]; then
        if echo "$body" | grep -q "healthy"; then
            log_success "Health endpoint returns 200 with healthy status"
        else
            log_error "Health endpoint returned 200 but status is not healthy"
            return 1
        fi
    else
        log_error "Health endpoint returned $http_code (expected 200)"
        return 1
    fi
}

# Test 2: Accept valid webhook
test_valid_webhook() {
    log_info "Testing valid webhook acceptance..."

    event_id="evt_test_$(date +%s%N)"
    payload="{\"event_id\":\"$event_id\",\"amount\":1000,\"timestamp\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}"
    signature=$(compute_signature "$payload" "$SECRET")

    response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/webhook" \
        -H "X-Webhook-Signature: $signature" \
        -H "Content-Type: application/json" \
        -d "$payload")

    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | head -n-1)

    if [ "$http_code" = "202" ]; then
        if echo "$body" | grep -q "accepted"; then
            log_success "Valid webhook accepted with 202 status"
            echo "$event_id"
        else
            log_error "Valid webhook returned 202 but status is not accepted"
            return 1
        fi
    else
        log_error "Valid webhook returned $http_code (expected 202)"
        return 1
    fi
}

# Test 3: Reject forged webhook
test_forged_webhook() {
    log_info "Testing forged webhook rejection..."

    event_id="evt_forged_$(date +%s%N)"
    payload="{\"event_id\":\"$event_id\",\"amount\":2000}"
    forged_signature="invalidsignaturebadformat"

    response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/webhook" \
        -H "X-Webhook-Signature: $forged_signature" \
        -H "Content-Type: application/json" \
        -d "$payload")

    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | head -n-1)

    if [ "$http_code" = "401" ]; then
        if echo "$body" | grep -q "invalid signature"; then
            log_success "Forged webhook rejected with 401 status"
        else
            log_error "Forged webhook returned 401 but error message incorrect"
            return 1
        fi
    else
        log_error "Forged webhook returned $http_code (expected 401)"
        return 1
    fi
}

# Test 4: Reject missing signature
test_missing_signature() {
    log_info "Testing missing signature rejection..."

    payload='{"event_id":"evt_nosig","amount":3000}'

    response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/webhook" \
        -H "Content-Type: application/json" \
        -d "$payload")

    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | head -n-1)

    if [ "$http_code" = "401" ]; then
        if echo "$body" | grep -q "missing signature"; then
            log_success "Missing signature rejected with 401 status"
        else
            log_error "Missing signature returned 401 but error message incorrect"
            return 1
        fi
    else
        log_error "Missing signature returned $http_code (expected 401)"
        return 1
    fi
}

# Test 5: Repeated callback not overwritten
test_repeated_callback() {
    log_info "Testing repeated callback immutability..."

    event_id="evt_repeat_$(date +%s%N)"
    payload1="{\"event_id\":\"$event_id\",\"amount\":1000,\"timestamp\":\"2026-09-03T10:00:00Z\"}"
    signature1=$(compute_signature "$payload1" "$SECRET")

    # First submission
    response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/webhook" \
        -H "X-Webhook-Signature: $signature1" \
        -H "Content-Type: application/json" \
        -d "$payload1")

    http_code=$(echo "$response" | tail -n1)
    if [ "$http_code" != "202" ]; then
        log_error "First submission failed with $http_code"
        return 1
    fi

    sleep 1

    # Second submission with different content
    payload2="{\"event_id\":\"$event_id\",\"amount\":2000,\"timestamp\":\"2026-09-03T10:00:10Z\"}"
    signature2=$(compute_signature "$payload2" "$SECRET")

    response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/webhook" \
        -H "X-Webhook-Signature: $signature2" \
        -H "Content-Type: application/json" \
        -d "$payload2")

    http_code=$(echo "$response" | tail -n1)
    if [ "$http_code" != "202" ]; then
        log_error "Second submission failed with $http_code"
        return 1
    fi

    # Query the stored event with authorization
    response=$(curl -s -w "\n%{http_code}" -H "Authorization: Bearer $SUPPORT_TOKEN" "$BASE_URL/lookup?event_id=$event_id")
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | head -n-1)

    if [ "$http_code" = "200" ]; then
        if echo "$body" | grep -q "1000"; then
            log_success "Repeated callback prevented overwrite - original data preserved"
        else
            log_error "Repeated callback overwritten - original data lost"
            return 1
        fi
    else
        log_error "Lookup failed with $http_code"
        return 1
    fi
}

# Test 6: Invalid JSON rejection
test_invalid_json() {
    log_info "Testing invalid JSON rejection..."

    payload="not valid json"
    signature=$(compute_signature "$payload" "$SECRET")

    response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/webhook" \
        -H "X-Webhook-Signature: $signature" \
        -H "Content-Type: application/json" \
        -d "$payload")

    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | head -n-1)

    if [ "$http_code" = "400" ]; then
        if echo "$body" | grep -q "invalid json"; then
            log_success "Invalid JSON rejected with 400 status and error classification as client_error"
        else
            log_error "Invalid JSON returned 400 but error message incorrect"
            return 1
        fi
    else
        log_error "Invalid JSON returned $http_code (expected 400)"
        return 1
    fi
}

# Test 7: Missing event_id rejection
test_missing_event_id() {
    log_info "Testing missing event_id rejection..."

    payload='{"amount":1000}'
    signature=$(compute_signature "$payload" "$SECRET")

    response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/webhook" \
        -H "X-Webhook-Signature: $signature" \
        -H "Content-Type: application/json" \
        -d "$payload")

    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | head -n-1)

    if [ "$http_code" = "400" ]; then
        if echo "$body" | grep -q "missing or invalid event_id"; then
            log_success "Missing event_id rejected with 400 status"
        else
            log_error "Missing event_id returned 400 but error message incorrect"
            return 1
        fi
    else
        log_error "Missing event_id returned $http_code (expected 400)"
        return 1
    fi
}

# Test 8: Lookup requires authentication
test_lookup_authentication() {
    log_info "Testing lookup endpoint authentication..."

    response=$(curl -s -w "\n%{http_code}" "$BASE_URL/lookup?event_id=evt_test")
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | head -n-1)

    if [ "$http_code" = "401" ]; then
        if echo "$body" | grep -q "missing authorization"; then
            log_success "Lookup endpoint requires authentication"
        else
            log_error "Lookup returned 401 but error message incorrect"
            return 1
        fi
    else
        log_error "Lookup without auth returned $http_code (expected 401)"
        return 1
    fi
}

# Run all tests
main() {
    log_info "Starting webhook receiver tests against $BASE_URL"
    log_info "Using secret: $SECRET"
    echo ""

    test_health || true
    echo ""

    test_valid_webhook || true
    echo ""

    test_forged_webhook || true
    echo ""

    test_missing_signature || true
    echo ""

    test_repeated_callback || true
    echo ""

    test_invalid_json || true
    echo ""

    test_missing_event_id || true
    echo ""

    test_lookup_authentication || true
    echo ""

    log_info "Test suite completed"
}

main "$@"
