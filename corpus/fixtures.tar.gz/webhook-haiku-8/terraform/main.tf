terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
  skip_credentials_validation = true
  skip_requesting_account_id = true
  skip_metadata_api_check = true
}

locals {
  app_name = "webhook-receiver"
  retention_years = 7
}

# S3 bucket for immutable webhook payloads with COMPLIANCE-mode object lock
resource "aws_s3_bucket" "webhook_payloads" {
  bucket              = "${local.app_name}-payloads-${var.aws_account_id}"
  object_lock_enabled = true

  tags = {
    Name        = "${local.app_name}-payloads"
    Environment = var.environment
  }

  lifecycle {
    prevent_destroy = true
  }
}

resource "aws_s3_bucket_object_lock_configuration" "webhook_payloads" {
  bucket = aws_s3_bucket.webhook_payloads.id

  depends_on = [aws_s3_bucket_versioning.webhook_payloads]

  rule {
    default_retention {
      mode = "COMPLIANCE"
      days = local.retention_years * 365
    }
  }
}

resource "aws_s3_bucket_versioning" "webhook_payloads" {
  bucket = aws_s3_bucket.webhook_payloads.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "webhook_payloads" {
  bucket = aws_s3_bucket.webhook_payloads.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "webhook_payloads" {
  bucket = aws_s3_bucket.webhook_payloads.id

  rule {
    id     = "archive-old-webhooks"
    status = "Enabled"

    noncurrent_version_transition {
      noncurrent_days = 90
      storage_class   = "GLACIER"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "webhook_payloads" {
  bucket = aws_s3_bucket.webhook_payloads.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# DynamoDB table for webhook index - records retained for 7 years minimum
resource "aws_dynamodb_table" "webhook_index" {
  name             = "${local.app_name}-index"
  billing_mode     = "PAY_PER_REQUEST"
  hash_key         = "event_id"
  stream_view_type = "NEW_AND_OLD_IMAGES"

  attribute {
    name = "event_id"
    type = "S"
  }

  attribute {
    name = "event_type"
    type = "S"
  }

  attribute {
    name = "received_at"
    type = "N"
  }

  global_secondary_index {
    name            = "event_type_received_at"
    hash_key        = "event_type"
    range_key       = "received_at"
    projection_type = "ALL"
  }

  point_in_time_recovery {
    enabled = true
  }

  tags = {
    Name        = "${local.app_name}-index"
    Environment = var.environment
  }

  lifecycle {
    prevent_destroy = true
  }
}

# IAM role for webhook receiver service
resource "aws_iam_role" "webhook_receiver" {
  name = "${local.app_name}-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          AWS = "arn:aws:iam::${var.aws_account_id}:root"
        }
      }
    ]
  })

  tags = {
    Environment = var.environment
  }
}

# S3 permissions for webhook payloads
resource "aws_iam_role_policy" "webhook_receiver_s3" {
  name = "${local.app_name}-s3-policy"
  role = aws_iam_role.webhook_receiver.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "s3:PutObject",
          "s3:GetObject"
        ]
        Resource = "${aws_s3_bucket.webhook_payloads.arn}/*"
        Condition = {
          StringEquals = {
            "s3:x-amz-acl" = "private"
          }
        }
      },
      {
        Effect = "Allow"
        Action = [
          "s3:ListBucket"
        ]
        Resource = aws_s3_bucket.webhook_payloads.arn
      }
    ]
  })
}

# DynamoDB permissions for webhook index
resource "aws_iam_role_policy" "webhook_receiver_dynamodb" {
  name = "${local.app_name}-dynamodb-policy"
  role = aws_iam_role.webhook_receiver.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "dynamodb:GetItem",
          "dynamodb:PutItem",
          "dynamodb:Query"
        ]
        Resource = aws_dynamodb_table.webhook_index.arn
      },
      {
        Effect = "Allow"
        Action = [
          "dynamodb:Query"
        ]
        Resource = "${aws_dynamodb_table.webhook_index.arn}/index/*"
      }
    ]
  })
}

# ECR repository for container image
resource "aws_ecr_repository" "webhook_receiver" {
  name                 = local.app_name
  image_tag_mutability = "IMMUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  encryption_configuration {
    encryption_type = "AES256"
  }

  tags = {
    Environment = var.environment
  }
}

resource "aws_ecr_lifecycle_policy" "webhook_receiver" {
  repository = aws_ecr_repository.webhook_receiver.name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Keep last 10 images"
        selection = {
          tagStatus     = "tagged"
          tagPrefixList = ["v"]
          countType     = "imageCountMoreThan"
          countNumber   = 10
        }
        action = {
          type = "expire"
        }
      }
    ]
  })
}

