import { Pool } from 'pg';

interface StoredWebhookRecord {
  id: string;
  event_id: string;
  provider_id: string;
  payload: string;
  signature: string;
  received_at: Date;
}

interface ProviderSecret {
  value: string;
  createdAt: Date;
  rotatesAt?: Date;
}

export class Database {
  private pool: Pool;

  constructor() {
    this.pool = new Pool({
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '5432'),
      database: process.env.DB_NAME || 'webhook_receiver',
      user: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASSWORD || 'postgres',
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000
    });
  }

  async initialize(): Promise<void> {
    const client = await this.pool.connect();
    try {
      // Create webhooks table with immutability enforced at DB level
      await client.query(`
        CREATE TABLE IF NOT EXISTS webhooks (
          id UUID PRIMARY KEY,
          event_id VARCHAR(255) NOT NULL,
          provider_id VARCHAR(255) NOT NULL,
          payload TEXT NOT NULL,
          signature TEXT NOT NULL,
          received_at TIMESTAMP NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
          UNIQUE(event_id, provider_id)
        );

        CREATE INDEX IF NOT EXISTS idx_webhooks_event_id ON webhooks(event_id);
        CREATE INDEX IF NOT EXISTS idx_webhooks_provider_id ON webhooks(provider_id);
        CREATE INDEX IF NOT EXISTS idx_webhooks_received_at ON webhooks(received_at);
      `);

      // Create trigger to prevent updates and deletes on webhooks
      await client.query(`
        CREATE OR REPLACE FUNCTION prevent_webhook_modification() RETURNS TRIGGER AS $$
        BEGIN
          RAISE EXCEPTION 'Webhooks are immutable and cannot be modified or deleted';
        END;
        $$ LANGUAGE plpgsql;

        DROP TRIGGER IF EXISTS prevent_webhook_update ON webhooks;
        CREATE TRIGGER prevent_webhook_update
        BEFORE UPDATE ON webhooks
        FOR EACH ROW
        EXECUTE FUNCTION prevent_webhook_modification();

        DROP TRIGGER IF EXISTS prevent_webhook_delete ON webhooks;
        CREATE TRIGGER prevent_webhook_delete
        BEFORE DELETE ON webhooks
        FOR EACH ROW
        EXECUTE FUNCTION prevent_webhook_modification();
      `);

      // Create provider secrets table
      await client.query(`
        CREATE TABLE IF NOT EXISTS provider_secrets (
          id SERIAL PRIMARY KEY,
          provider_id VARCHAR(255) NOT NULL,
          secret_value TEXT NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
          rotates_at TIMESTAMP,
          is_active BOOLEAN DEFAULT true NOT NULL,
          UNIQUE(provider_id, secret_value)
        );

        CREATE INDEX IF NOT EXISTS idx_provider_secrets_provider_id
          ON provider_secrets(provider_id);
        CREATE INDEX IF NOT EXISTS idx_provider_secrets_active
          ON provider_secrets(provider_id, is_active);
      `);

      // Create support team API keys table
      await client.query(`
        CREATE TABLE IF NOT EXISTS support_team_api_keys (
          id SERIAL PRIMARY KEY,
          key_hash VARCHAR(255) NOT NULL UNIQUE,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
          revoked_at TIMESTAMP
        );

        CREATE INDEX IF NOT EXISTS idx_api_keys_active
          ON support_team_api_keys(key_hash) WHERE revoked_at IS NULL;
      `);

      // Create provider API keys table
      await client.query(`
        CREATE TABLE IF NOT EXISTS provider_api_keys (
          id SERIAL PRIMARY KEY,
          provider_id VARCHAR(255) NOT NULL,
          key_hash VARCHAR(255) NOT NULL UNIQUE,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
          revoked_at TIMESTAMP
        );

        CREATE INDEX IF NOT EXISTS idx_provider_api_keys_active
          ON provider_api_keys(provider_id, key_hash) WHERE revoked_at IS NULL;
      `);

      // Create audit log table for immutability verification
      await client.query(`
        CREATE TABLE IF NOT EXISTS webhook_audit_log (
          id SERIAL PRIMARY KEY,
          webhook_id UUID NOT NULL,
          action VARCHAR(50) NOT NULL,
          timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
          CONSTRAINT fk_webhook FOREIGN KEY (webhook_id) REFERENCES webhooks(id)
        );
      `);

      console.log('Database schema initialized successfully');
    } finally {
      client.release();
    }
  }

  async ping(): Promise<void> {
    const result = await this.pool.query('SELECT NOW()');
    if (!result.rows[0]) {
      throw new Error('Database ping failed');
    }
  }

  async storeWebhook(webhook: {
    id: string;
    eventId: string;
    providerId: string;
    payload: string;
    signature: string;
    receivedAt: Date;
  }): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');

      await client.query(
        `INSERT INTO webhooks (id, event_id, provider_id, payload, signature, received_at)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [webhook.id, webhook.eventId, webhook.providerId, webhook.payload, webhook.signature, webhook.receivedAt]
      );

      // Log the audit entry
      await client.query(
        `INSERT INTO webhook_audit_log (webhook_id, action) VALUES ($1, 'CREATED')`,
        [webhook.id]
      );

      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async getWebhookByEventId(eventId: string, providerId?: string): Promise<any | null> {
    let query = 'SELECT * FROM webhooks WHERE event_id = $1';
    const params: any[] = [eventId];

    if (providerId) {
      query += ' AND provider_id = $2';
      params.push(providerId);
    }

    const result = await this.pool.query(query, params);
    if (result.rows.length === 0) {
      return null;
    }

    const row = result.rows[0];
    return {
      id: row.id,
      eventId: row.event_id,
      providerId: row.provider_id,
      payload: row.payload,
      signature: row.signature,
      receivedAt: row.received_at
    };
  }

  async getProviderSecrets(providerId: string): Promise<ProviderSecret[]> {
    const result = await this.pool.query(
      `SELECT secret_value, created_at, rotates_at FROM provider_secrets
       WHERE provider_id = $1 AND is_active = true
       ORDER BY created_at DESC`,
      [providerId]
    );

    return result.rows.map(row => ({
      value: row.secret_value,
      createdAt: row.created_at,
      rotatesAt: row.rotates_at
    }));
  }

  async addProviderSecret(providerId: string, secret: string, rotatesAt?: Date): Promise<void> {
    await this.pool.query(
      `INSERT INTO provider_secrets (provider_id, secret_value, rotates_at)
       VALUES ($1, $2, $3)`,
      [providerId, secret, rotatesAt]
    );
  }

  async validateSupportTeamApiKey(key: string): Promise<boolean> {
    const crypto = require('crypto');
    const keyHash = crypto.createHash('sha256').update(key).digest('hex');

    const result = await this.pool.query(
      `SELECT key_hash FROM support_team_api_keys
       WHERE revoked_at IS NULL`,
    );

    // Constant-time comparison: iterate through all keys to prevent timing leak
    for (const row of result.rows) {
      try {
        if (crypto.timingSafeEqual(Buffer.from(keyHash), Buffer.from(row.key_hash))) {
          return true;
        }
      } catch {
        continue;
      }
    }

    return false;
  }

  async addSupportTeamApiKey(key: string): Promise<void> {
    const crypto = require('crypto');
    const keyHash = crypto.createHash('sha256').update(key).digest('hex');

    await this.pool.query(
      `INSERT INTO support_team_api_keys (key_hash) VALUES ($1)`,
      [keyHash]
    );
  }

  async validateProviderApiKey(key: string): Promise<boolean> {
    const crypto = require('crypto');
    const keyHash = crypto.createHash('sha256').update(key).digest('hex');

    const result = await this.pool.query(
      `SELECT key_hash FROM provider_api_keys
       WHERE revoked_at IS NULL`,
    );

    // Constant-time comparison: iterate through all keys to prevent timing leak
    for (const row of result.rows) {
      try {
        if (crypto.timingSafeEqual(Buffer.from(keyHash), Buffer.from(row.key_hash))) {
          return true;
        }
      } catch {
        continue;
      }
    }

    return false;
  }

  async addProviderApiKey(providerId: string, key: string): Promise<void> {
    const crypto = require('crypto');
    const keyHash = crypto.createHash('sha256').update(key).digest('hex');

    await this.pool.query(
      `INSERT INTO provider_api_keys (provider_id, key_hash) VALUES ($1, $2)`,
      [providerId, keyHash]
    );
  }

  async close(): Promise<void> {
    await this.pool.end();
  }
}
