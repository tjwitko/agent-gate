aws_region = "us-east-1"
aws_account_id = "123456789012"
environment = "production"
