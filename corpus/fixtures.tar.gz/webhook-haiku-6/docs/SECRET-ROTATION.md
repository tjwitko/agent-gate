# Secret Rotation Guide

## Current Implementation

The webhook receiver reads secrets from environment variables:
- `WEBHOOK_SECRET`: Provider's signing key
- `SUPPORT_TOKEN`: Authentication token for support team

## Rotation Process

### Provider Signing Secret Rotation

The payment provider rotates its signing secret quarterly. To handle rotation without downtime:

### Option 1: Graceful Multi-Secret Support (Recommended)

Modify the application to accept both old and new secrets during a transition period:

```go
func verifySignature(body []byte, signature string) bool {
	currentSecret := os.Getenv("WEBHOOK_SECRET")
	previousSecret := os.Getenv("WEBHOOK_SECRET_PREVIOUS")
	
	// Try current secret first
	if verifyWithSecret(body, signature, currentSecret) {
		return true
	}
	
	// Fall back to previous secret during rotation window
	if previousSecret != "" && verifyWithSecret(body, signature, previousSecret) {
		return true
	}
	
	return false
}
```

**Steps:**
1. When provider announces rotation schedule, add new secret as `WEBHOOK_SECRET_NEW`
2. Update application and deploy (accepts both old and new)
3. After provider rotates (or in parallel), update `WEBHOOK_SECRET` to new value
4. Keep `WEBHOOK_SECRET_PREVIOUS` until rotation window closes
5. Remove old secret reference after window closes

### Option 2: Kubernetes Secret Rotation + Pod Restart

Use a secret rotation tool that:
1. Updates Kubernetes secret with new value
2. Triggers pod restart (via deployment annotation change)
3. New pods pick up rotated secret

**Tools:**
- External Secrets Operator
- Sealed Secrets with auto-rotation
- AWS Secrets Manager with EventBridge triggering pod restart

### Option 3: Hot-Reload Configuration

Implement a configuration endpoint or file watcher:
1. Application periodically reads secrets from external store (AWS Secrets Manager)
2. No restart needed when secrets rotate
3. Read-through caching for performance

**Implementation example using AWS Secrets Manager:**
```go
var webhookSecret string

func init() {
	// Refresh secret every 5 minutes
	ticker := time.NewTicker(5 * time.Minute)
	go func() {
		for range ticker.C {
			refreshSecret()
		}
	}()
	
	refreshSecret()
}

func refreshSecret() {
	// Fetch from AWS Secrets Manager
	secret := getFromSecretsManager("webhook-receiver/webhook-secret")
	webhookSecret = secret
}

func handleWebhook(w http.ResponseWriter, r *http.Request) {
	if !verifySignature(body, signature, webhookSecret) {
		// reject
	}
	// accept
}
```

## Support Team Token Rotation

The `SUPPORT_TOKEN` used for lookup authentication should be rotated periodically (e.g., quarterly):

1. Generate new token
2. Deploy with both old and new token (comma-separated or alternative variable)
3. After rotation window, remove old token
4. Support team uses new token for authentication

**Implementation:**
```go
validTokens := strings.Split(os.Getenv("SUPPORT_TOKENS"), ",")
for _, token := range validTokens {
	if hmac.Equal([]byte(authToken), []byte("Bearer "+strings.TrimSpace(token))) {
		return true
	}
}
```

## Testing Secret Changes

After rotating secrets:

1. Test old secret is rejected (if removed)
2. Test new secret is accepted
3. Monitor logs for authentication failures
4. Verify webhooks continue to be received and stored

```bash
# Test with old secret (should fail after rotation)
PAYLOAD='{"event_id":"test123","amount":1000}'
SIGNATURE=$(echo -n "$PAYLOAD" | openssl dgst -sha256 -hmac "old-secret" | cut -d' ' -f2)
curl -X POST http://localhost:8080/webhook \
  -H "X-Webhook-Signature: $SIGNATURE" \
  -d "$PAYLOAD"
# Should return 401

# Test with new secret (should succeed)
SIGNATURE=$(echo -n "$PAYLOAD" | openssl dgst -sha256 -hmac "new-secret" | cut -d' ' -f2)
curl -X POST http://localhost:8080/webhook \
  -H "X-Webhook-Signature: $SIGNATURE" \
  -d "$PAYLOAD"
# Should return 202
```

## Recommended Approach

Use **Option 3 (Hot-Reload)** with AWS Secrets Manager for production:
- No downtime during secret rotation
- Automatic rotation with manager-managed secrets
- Audit trail of all secret access
- Integrates with AWS security best practices
- Can be extended to handle key rotation as well
