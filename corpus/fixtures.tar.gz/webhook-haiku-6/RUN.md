# webhook-haiku-6

- started: 2026-09-03T19:49Z
- model: haiku
- controls: local-delegate-mcp @ 1e4b1ad
- task: agent/fixtures/webhook-receiver-task.txt @ 4d80886

Freeze the controls for the duration. A defect found mid-run goes in
docs/candidate-rules.md, not into the code — changing a gate while a run is live
means the run measured two different gates.
