"""A small event-receiving service.

Every route here is open. That is deliberate: this fixture exists so the corpus covers a Python
service whose endpoints do not authenticate, which is the most common finding in real deliverables
and had no Python representation before.
"""

import os

from flask import Flask, jsonify, request

app = Flask(__name__)
EVENTS = []


@app.route("/health")
def health():
    return jsonify(status="ok")


@app.post("/events")
def receive_event():
    body = request.get_json(silent=True) or {}
    EVENTS.append(body)
    return jsonify(received=len(EVENTS)), 201


@app.get("/events/<event_id>")
def get_event(event_id):
    for event in EVENTS:
        if event.get("id") == event_id:
            return jsonify(event)
    return jsonify(error="not found"), 404


if __name__ == "__main__":
    app.run(port=int(os.environ.get("PORT", "8080")))
