terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

locals {
  service_name = "webhook-receiver"
  environment  = var.environment
  tags = {
    Service     = local.service_name
    Environment = local.environment
    ManagedBy   = "Terraform"
  }
}

module "vpc" {
  source = "./modules/vpc"

  environment      = var.environment
  vpc_cidr         = var.vpc_cidr
  availability_zones = var.availability_zones

  tags = local.tags
}

module "security_groups" {
  source = "./modules/security_groups"

  environment = var.environment
  vpc_id      = module.vpc.vpc_id
  vpc_cidr    = var.vpc_cidr

  tags = local.tags
}

module "rds" {
  source = "./modules/rds"

  environment          = var.environment
  db_subnet_group_name = module.vpc.db_subnet_group_name
  db_security_group_id = module.security_groups.db_security_group_id

  db_name     = var.db_name
  db_username = var.db_username
  db_password = var.db_password

  retention_days = var.retention_days
  backup_window  = var.backup_window

  tags = local.tags

  depends_on = [module.vpc]
}

module "eks" {
  source = "./modules/eks"

  environment              = var.environment
  vpc_id                   = module.vpc.vpc_id
  subnet_ids               = module.vpc.private_subnet_ids
  control_plane_subnet_ids = module.vpc.private_subnet_ids

  eks_cluster_name    = local.service_name
  eks_cluster_version = var.eks_cluster_version

  node_group_desired_size = var.node_group_desired_size
  node_group_min_size     = var.node_group_min_size
  node_group_max_size     = var.node_group_max_size
  node_instance_types     = var.node_instance_types

  tags = local.tags

  depends_on = [module.vpc]
}

output "rds_endpoint" {
  description = "RDS database endpoint"
  value       = module.rds.db_instance_endpoint
}

output "rds_port" {
  description = "RDS database port"
  value       = module.rds.db_instance_port
}

output "eks_cluster_name" {
  description = "EKS cluster name"
  value       = module.eks.cluster_name
}

output "eks_cluster_endpoint" {
  description = "EKS cluster API endpoint"
  value       = module.eks.cluster_endpoint
}

output "eks_cluster_ca_certificate" {
  description = "EKS cluster CA certificate"
  value       = module.eks.cluster_certificate_authority_data
  sensitive   = true
}
