import { createHmac } from 'crypto';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';

let secretsCache = {};
let lastCacheFetch = 0;
const CACHE_TTL = 3600000; // 1 hour

const client = new SecretsManagerClient();

async function fetchSecretsFromManager() {
  const now = Date.now();

  // Return cached secrets if still valid
  if (secretsCache.current && (now - lastCacheFetch) < CACHE_TTL) {
    return secretsCache;
  }

  try {
    // Fetch signing secret
    if (process.env.SIGNING_SECRET_NAME) {
      const signingCmd = new GetSecretValueCommand({
        SecretId: process.env.SIGNING_SECRET_NAME,
      });
      const signingResp = await client.send(signingCmd);
      secretsCache.current = JSON.parse(signingResp.SecretString).value;
    }

    // Fetch previous signing secret if it exists
    if (process.env.PREVIOUS_SIGNING_SECRET_NAME) {
      try {
        const prevCmd = new GetSecretValueCommand({
          SecretId: process.env.PREVIOUS_SIGNING_SECRET_NAME,
        });
        const prevResp = await client.send(prevCmd);
        secretsCache.previous = JSON.parse(prevResp.SecretString).value;
      } catch (e) {
        // Previous secret might not exist yet
        secretsCache.previous = null;
      }
    }

    // Fetch support auth token
    if (process.env.SUPPORT_AUTH_TOKEN_NAME) {
      const tokenCmd = new GetSecretValueCommand({
        SecretId: process.env.SUPPORT_AUTH_TOKEN_NAME,
      });
      const tokenResp = await client.send(tokenCmd);
      secretsCache.token = JSON.parse(tokenResp.SecretString).value;
    }

    lastCacheFetch = now;
  } catch (e) {
    console.error('Error fetching secrets from Secrets Manager:', e);
    // Fall back to environment variables on error
  }

  return secretsCache;
}

export async function getCurrentSigningKey() {
  const secrets = await fetchSecretsFromManager();
  return secrets.current || process.env.SIGNING_SECRET || 'dev-secret-key-do-not-use-in-production';
}

export async function getPreviousSigningKey() {
  const secrets = await fetchSecretsFromManager();
  return secrets.previous || process.env.PREVIOUS_SIGNING_SECRET || null;
}

export async function getSupportAuthToken() {
  const secrets = await fetchSecretsFromManager();
  return secrets.token || process.env.SUPPORT_AUTH_TOKEN || 'dev-support-token';
}

export function isValidSecret(provided, expected) {
  if (!expected) return false;

  try {
    return provided === expected;
  } catch (e) {
    return false;
  }
}
