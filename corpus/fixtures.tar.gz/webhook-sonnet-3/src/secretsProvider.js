import { GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';

// How long a fetched secret may be reused before this process asks Secrets Manager again. Short
// enough that a quarterly rotation is picked up promptly by every replica without a restart, long
// enough that steady-state traffic isn't fetching a secret on every single request.
const DEFAULT_TTL_MS = 5 * 60 * 1000;

/**
 * Wraps a SecretsManagerClient with a short-lived, explicitly-invalidating cache.
 *
 * The signing secret rotates every quarter, and a cache with no way to become stale again fails
 * in both directions at once: after rotation the provider's genuinely new signature is rejected
 * until every replica restarts, and a secret that has just been revoked keeps being honoured for
 * just as long. Every read here is either fresh (TTL expired) or explicitly force-refreshed after
 * a verification failure, so a rotation is visible on the very next request that needs it rather
 * than on the next deploy.
 */
export function createSecretsProvider(client, { ttlMs = DEFAULT_TTL_MS } = {}) {
  const cache = new Map(); // secretId -> { value, fetchedAt }

  async function fetchFresh(secretId) {
    const command = new GetSecretValueCommand({ SecretId: secretId });
    const result = await client.send(command);
    const value = result.SecretString;
    cache.set(secretId, { value, fetchedAt: Date.now() });
    return value;
  }

  async function get(secretId, { forceRefresh = false } = {}) {
    const entry = cache.get(secretId);
    const isStale = !entry || Date.now() - entry.fetchedAt >= ttlMs;
    if (forceRefresh || isStale) {
      return fetchFresh(secretId);
    }
    return entry.value;
  }

  /** Every currently-honoured signing secret, current first: {current, previous}. */
  async function getSigningSecrets(secretId, opts) {
    const raw = await get(secretId, opts);
    const parsed = JSON.parse(raw);
    return [parsed.current, parsed.previous].filter(Boolean);
  }

  async function getSupportToken(secretId, opts) {
    const raw = await get(secretId, opts);
    // Stored as plain text; tolerate a JSON-wrapped value too so rotating it the same way as the
    // signing secret (a {current, previous} document) is not a breaking change later.
    try {
      const parsed = JSON.parse(raw);
      return typeof parsed === 'object' && parsed !== null ? parsed.current : raw;
    } catch {
      return raw;
    }
  }

  function invalidate(secretId) {
    cache.delete(secretId);
  }

  return { getSigningSecrets, getSupportToken, invalidate };
}
