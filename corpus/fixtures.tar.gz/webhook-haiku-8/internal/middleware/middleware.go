package middleware

import (
	"crypto/hmac"
	"crypto/sha256"
	"log"
	"net/http"
	"os"
	"strings"
)

// LogRequest logs HTTP request details
func LogRequest(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		log.Printf("%s %s %s", r.Method, r.RequestURI, r.RemoteAddr)
		next(w, r)
	}
}

// Authenticate checks for Bearer token in Authorization header using constant-time comparison
func Authenticate(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		token := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		expectedToken := os.Getenv("SUPPORT_API_KEY")

		// Use hmac.Equal for constant-time comparison to prevent timing attacks
		tokenDigest := sha256.Sum256([]byte(token))
		expectedDigest := sha256.Sum256([]byte(expectedToken))
		if !hmac.Equal(tokenDigest[:], expectedDigest[:]) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			w.Write([]byte(`{"code":"unauthorized","message":"invalid or missing api key"}`))
			return
		}

		next(w, r)
	}
}
