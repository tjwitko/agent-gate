-- Webhook callback storage schema with immutability constraints
-- This schema is initialized and created at runtime in store.js

-- Callbacks table - stores immutable webhook records
CREATE TABLE IF NOT EXISTS callbacks (
  id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL UNIQUE,
  payload TEXT NOT NULL,
  signature TEXT NOT NULL,
  timestamp TEXT NOT NULL,
  received_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Immutability constraints - prevent any modifications to records
-- These triggers are created at runtime but documented here for security scanning

-- Prevent UPDATE operations on callbacks
CREATE TRIGGER IF NOT EXISTS callbacks_prevent_update
BEFORE UPDATE ON callbacks
BEGIN
  SELECT RAISE(ABORT, 'Callbacks are immutable and cannot be updated');
END;

-- Prevent DELETE operations on callbacks
CREATE TRIGGER IF NOT EXISTS callbacks_prevent_delete
BEFORE DELETE ON callbacks
BEGIN
  SELECT RAISE(ABORT, 'Callbacks are immutable and cannot be deleted');
END;
