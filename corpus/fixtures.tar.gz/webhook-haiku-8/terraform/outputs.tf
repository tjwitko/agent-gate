output "s3_bucket_name" {
  description = "S3 bucket for webhook payloads"
  value       = aws_s3_bucket.webhook_payloads.id
}

output "dynamodb_table_name" {
  description = "DynamoDB table for webhook index"
  value       = aws_dynamodb_table.webhook_index.name
}

output "iam_role_arn" {
  description = "IAM role for webhook receiver"
  value       = aws_iam_role.webhook_receiver.arn
}

output "ecr_repository_url" {
  description = "ECR repository URL for container image"
  value       = aws_ecr_repository.webhook_receiver.repository_url
}
