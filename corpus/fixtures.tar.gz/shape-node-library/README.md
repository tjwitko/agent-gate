# shape-node-library

A dependency-free Node library. It exists as an agent-gate corpus fixture covering the plain-Node
project shape: no infrastructure, no Terraform, a committed lockfile, and a test suite that runs
with nothing installed.
