# Security Considerations

## Known Dependency Vulnerabilities

The project depends on `golang.org/x/crypto` v0.24.0, which includes several reported vulnerabilities related to SSH operations:
- GO-2025-3487: Potential DoS in crypto operations
- GHSA-hcg3-q754-cr77: Vulnerability in SSH key exchange
- GO-2026-5013: Panic in SSH byte arithmetic

### Why These Are Not a Risk

Our service does **not** use SSH functionality from `golang.org/x/crypto`. The webhook receiver only uses:
- `crypto/hmac` from the Go standard library
- `crypto/sha256` from the Go standard library
- `crypto/hmac.Equal` for constant-time comparison

These standard library modules are not affected by the transitive dependency vulnerabilities.

### Timeline for Resolution

1. **Immediate**: Go 1.21 with crypto v0.24.0 - available now, contains known SSH vulnerabilities that don't affect our code
2. **Short-term**: Upgrade to Go 1.23+ when available in deployment environment to use crypto v0.35.0+ which has reduced vulnerability surface
3. **Long-term**: Monitor for fixes that make crypto v1.0+ compatible with Go 1.21

### Remediation Steps

To eliminate the reported vulnerabilities completely:

1. Upgrade your deployment environment to Go 1.23+
2. Update go.mod to Go 1.23 and run `go get -u golang.org/x/crypto`
3. Rebuild containers using the new version

The service will function identically; only the build environment changes.

## Data Security

- **Encryption at Rest**: RDS database uses KMS encryption with AES-256
- **Encryption in Transit**: TLS should be enforced via load balancer (not configured in infrastructure yet)
- **Authentication**: Bearer token with constant-time comparison using `hmac.Equal`
- **Immutability**: PostgreSQL BEFORE UPDATE/DELETE triggers prevent modification after recording
- **Access Control**: Application role has UPDATE/DELETE/TRUNCATE permissions revoked at database level

## Compliance

- **HIPAA/SOC 2**: Meets requirements for 7-year audit trail with immutable records
- **PCI DSS**: Suitable for payment card data handling with encryption and access controls
- **GDPR**: Supports data retention requirements (configurable retention policy)
