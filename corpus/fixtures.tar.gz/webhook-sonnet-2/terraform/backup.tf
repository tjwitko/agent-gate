# Defense in depth behind the primary retention mechanism (dynamodb.tf never deletes a record at
# all): AWS Backup keeps periodic recovery points of the table for at least seven years, so the
# retention requirement survives even a mistaken `terraform destroy` of the table itself, not just
# ordinary application-level deletes.
resource "aws_backup_vault" "events_log" {
  name        = "${var.app_name}-events-log-vault"
  kms_key_arn = aws_kms_key.app.arn
}

data "aws_iam_policy_document" "backup_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["backup.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "backup" {
  name               = "${var.app_name}-backup"
  assume_role_policy = data.aws_iam_policy_document.backup_trust.json
}

resource "aws_iam_role_policy_attachment" "backup" {
  role       = aws_iam_role.backup.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSBackupServiceRolePolicyForBackup"
}

resource "aws_backup_plan" "events_log" {
  name = "${var.app_name}-events-log-retention"

  rule {
    rule_name         = "seven-year-retention"
    target_vault_name = aws_backup_vault.events_log.name
    schedule          = "cron(0 5 * * ? *)"

    lifecycle {
      delete_after = var.backup_retention_days
    }
  }
}

resource "aws_backup_selection" "events_log" {
  name         = "${var.app_name}-events-log"
  plan_id      = aws_backup_plan.events_log.id
  iam_role_arn = aws_iam_role.backup.arn
  resources    = [aws_dynamodb_table.webhook_events_log.arn]
}
