# One customer-managed key for this stack's own data at rest -- the callbacks table, the two
# secrets, the container images, and the EKS control plane's own secrets. A shared key here is a
# deliberate simplification (one blast radius to reason about, one key policy to audit) rather than
# a cost/rotation-boundary decision; split it if any of these needs an independent rotation
# schedule or a tighter grant later.
resource "aws_kms_key" "app" {
  description             = "${var.project_name} data at rest: callbacks table, secrets, container images, EKS secrets"
  deletion_window_in_days = 30
  enable_key_rotation     = true

  tags = local.tags
}

resource "aws_kms_alias" "app" {
  name          = "alias/${var.project_name}"
  target_key_id = aws_kms_key.app.key_id
}
