variable "aws_account_id" {
  description = "The AWS account id this configuration deploys into. Required (no default) and not looked up live via a data source, so `terraform plan` never needs a real STS call — only real credentials, which every real invocation has anyway."
  type        = string
}

variable "aws_region" {
  description = "Single AWS region this whole deployment lives in."
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Short name used to prefix every resource this configuration creates."
  type        = string
  default     = "webhook-receiver"
}

variable "environment" {
  type    = string
  default = "production"
}

variable "vpc_cidr" {
  description = "Must match the CIDR the NetworkPolicies in k8s/06-network-policies.yaml allow for the support-api service — that file is not templated from this one."
  type        = string
  default     = "10.0.0.0/16"
}

variable "azs" {
  description = "At least two, for EKS's own availability requirement."
  type        = list(string)
  default     = ["us-east-1a", "us-east-1b"]
}

variable "eks_cluster_version" {
  type    = string
  default = "1.31"
}

variable "node_instance_types" {
  type    = list(string)
  default = ["t3.medium"]
}

variable "node_desired_size" {
  type    = number
  default = 2
}

variable "node_min_size" {
  type    = number
  default = 2
}

variable "node_max_size" {
  type    = number
  default = 4
}
