import { createApp } from "./app.js";
import { loadConfig } from "./config.js";
import { createDynamoEventStore } from "./lib/dynamoEventStore.js";
import { logger } from "./lib/logger.js";
import { createSecretStore } from "./lib/secretStore.js";
import { createSupportAuth } from "./lib/supportAuth.js";
import { createWebhookService } from "./lib/webhookService.js";

const config = loadConfig();

const secretStore = createSecretStore({ region: config.awsRegion, ttlMs: config.secretCacheTtlMs });
const eventStore = createDynamoEventStore({ region: config.awsRegion, tableName: config.tableName });

const webhookService = createWebhookService({
  getSigningSecrets: () => secretStore.getSigningSecrets(config.signingSecretId),
  store: eventStore,
});

const supportAuth = createSupportAuth({
  getSupportToken: () => secretStore.getSupportToken(config.supportTokenSecretId),
});

const server = createApp({ webhookService, supportAuth });

server.listen(config.port, () => {
  logger.info(`webhook receiver listening on port ${config.port}`);
});

// A rejected promise this service didn't handle is a fault, same as any other -- log it the same
// way rather than letting it crash the process silently or print an unstructured stack trace.
process.on("unhandledRejection", (err) => {
  logger.fault("unhandled rejection", { error: err instanceof Error ? err.message : String(err) });
});
