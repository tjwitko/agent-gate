# Webhook Receiver Service

A secure webhook receiver for payment provider event notifications built with Go, Kubernetes, and AWS infrastructure.

## Features

- **Signature Verification**: HMAC-SHA256 verification of incoming webhooks
- **Immutable Storage**: Records stored in PostgreSQL with write-once semantics (ON CONFLICT DO NOTHING)
- **7-Year Retention**: Automated backups retained for 7 years via AWS Backup
- **Health Endpoint**: Load balancer health check support
- **Support Team Access**: Query past callbacks by event ID
- **Error Classification**: Distinguishes client errors from server faults

## Architecture

### Components

- **Go Service**: HTTP server handling webhook receipt, verification, and storage
- **PostgreSQL RDS**: Multi-AZ database with encryption and automated backups
- **EKS Cluster**: Kubernetes cluster for service deployment (2+ replicas)
- **AWS Backup**: Long-term retention for 7-year compliance requirement

### Endpoints

- `POST /webhook` - Receive webhooks (requires X-Webhook-Signature header)
- `GET /health` - Health check for load balancer
- `GET /lookup?event_id=<id>` - Query past webhook by event ID (support team only)

## Requirements

- Terraform 1.0+
- AWS CLI configured with credentials
- kubectl configured for EKS access
- Docker for building container image
- Go 1.21+ (for local development/testing)

## Deployment

### 1. Build Infrastructure with Terraform

```bash
cd terraform
terraform init
terraform plan -var 'db_password=<secure-password>'
terraform apply -var 'db_password=<secure-password>'
```

Terraform creates:
- VPC with public/private subnets across 2 AZs
- Multi-AZ RDS PostgreSQL instance with encrypted storage
- EKS cluster with managed node groups
- AWS Backup vault with 7-year retention plan
- Security groups and IAM roles

### 2. Build and Push Container Image

```bash
docker build -t webhook-receiver:latest .
# Push to your ECR registry
```

### 3. Deploy to Kubernetes

```bash
# Create namespace and secrets
kubectl apply -f k8s/namespace.yaml
kubectl create secret generic webhook-receiver-secrets \
  --from-literal=database-url='postgresql://webhook_user:password@rds-endpoint/webhooks' \
  --from-literal=webhook-secret='<provider-signing-secret>' \
  -n webhook-receiver

# Deploy service
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
```

## Testing

### Unit Tests

The test suite covers:
- Signature verification (valid and forged signatures)
- Accepting valid webhooks
- Rejecting forged webhooks
- Preventing duplicate overwriting
- Error type classification (client vs server)
- Health endpoint behavior

Run tests:
```bash
go test -v ./...
```

Tests require a PostgreSQL instance running at `localhost:5432` with:
- Database: `webhook_test`
- User: `test`
- Password: `test`

### Manual Testing

Test valid webhook:
```bash
PAYLOAD='{"event_id":"evt_123","amount":1000}'
SIGNATURE=$(echo -n "$PAYLOAD" | openssl dgst -sha256 -hmac "test-secret" | cut -d' ' -f2)

curl -X POST http://localhost:8080/webhook \
  -H "X-Webhook-Signature: $SIGNATURE" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD"
```

Test health endpoint:
```bash
curl http://localhost:8080/health
```

Query stored event:
```bash
curl 'http://localhost:8080/lookup?event_id=evt_123'
```

## Security Considerations

### Signature Verification

- Webhooks must include `X-Webhook-Signature` header with HMAC-SHA256 of request body
- Secrets rotated quarterly by provider; support team handles updates

### Storage Immutability

- Database uses `ON CONFLICT (event_id) DO NOTHING` to prevent overwrites
- No UPDATE or DELETE permissions for application role
- All records encrypted at rest with KMS

### Network Security

- RDS in private subnets, accessible only from app security group
- Application security group allows inbound on ports 80/443/8080
- EKS cluster uses VPC networking without public IP assignment

### Access Control

- Support team needs Kubernetes RBAC role for kubectl access to log lookups
- Database credentials stored in Kubernetes secrets
- CloudWatch logging enabled for audit trail

## Monitoring

- RDS CloudWatch logs retention: 30 days
- EKS cluster logs exported to CloudWatch
- Health endpoint for load balancer target health
- Database backups automated via AWS Backup

## Maintenance

### Rotating Webhook Secret

1. Add new secret to Kubernetes secret (keeping old one temporarily)
2. Update code to accept both signatures during transition period
3. Remove old signature validation after provider confirms rotation

### Database Backups

- Automated daily snapshots with 35-day retention
- Long-term backups via AWS Backup: 30 days cold storage, then 7-year retention
- Test restore procedures quarterly

## Cost Optimization

- Single-region deployment (us-east-1 by default)
- t4g.micro RDS instance (small to medium workloads)
- t3.small EKS nodes (adjust scaling based on traffic)
- Backup cost ~$0.05/GB/month for 7-year retention

## Troubleshooting

### Database Connection Issues

Check RDS security group allows inbound on port 5432 from app security group:
```bash
aws ec2 describe-security-groups --group-ids sg-xxxxx
```

### Webhook Signature Failures

1. Verify provider is sending correct secret
2. Confirm X-Webhook-Signature header format matches HMAC-SHA256
3. Check payload is exact bytes received (no encoding/decoding)

### Application Logs

```bash
kubectl logs -f deployment/webhook-receiver -n webhook-receiver
```
