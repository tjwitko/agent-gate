# A single customer-managed key for everything in this module that encrypts at rest -- the
# events log, its two secrets, its backups, and the container image -- rather than each service's
# AWS-owned default key. Financial dispute records that live here for seven years are worth this
# account having its own key rotation and audit trail for who could decrypt them, not just AWS's.
#
# No explicit key policy is set, so AWS applies its default ("Enable IAM User Permissions",
# delegating access to this account's own IAM policies) -- the app role's ability to use this key
# is granted the same way as every other permission it holds, in iam.tf's UseEncryptionKey
# statement. The AWS-managed AWSBackupServiceRolePolicyForBackup policy (backup.tf) already
# includes the KMS actions AWS Backup needs against a customer-managed key.
resource "aws_kms_key" "app" {
  description             = "Customer-managed key for the webhook receiver's events log, secrets, backups and container image."
  enable_key_rotation     = true
  deletion_window_in_days = 30
}

resource "aws_kms_alias" "app" {
  name          = "alias/${var.app_name}"
  target_key_id = aws_kms_key.app.key_id
}
