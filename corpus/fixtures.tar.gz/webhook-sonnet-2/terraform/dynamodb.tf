# The system of record for received callbacks. A chargeback dispute raised years from now has to
# be settled by exactly what was received at the time, so this table is designed so nothing
# running in the cluster can alter or remove a row once it lands:
#   - the application writes with a conditional put (attribute_not_exists(event_id)), so a
#     redelivered event never overwrites the original -- see src/lib/dynamoEventStore.js
#   - the IAM policy this app's role is granted (iam.tf) includes PutItem/GetItem/Query only;
#     there is no UpdateItem, DeleteItem or BatchWriteItem permission for it to use
#   - no TTL attribute is configured, so nothing here expires records early -- the seven-year
#     retention requirement is satisfied by never deleting rather than by scheduling a deletion
resource "aws_dynamodb_table" "webhook_events_log" {
  name         = "${var.app_name}-events-log"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "event_id"

  attribute {
    name = "event_id"
    type = "S"
  }

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = aws_kms_key.app.arn
  }

  deletion_protection_enabled = true

  tags = {
    Name        = "${var.app_name}-events-log"
    Environment = var.environment
    Purpose     = "immutable-webhook-audit-log"
  }
}
