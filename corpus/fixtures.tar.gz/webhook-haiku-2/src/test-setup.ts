import { start, verifier } from "./server.js";

// Set test environment variables
process.env.NODE_ENV = "test";

// Add test secret to the verifier
const TEST_SECRET = "test-webhook-secret";
verifier.addSecret(TEST_SECRET, new Date(0));

// Start the server before running tests
start();

// Give the server time to start
await new Promise((resolve) => setTimeout(resolve, 100));
