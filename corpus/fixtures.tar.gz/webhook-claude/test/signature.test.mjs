import { test } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { verifySignature, verifyCredential } from "../src/lib/signature.mjs";

function sign(secret, body) {
  return createHmac("sha256", secret).update(body).digest("hex");
}

test("verifySignature accepts a signature genuinely produced with the shared secret", () => {
  const secret = "quarterly-rotated-signing-secret";
  const body = Buffer.from(JSON.stringify({ event_id: "evt_1", amount: 100 }));
  assert.equal(verifySignature(secret, body, sign(secret, body)), true);
});

test("verifySignature rejects a signature produced with the wrong secret (forged)", () => {
  const body = Buffer.from(JSON.stringify({ event_id: "evt_1", amount: 100 }));
  const forgedSignature = sign("an-attackers-guessed-secret", body);
  assert.equal(verifySignature("quarterly-rotated-signing-secret", body, forgedSignature), false);
});

test("verifySignature rejects a genuine signature applied to a tampered body", () => {
  const secret = "quarterly-rotated-signing-secret";
  const originalBody = Buffer.from(JSON.stringify({ event_id: "evt_1", amount: 100 }));
  const signature = sign(secret, originalBody);
  const tamperedBody = Buffer.from(JSON.stringify({ event_id: "evt_1", amount: 100000 }));
  assert.equal(verifySignature(secret, tamperedBody, signature), false);
});

test("verifySignature rejects a missing or malformed signature header without throwing", () => {
  const secret = "quarterly-rotated-signing-secret";
  const body = Buffer.from("{}");
  assert.equal(verifySignature(secret, body, undefined), false);
  assert.equal(verifySignature(secret, body, ""), false);
  assert.equal(verifySignature(secret, body, "not-hex-and-wrong-length"), false);
  assert.equal(verifySignature(secret, body, "ab"), false); // valid hex, wrong length
});

test("verifyCredential accepts the genuine value and rejects any other, including a different-length guess", () => {
  const expected = "a-generated-support-team-api-key";
  assert.equal(verifyCredential(expected, expected), true);
  assert.equal(verifyCredential(expected, "wrong-key"), false);
  assert.equal(verifyCredential(expected, "x"), false);
  assert.equal(verifyCredential(expected, ""), false);
});
