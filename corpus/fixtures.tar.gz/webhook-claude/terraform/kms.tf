# A single customer-managed key for this project's at-rest encryption (DynamoDB, Secrets Manager,
# ECR, the EKS control-plane's Kubernetes Secrets envelope encryption, and CloudWatch Logs).
# Rotation is enabled — terraform-guard's aws.secrets.kms-rotation-disabled rule blocks on this by
# design, since the provider default is off.
#
# A custom key policy is required (not just IAM policies on the app roles) because CloudWatch
# Logs encrypts with this key as its own service principal, which the default AWS-generated key
# policy — account-root-only — does not cover. Every other consumer here (DynamoDB, Secrets
# Manager, ECR, EKS) is authorized through ordinary IAM policies on the calling principal, which
# the root-delegation statement already allows.
#
# Built from var.aws_account_id rather than a live aws_caller_identity data source on purpose:
# that data source makes a real STS call at plan time, which fails outright under placeholder
# credentials and would make this configuration impossible to plan (even schema/security-scan
# only) without genuine AWS access.
data "aws_iam_policy_document" "app_kms_key" {
  # The account-root statement below is AWS's own default key policy shape (verbatim what
  # aws_kms_key generates automatically when no `policy` argument is given at all), not a
  # loosened grant: a KMS key policy is the ONLY access path that cannot itself be granted by an
  # IAM policy, so without an "enable IAM user permissions" statement here, every IAM policy on
  # every role in this configuration — the two IRSA roles' kms:Decrypt grants included — would be
  # silently ineffective, because the key policy is what delegates authority to IAM in the first
  # place. Every real capability is still gated by the IAM policies in iam_irsa.tf.
  #checkov:skip=CKV_AWS_111:root-account key-policy delegation statement; access is actually gated by the scoped IAM policies in iam_irsa.tf
  #checkov:skip=CKV_AWS_109:same — this statement delegates to IAM, it does not itself grant permissions management
  #checkov:skip=CKV_AWS_356:Resource "*" in a KMS key policy means "this key", which is the standard/only way to write a key policy
  statement {
    sid       = "EnableIamPolicies"
    effect    = "Allow"
    actions   = ["kms:*"]
    resources = ["*"]
    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::${var.aws_account_id}:root"]
    }
  }

  statement {
    sid    = "AllowCloudWatchLogs"
    effect = "Allow"
    actions = [
      "kms:Encrypt", "kms:Decrypt", "kms:ReEncrypt*", "kms:GenerateDataKey*", "kms:DescribeKey",
    ]
    resources = ["*"]
    principals {
      type        = "Service"
      identifiers = ["logs.${var.aws_region}.amazonaws.com"]
    }
    condition {
      test     = "ArnLike"
      variable = "kms:EncryptionContext:aws:logs:arn"
      values   = ["arn:aws:logs:${var.aws_region}:${var.aws_account_id}:log-group:*"]
    }
  }
}

resource "aws_kms_key" "app" {
  description         = "${var.project_name} at-rest encryption key"
  enable_key_rotation = true
  policy              = data.aws_iam_policy_document.app_kms_key.json
}

resource "aws_kms_alias" "app" {
  name          = "alias/${var.project_name}"
  target_key_id = aws_kms_key.app.key_id
}
