terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

locals {
  callbacks_table = "${var.project_name}-callbacks"
  secrets_table   = "${var.project_name}-secrets"
}

# DynamoDB table for webhook callbacks (immutable, append-only)
resource "aws_dynamodb_table" "callbacks" {
  name                      = local.callbacks_table
  billing_mode              = "PAY_PER_REQUEST"
  hash_key                  = "event_id"
  deletion_protection_enabled = true

  attribute {
    name = "event_id"
    type = "S"
  }

  point_in_time_recovery {
    enabled = true
  }

  tags = merge(
    var.common_tags,
    {
      Name = local.callbacks_table
    }
  )
}

# DynamoDB table for signing secrets (rotated quarterly)
resource "aws_dynamodb_table" "secrets" {
  name           = local.secrets_table
  billing_mode   = "PAY_PER_REQUEST"
  hash_key       = "secret_id"

  attribute {
    name = "secret_id"
    type = "S"
  }

  point_in_time_recovery {
    enabled = true
  }

  tags = merge(
    var.common_tags,
    {
      Name = local.secrets_table
    }
  )
}

# IAM role for EKS service account (IRSA)
resource "aws_iam_role" "webhook_receiver" {
  name = "${var.project_name}-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          AWS = var.oidc_provider_arn
        }
      }
    ]
  })

  tags = merge(
    var.common_tags,
    {
      Name = "${var.project_name}-role"
    }
  )
}

# IAM policy for DynamoDB access
resource "aws_iam_role_policy" "webhook_receiver_dynamodb" {
  name = "${var.project_name}-dynamodb"
  role = aws_iam_role.webhook_receiver.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = [
          "dynamodb:GetItem",
          "dynamodb:PutItem",
          "dynamodb:Query",
          "dynamodb:Scan",
        ]
        Effect = "Allow"
        Resource = [
          aws_dynamodb_table.callbacks.arn,
          aws_dynamodb_table.secrets.arn,
        ]
      }
    ]
  })
}

# CloudWatch log group for application logs (7-year retention)
resource "aws_cloudwatch_log_group" "webhook_receiver" {
  name              = "/aws/webhook-receiver/${var.project_name}"
  retention_in_days = 3653

  tags = merge(
    var.common_tags,
    {
      Name = "${var.project_name}-logs"
    }
  )
}

# ECR repository for container images
resource "aws_ecr_repository" "webhook_receiver" {
  name                 = var.project_name
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  encryption_configuration {
    encryption_type = "AES256"
  }

  tags = merge(
    var.common_tags,
    {
      Name = "${var.project_name}-repo"
    }
  )
}

# ECR lifecycle policy to manage image retention
resource "aws_ecr_lifecycle_policy" "webhook_receiver" {
  repository = aws_ecr_repository.webhook_receiver.name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Keep last 10 images"
        selection = {
          tagStatus     = "tagged"
          tagPrefixList = ["v"]
          countType     = "imageCountMoreThan"
          countNumber   = 10
        }
        action = {
          type = "expire"
        }
      }
    ]
  })
}

# SNS topic for operational alerts
resource "aws_sns_topic" "webhook_receiver_alerts" {
  name = "${var.project_name}-alerts"

  tags = merge(
    var.common_tags,
    {
      Name = "${var.project_name}-alerts"
    }
  )
}

# CloudWatch alarm for DynamoDB errors
resource "aws_cloudwatch_metric_alarm" "dynamodb_user_errors" {
  alarm_name          = "${var.project_name}-dynamodb-errors"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 2
  metric_name         = "UserErrors"
  namespace           = "AWS/DynamoDB"
  period              = 300
  statistic           = "Sum"
  threshold           = 5
  alarm_description   = "Alert on DynamoDB user errors"
  alarm_actions       = [aws_sns_topic.webhook_receiver_alerts.arn]

  dimensions = {
    TableName = aws_dynamodb_table.callbacks.name
  }
}

output "dynamodb_callbacks_table" {
  value       = aws_dynamodb_table.callbacks.name
  description = "DynamoDB table for webhook callbacks"
}

output "dynamodb_secrets_table" {
  value       = aws_dynamodb_table.secrets.name
  description = "DynamoDB table for signing secrets"
}

output "ecr_repository_url" {
  value       = aws_ecr_repository.webhook_receiver.repository_url
  description = "ECR repository URL for container images"
}

output "iam_role_arn" {
  value       = aws_iam_role.webhook_receiver.arn
  description = "IAM role ARN for Kubernetes service account"
}

output "log_group_name" {
  value       = aws_cloudwatch_log_group.webhook_receiver.name
  description = "CloudWatch log group name"
}
