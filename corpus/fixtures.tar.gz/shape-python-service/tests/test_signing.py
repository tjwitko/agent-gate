"""Tests for the signing helpers.

Standard library only, deliberately: the gate never installs a project's dependencies, so a test
importing Flask could not run on any machine that had not already installed it. Three Go
deliverables in this corpus shipped suites that fell into exactly that trap.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.signing import sign, verify  # noqa: E402


def test_signature_is_stable():
    assert sign("k", b"payload") == sign("k", b"payload")


def test_a_different_secret_gives_a_different_signature():
    assert sign("a", b"payload") != sign("b", b"payload")


def test_a_different_payload_gives_a_different_signature():
    assert sign("k", b"one") != sign("k", b"two")


def test_verify_accepts_a_genuine_signature():
    assert verify("k", b"payload", sign("k", b"payload"))


def test_verify_rejects_a_forged_signature():
    assert not verify("k", b"payload", "0" * 64)


def test_an_empty_secret_is_refused():
    try:
        sign("", b"payload")
    except ValueError:
        return
    raise AssertionError("an empty secret must not produce a signature")
