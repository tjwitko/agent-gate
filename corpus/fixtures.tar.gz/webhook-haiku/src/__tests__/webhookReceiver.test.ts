import crypto from 'crypto';
import { SignatureVerifier } from '../service/signatureVerifier';
import { WebhookService } from '../service/webhookService';

// Mock Database
class MockDatabase {
  private secrets: Map<string, string[]> = new Map();
  private webhooks: Map<string, any> = new Map();
  private supportApiKeys: Set<string> = new Set();
  private providerApiKeys: Set<string> = new Set();

  async getProviderSecrets(providerId: string) {
    const values = this.secrets.get(providerId) || [];
    return values.map(value => ({
      value,
      createdAt: new Date(),
      rotatesAt: undefined
    }));
  }

  async getWebhookByEventId(eventId: string, providerId?: string) {
    const key = providerId ? `${providerId}:${eventId}` : eventId;
    return this.webhooks.get(key) || null;
  }

  async storeWebhook(webhook: any) {
    const key = `${webhook.providerId}:${webhook.eventId}`;
    this.webhooks.set(key, webhook);
  }

  async validateSupportTeamApiKey(key: string) {
    return this.supportApiKeys.has(key);
  }

  async validateProviderApiKey(key: string) {
    return this.providerApiKeys.has(key);
  }

  setSecret(providerId: string, secret: string) {
    this.secrets.set(providerId, [secret]);
  }

  setSupportApiKey(key: string) {
    this.supportApiKeys.add(key);
  }

  setProviderApiKey(key: string) {
    this.providerApiKeys.add(key);
  }

  clearSecrets(providerId: string) {
    this.secrets.delete(providerId);
  }
}

describe('Webhook Receiver', () => {
  let db: MockDatabase;
  let verifier: SignatureVerifier;
  let service: WebhookService;

  beforeEach(() => {
    db = new MockDatabase();
    verifier = new SignatureVerifier(db as any);
    service = new WebhookService(db as any);
  });

  describe('Signature Verification', () => {
    it('should accept a valid signature', async () => {
      const providerId = 'stripe';
      const secret = 'whsec_test_secret_12345';
      const payload = JSON.stringify({ event_id: 'evt_123', type: 'payment.success' });

      db.setSecret(providerId, secret);

      const hmac = crypto.createHmac('sha256', secret);
      hmac.update(payload);
      const validSignature = hmac.digest('hex');

      const isValid = await verifier.verify(payload, validSignature, providerId);
      expect(isValid).toBe(true);
    });

    it('should reject an invalid signature', async () => {
      const providerId = 'stripe';
      const secret = 'whsec_test_secret_12345';
      const payload = JSON.stringify({ event_id: 'evt_123', type: 'payment.success' });

      db.setSecret(providerId, secret);

      const invalidSignature = 'invalid_signature_abc123def456';

      const isValid = await verifier.verify(payload, invalidSignature, providerId);
      expect(isValid).toBe(false);
    });

    it('should reject a forged callback with tampered payload', async () => {
      const providerId = 'stripe';
      const secret = 'whsec_test_secret_12345';
      const originalPayload = JSON.stringify({ event_id: 'evt_123', amount: 1000 });

      db.setSecret(providerId, secret);

      // Attacker creates signature for original payload but sends modified payload
      const hmac = crypto.createHmac('sha256', secret);
      hmac.update(originalPayload);
      const validSignature = hmac.digest('hex');

      const tamperedPayload = JSON.stringify({ event_id: 'evt_123', amount: 10000 });

      const isValid = await verifier.verify(tamperedPayload, validSignature, providerId);
      expect(isValid).toBe(false);
    });

    it('should handle provider secret rotation', async () => {
      const providerId = 'stripe';
      const oldSecret = 'old_secret';
      const newSecret = 'new_secret';
      const payload = JSON.stringify({ event_id: 'evt_123', type: 'payment.success' });

      // Simulate both old and new secrets being active during rotation
      (db as any).secrets.set(providerId, [newSecret, oldSecret]);

      // Old signature should still work
      const oldHmac = crypto.createHmac('sha256', oldSecret);
      oldHmac.update(payload);
      const oldSignature = oldHmac.digest('hex');

      const isValidOld = await verifier.verify(payload, oldSignature, providerId);
      expect(isValidOld).toBe(true);

      // New signature should also work
      const newHmac = crypto.createHmac('sha256', newSecret);
      newHmac.update(payload);
      const newSignature = newHmac.digest('hex');

      const isValidNew = await verifier.verify(payload, newSignature, providerId);
      expect(isValidNew).toBe(true);
    });

    it('should reject signature when no secrets are configured', async () => {
      const providerId = 'unknown_provider';
      const payload = JSON.stringify({ event_id: 'evt_123' });
      const signature = 'some_signature';

      db.clearSecrets(providerId);

      const isValid = await verifier.verify(payload, signature, providerId);
      expect(isValid).toBe(false);
    });
  });

  describe('Webhook Storage and Idempotency', () => {
    it('should store a webhook and return an ID', async () => {
      const id = await service.storeWebhook({
        eventId: 'evt_123',
        providerId: 'stripe',
        payload: '{"event_id":"evt_123"}',
        signature: 'sig_abc123',
        receivedAt: new Date()
      });

      expect(id).toBeDefined();
      expect(typeof id).toBe('string');
    });

    it('should not overwrite an existing webhook with the same event ID', async () => {
      const eventId = 'evt_repeated';
      const providerId = 'stripe';
      const firstPayload = '{"event_id":"evt_repeated","version":1}';
      const secondPayload = '{"event_id":"evt_repeated","version":2}';

      // Store first webhook
      const firstId = await service.storeWebhook({
        eventId,
        providerId,
        payload: firstPayload,
        signature: 'sig_first',
        receivedAt: new Date()
      });

      // Store second webhook with same event ID
      const secondId = await service.storeWebhook({
        eventId,
        providerId,
        payload: secondPayload,
        signature: 'sig_second',
        receivedAt: new Date()
      });

      // Should return the original ID (idempotent)
      expect(secondId).toBe(firstId);

      // Verify the payload hasn't been overwritten
      const retrieved = await service.getWebhookByEventId(eventId);
      expect(retrieved?.payload).toBe(firstPayload);
    });

    it('should allow same event ID from different providers', async () => {
      const eventId = 'evt_shared';
      const payload1 = '{"event_id":"evt_shared","provider":"stripe"}';
      const payload2 = '{"event_id":"evt_shared","provider":"square"}';

      const id1 = await service.storeWebhook({
        eventId,
        providerId: 'stripe',
        payload: payload1,
        signature: 'sig_stripe',
        receivedAt: new Date()
      });

      const id2 = await service.storeWebhook({
        eventId,
        providerId: 'square',
        payload: payload2,
        signature: 'sig_square',
        receivedAt: new Date()
      });

      expect(id1).not.toBe(id2);
    });

    it('should retain webhook exactly as received', async () => {
      const originalPayload = JSON.stringify({
        event_id: 'evt_123',
        amount: 12345,
        currency: 'USD',
        timestamp: '2024-01-15T10:30:00Z',
        metadata: { order_id: 'order_456', special_chars: 'ñ€©®™' }
      });

      const id = await service.storeWebhook({
        eventId: 'evt_123',
        providerId: 'stripe',
        payload: originalPayload,
        signature: 'sig_abc',
        receivedAt: new Date('2024-01-15T10:30:05Z')
      });

      const retrieved = await service.getWebhookByEventId('evt_123');

      // Payload must be exactly as stored (byte-for-byte)
      expect(retrieved?.payload).toBe(originalPayload);
      expect(retrieved?.signature).toBe('sig_abc');
      expect(retrieved?.eventId).toBe('evt_123');
      expect(retrieved?.providerId).toBe('stripe');
    });
  });

  describe('Error Handling', () => {
    it('should distinguish between bad requests and server errors', () => {
      // Bad request: malformed JSON
      const badJsonError = new Error('JSON.parse error');
      expect(badJsonError.message.includes('JSON')).toBe(true);

      // Server error: database connection
      const serverError = new Error('Connection timeout');
      expect(serverError.message.includes('JSON')).toBe(false);
    });
  });

  describe('Authentication', () => {
    it('should verify provider API key with constant-time comparison', async () => {
      const key = 'provider_secret_key_123';
      db.setProviderApiKey(key);

      const isValid = await db.validateProviderApiKey(key);
      expect(isValid).toBe(true);

      const invalidKey = 'wrong_key';
      const isInvalid = await db.validateProviderApiKey(invalidKey);
      expect(isInvalid).toBe(false);
    });

    it('should verify support team API key with constant-time comparison', async () => {
      const key = 'support_api_key_456';
      db.setSupportApiKey(key);

      const isValid = await db.validateSupportTeamApiKey(key);
      expect(isValid).toBe(true);

      const invalidKey = 'wrong_support_key';
      const isInvalid = await db.validateSupportTeamApiKey(invalidKey);
      expect(isInvalid).toBe(false);
    });
  });
});
