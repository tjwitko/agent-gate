package signature

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"testing"
)

func TestVerifyValidSignature(t *testing.T) {
	secret := "my-secret-key"
	body := []byte(`{"event_id":"evt_123","type":"payment.completed"}`)

	h := hmac.New(sha256.New, []byte(secret))
	h.Write(body)
	signature := hex.EncodeToString(h.Sum(nil))

	verifier := NewVerifier(secret, "")
	err := verifier.Verify(body, signature)
	if err != nil {
		t.Errorf("valid signature rejected: %v", err)
	}
}

func TestVerifyInvalidSignature(t *testing.T) {
	secret := "my-secret-key"
	body := []byte(`{"event_id":"evt_123","type":"payment.completed"}`)

	verifier := NewVerifier(secret, "")
	err := verifier.Verify(body, "invalid-signature")
	if err == nil {
		t.Error("invalid signature accepted")
	}
}

func TestVerifyWithRotatedSecret(t *testing.T) {
	currentSecret := "new-secret"
	oldSecret := "old-secret"
	body := []byte(`{"event_id":"evt_123","type":"payment.completed"}`)

	// Signature created with old secret
	h := hmac.New(sha256.New, []byte(oldSecret))
	h.Write(body)
	signature := hex.EncodeToString(h.Sum(nil))

	verifier := NewVerifier(currentSecret, oldSecret)
	err := verifier.Verify(body, signature)
	if err != nil {
		t.Errorf("signature with rotated secret rejected: %v", err)
	}
}

func TestVerifyEmptySignature(t *testing.T) {
	verifier := NewVerifier("secret", "")
	err := verifier.Verify([]byte("body"), "")
	if err == nil {
		t.Error("empty signature accepted")
	}
}

func TestVerifyTamperedBody(t *testing.T) {
	secret := "my-secret-key"
	originalBody := []byte(`{"event_id":"evt_123","type":"payment.completed"}`)

	h := hmac.New(sha256.New, []byte(secret))
	h.Write(originalBody)
	signature := hex.EncodeToString(h.Sum(nil))

	tamperedBody := []byte(`{"event_id":"evt_123","type":"payment.completed","amount":999}`)

	verifier := NewVerifier(secret, "")
	err := verifier.Verify(tamperedBody, signature)
	if err == nil {
		t.Error("tampered body with valid signature accepted")
	}
}
