import assert from "node:assert/strict";
import { after, before, test } from "node:test";
import { createApp } from "../src/app.js";
import { computeSignature } from "../src/lib/signature.js";
import { createSupportAuth } from "../src/lib/supportAuth.js";
import { createWebhookService } from "../src/lib/webhookService.js";

const SIGNING_SECRET = "test-signing-secret";
const SUPPORT_TOKEN = "test-support-token";

// A minimal stand-in for the DynamoDB-backed store with the same contract, including the
// duplicate-detection behavior a real conditional put (attribute_not_exists) gives us: the first
// write for an event id succeeds, every later write for that same id is reported as a duplicate
// and never changes what's already on file.
function createFakeStore() {
  const records = new Map();
  return {
    async record(eventId, record) {
      if (records.has(eventId)) {
        return { stored: false, duplicate: true };
      }
      records.set(eventId, record);
      return { stored: true };
    },
    async get(eventId) {
      return records.get(eventId) ?? null;
    },
    _records: records,
  };
}

let server;
let baseUrl;
let store;

before(async () => {
  store = createFakeStore();
  const webhookService = createWebhookService({
    getSigningSecrets: async () => [SIGNING_SECRET],
    store,
  });
  const supportAuth = createSupportAuth({ getSupportToken: async () => SUPPORT_TOKEN });

  server = createApp({ webhookService, supportAuth });
  await new Promise((resolve) => server.listen(0, resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(() => {
  server.close();
});

function sign(body) {
  return `sha256=${computeSignature(SIGNING_SECRET, Buffer.from(body))}`;
}

test("GET /healthz needs no credential and returns 200", async () => {
  const res = await fetch(`${baseUrl}/healthz`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.status, "ok");
});

test("a genuinely signed callback is accepted and recorded", async () => {
  const body = JSON.stringify({ id: "evt_genuine_1", type: "payment.succeeded", amount: 4200 });
  const res = await fetch(`${baseUrl}/webhooks/payment-provider`, {
    method: "POST",
    headers: { "x-webhook-signature": sign(body) },
    body,
  });
  assert.equal(res.status, 201);
  const json = await res.json();
  assert.equal(json.stored, true);
  assert.equal(json.eventId, "evt_genuine_1");
});

test("a forged signature is rejected and nothing is recorded", async () => {
  const body = JSON.stringify({ id: "evt_forged_1", type: "payment.succeeded" });
  const res = await fetch(`${baseUrl}/webhooks/payment-provider`, {
    method: "POST",
    headers: { "x-webhook-signature": "sha256=" + "0".repeat(64) },
    body,
  });
  assert.equal(res.status, 401);
  assert.equal(store._records.has("evt_forged_1"), false);
});

test("a missing signature header is rejected the same way", async () => {
  const body = JSON.stringify({ id: "evt_no_sig", type: "payment.succeeded" });
  const res = await fetch(`${baseUrl}/webhooks/payment-provider`, {
    method: "POST",
    body,
  });
  assert.equal(res.status, 401);
});

test("a repeated delivery of the same event id does not overwrite what was recorded", async () => {
  const original = JSON.stringify({ id: "evt_dup_1", type: "payment.succeeded", amount: 100 });
  const first = await fetch(`${baseUrl}/webhooks/payment-provider`, {
    method: "POST",
    headers: { "x-webhook-signature": sign(original) },
    body: original,
  });
  assert.equal(first.status, 201);

  // The provider retries with a payload that differs (as a real retry with updated metadata
  // might) but the same event id -- the second write must not replace what's already stored.
  const retried = JSON.stringify({ id: "evt_dup_1", type: "payment.succeeded", amount: 999 });
  const second = await fetch(`${baseUrl}/webhooks/payment-provider`, {
    method: "POST",
    headers: { "x-webhook-signature": sign(retried) },
    body: retried,
  });
  assert.equal(second.status, 200);
  const secondJson = await second.json();
  assert.equal(secondJson.duplicate, true);

  assert.equal(store._records.get("evt_dup_1").payload.amount, 100);
});

test("a malformed JSON body with a genuine signature is a client error, not a fault", async () => {
  const body = "{not valid json";
  const res = await fetch(`${baseUrl}/webhooks/payment-provider`, {
    method: "POST",
    headers: { "x-webhook-signature": sign(body) },
    body,
  });
  assert.equal(res.status, 400);
});

test("GET /callbacks/:id with no credential is rejected", async () => {
  const res = await fetch(`${baseUrl}/callbacks/evt_genuine_1`);
  assert.equal(res.status, 401);
});

test("GET /callbacks/:id with the wrong token is rejected", async () => {
  const res = await fetch(`${baseUrl}/callbacks/evt_genuine_1`, {
    headers: { authorization: "Bearer wrong-token" },
  });
  assert.equal(res.status, 403);
});

test("GET /callbacks/:id with the support token returns what was received", async () => {
  const res = await fetch(`${baseUrl}/callbacks/evt_genuine_1`, {
    headers: { authorization: `Bearer ${SUPPORT_TOKEN}` },
  });
  assert.equal(res.status, 200);
  const json = await res.json();
  assert.equal(json.payload.id, "evt_genuine_1");
  assert.equal(json.payload.amount, 4200);
});

test("GET /callbacks/:id for an unknown event id is a 404, not a fault", async () => {
  const res = await fetch(`${baseUrl}/callbacks/evt_never_happened`, {
    headers: { authorization: `Bearer ${SUPPORT_TOKEN}` },
  });
  assert.equal(res.status, 404);
});

test("an unexpected failure in the store surfaces as a fault, distinct from a client error", async () => {
  const failingStore = {
    async record() {
      throw new Error("simulated DynamoDB outage");
    },
    async get() {
      return null;
    },
  };
  const webhookService = createWebhookService({
    getSigningSecrets: async () => [SIGNING_SECRET],
    store: failingStore,
  });
  const supportAuth = createSupportAuth({ getSupportToken: async () => SUPPORT_TOKEN });
  const faultServer = createApp({ webhookService, supportAuth });
  await new Promise((resolve) => faultServer.listen(0, resolve));
  const faultUrl = `http://127.0.0.1:${faultServer.address().port}`;

  try {
    const body = JSON.stringify({ id: "evt_fault_1", type: "payment.succeeded" });
    const res = await fetch(`${faultUrl}/webhooks/payment-provider`, {
      method: "POST",
      headers: { "x-webhook-signature": sign(body) },
      body,
    });
    assert.equal(res.status, 500);
    const json = await res.json();
    // The fault response must never leak the internal error message to the caller.
    assert.equal(json.error, "internal server error");
  } finally {
    faultServer.close();
  }
});
