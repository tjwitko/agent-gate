import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createHmac, randomBytes } from 'node:crypto';

import { mockClient } from 'aws-sdk-client-mock';
import { DynamoDBDocumentClient, PutCommand } from '@aws-sdk/lib-dynamodb';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import request from 'supertest';

import { createApp } from '../src/app.js';
import { createStore } from '../src/store.js';
import { createSecretsProvider } from '../src/secretsProvider.js';

const SIGNING_SECRET_ID = 'webhook/signing-secret';
const SUPPORT_TOKEN_SECRET_ID = 'webhook/support-token';
// Generated fresh per test run rather than a fixture string -- this stands in for a value that
// only ever lives in Secrets Manager, and never belongs in source as a literal.
const CURRENT_SECRET = randomBytes(32).toString('hex');

function sign(secret, body) {
  return 'sha256=' + createHmac('sha256', secret).update(body).digest('hex');
}

function buildApp() {
  const ddb = mockClient(DynamoDBDocumentClient);
  const secretsManager = mockClient(SecretsManagerClient);

  secretsManager.on(GetSecretValueCommand, { SecretId: SIGNING_SECRET_ID }).resolves({
    SecretString: JSON.stringify({ current: CURRENT_SECRET, previous: 'quarter-2-signing-secret' }),
  });
  secretsManager.on(GetSecretValueCommand, { SecretId: SUPPORT_TOKEN_SECRET_ID }).resolves({
    SecretString: 'support-team-token',
  });

  const store = createStore(ddb, 'webhook-callbacks');
  const secretsProvider = createSecretsProvider(secretsManager);
  const app = createApp({
    store,
    secretsProvider,
    signingSecretId: SIGNING_SECRET_ID,
    supportTokenSecretId: SUPPORT_TOKEN_SECRET_ID,
  });

  return { app, ddb, secretsManager };
}

test('a genuine callback with a valid signature is accepted and stored', async () => {
  const { app, ddb } = buildApp();
  ddb.on(PutCommand).resolves({});

  const payload = JSON.stringify({ event_id: 'evt_100', type: 'payment.succeeded' });
  const res = await request(app)
    .post('/webhooks/payment-provider')
    .set('Content-Type', 'application/json')
    .set('x-provider-signature', sign(CURRENT_SECRET, Buffer.from(payload)))
    .send(payload);

  assert.equal(res.status, 201);
  assert.equal(res.body.status, 'recorded');
  assert.equal(ddb.commandCalls(PutCommand).length, 1);
});

test('a forged callback with an invalid signature is rejected and never written', async () => {
  const { app, ddb } = buildApp();
  ddb.on(PutCommand).resolves({});

  const payload = JSON.stringify({ event_id: 'evt_101' });
  const res = await request(app)
    .post('/webhooks/payment-provider')
    .set('Content-Type', 'application/json')
    .set('x-provider-signature', 'sha256=' + 'a'.repeat(64))
    .send(payload);

  assert.equal(res.status, 401);
  assert.equal(ddb.commandCalls(PutCommand).length, 0);
});

test('a repeated delivery of an already-recorded event does not overwrite it', async () => {
  const { app, ddb } = buildApp();
  const conflict = new Error('conditional check failed');
  conflict.name = 'ConditionalCheckFailedException';
  ddb.on(PutCommand).rejects(conflict);

  const payload = JSON.stringify({ event_id: 'evt_102' });
  const res = await request(app)
    .post('/webhooks/payment-provider')
    .set('Content-Type', 'application/json')
    .set('x-provider-signature', sign(CURRENT_SECRET, Buffer.from(payload)))
    .send(payload);

  assert.equal(res.status, 200);
  assert.equal(res.body.status, 'already recorded');
  const calls = ddb.commandCalls(PutCommand);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].args[0].input.ConditionExpression, 'attribute_not_exists(event_id)');
});

test('a malformed body is reported as a client error, not a server fault', async () => {
  const { app, ddb } = buildApp();
  ddb.on(PutCommand).resolves({});

  const notJson = 'this is not json';
  const res = await request(app)
    .post('/webhooks/payment-provider')
    .set('Content-Type', 'application/json')
    .set('x-provider-signature', sign(CURRENT_SECRET, Buffer.from(notJson)))
    .send(notJson);

  assert.equal(res.status, 400);
  assert.equal(ddb.commandCalls(PutCommand).length, 0);
});

test('a request missing the signature header is a 400, not a 500', async () => {
  const { app } = buildApp();
  const payload = JSON.stringify({ event_id: 'evt_103' });

  const res = await request(app)
    .post('/webhooks/payment-provider')
    .set('Content-Type', 'application/json')
    .send(payload);

  assert.equal(res.status, 400);
});

test('a datastore fault is reported as a 500, distinct from a caller mistake', async () => {
  const { app, ddb } = buildApp();
  const fault = new Error('service unavailable');
  fault.name = 'ProvisionedThroughputExceededException';
  ddb.on(PutCommand).rejects(fault);

  const payload = JSON.stringify({ event_id: 'evt_104' });
  const res = await request(app)
    .post('/webhooks/payment-provider')
    .set('Content-Type', 'application/json')
    .set('x-provider-signature', sign(CURRENT_SECRET, Buffer.from(payload)))
    .send(payload);

  assert.equal(res.status, 500);
  // The internal exception name must never leak to the caller.
  assert.doesNotMatch(JSON.stringify(res.body), /ProvisionedThroughputExceededException/);
});

test('a signature from a just-rotated secret is accepted without a restart, via the forced refresh', async () => {
  const { app, ddb, secretsManager } = buildApp();
  ddb.on(PutCommand).resolves({});

  // Warm the process's cache with the pre-rotation secret pair, the way steady-state traffic
  // would before the provider ever rotates.
  const first = JSON.stringify({ event_id: 'evt_105' });
  const warmup = await request(app)
    .post('/webhooks/payment-provider')
    .set('Content-Type', 'application/json')
    .set('x-provider-signature', sign(CURRENT_SECRET, Buffer.from(first)))
    .send(first);
  assert.equal(warmup.status, 201);

  // The provider rotates: it now signs with a secret this process has never fetched. Reprogram
  // the mock to return the new pair, simulating what Secrets Manager holds after rotation.
  secretsManager.on(GetSecretValueCommand, { SecretId: SIGNING_SECRET_ID }).resolves({
    SecretString: JSON.stringify({ current: 'brand-new-secret', previous: CURRENT_SECRET }),
  });

  const second = JSON.stringify({ event_id: 'evt_106' });
  const res = await request(app)
    .post('/webhooks/payment-provider')
    .set('Content-Type', 'application/json')
    .set('x-provider-signature', sign('brand-new-secret', Buffer.from(second)))
    .send(second);

  // Verification succeeds only because a failed check against the cached secret triggers one
  // forced refetch before rejecting -- without it this would be a 401 until the process restarts.
  assert.equal(res.status, 201);
});

test('GET /healthz is open and returns 200', async () => {
  const { app } = buildApp();
  const res = await request(app).get('/healthz');
  assert.equal(res.status, 200);
});
