const REQUIRED_ENV = [
  "AWS_REGION",
  "DYNAMODB_TABLE_NAME",
  "SIGNING_SECRET_ID",
  "SUPPORT_TOKEN_SECRET_ID",
];

// Fails fast at startup rather than the first time a request happens to need the missing value --
// a misconfigured pod should crash-loop and get flagged by the deployment rollout, not serve
// traffic that silently can't verify signatures or reach the store.
export function loadConfig(env = process.env) {
  const missing = REQUIRED_ENV.filter((key) => !env[key]);
  if (missing.length > 0) {
    throw new Error(`missing required environment variable(s): ${missing.join(", ")}`);
  }

  return {
    port: Number(env.PORT) || 8080,
    awsRegion: env.AWS_REGION,
    tableName: env.DYNAMODB_TABLE_NAME,
    signingSecretId: env.SIGNING_SECRET_ID,
    supportTokenSecretId: env.SUPPORT_TOKEN_SECRET_ID,
    secretCacheTtlMs: Number(env.SECRET_CACHE_TTL_MS) || 5 * 60 * 1000,
  };
}
