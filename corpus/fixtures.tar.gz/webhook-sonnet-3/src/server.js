import { loadConfig } from './config.js';
import { createApp } from './app.js';
import { createDocClient, createSecretsManagerClient } from './awsClients.js';
import { createStore } from './store.js';
import { createSecretsProvider } from './secretsProvider.js';

const config = loadConfig();

const store = createStore(createDocClient(), config.tableName);
const secretsProvider = createSecretsProvider(createSecretsManagerClient());

const app = createApp({
  store,
  secretsProvider,
  signingSecretId: config.signingSecretId,
  supportTokenSecretId: config.supportTokenSecretId,
});

app.listen(config.port, () => {
  console.log(JSON.stringify({ level: 'info', msg: 'webhook-receiver listening', port: config.port }));
});
