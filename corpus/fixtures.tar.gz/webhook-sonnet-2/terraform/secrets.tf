# Only the *container* for each secret is declared here, deliberately with no
# aws_secretsmanager_secret_version -- an initial value belongs in state and in a .tf file even
# less than anywhere else. Set the first value out-of-band once, e.g.:
#   aws secretsmanager put-secret-value \
#     --secret-id "$(terraform output -raw webhook_signing_secret_id)" \
#     --secret-string "$(openssl rand -hex 32)"
# and thereafter through the provider's/your own rotation process.
resource "aws_secretsmanager_secret" "webhook_signing_secret" {
  name                    = "${var.app_name}/webhook-signing-secret"
  description             = "HMAC secret shared with the payment provider to sign callbacks. Rotated quarterly; Secrets Manager's own AWSCURRENT/AWSPREVIOUS staging keeps the outgoing value verifiable during the rollover window (see src/lib/secretStore.js)."
  recovery_window_in_days = 30
  kms_key_id              = aws_kms_key.app.arn
}

resource "aws_secretsmanager_secret" "support_api_token" {
  name                    = "${var.app_name}/support-api-token"
  description             = "Bearer token the support team's tooling presents to look up past callbacks."
  recovery_window_in_days = 30
  kms_key_id              = aws_kms_key.app.arn
}
