# webhook-haiku-7

- started: 2026-09-03T21:09Z
- model: haiku
- task: agent/fixtures/webhook-receiver-task.txt @ 4d80886

## Controls
- local-delegate-mcp: 85b304b
- terraform-guard-mcp: 8cea08e
- dep-audit-mcp: fc54029
- secret-guard-mcp: 35f85ea
- identity-guard-mcp: fd2eddc

Freeze the controls for the duration. A defect found mid-run goes in
docs/candidate-rules.md, not into the code — changing a gate while a run is live
means the run measured two different gates.
