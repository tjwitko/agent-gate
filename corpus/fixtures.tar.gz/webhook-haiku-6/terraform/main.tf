terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# VPC
resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name = "webhook-receiver-vpc"
  }
}

# Subnets for database
resource "aws_subnet" "db_a" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = "${var.aws_region}a"
  map_public_ip_on_launch = false

  tags = {
    Name = "webhook-receiver-db-a"
  }
}

resource "aws_subnet" "db_b" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.2.0/24"
  availability_zone       = "${var.aws_region}b"
  map_public_ip_on_launch = false

  tags = {
    Name = "webhook-receiver-db-b"
  }
}

# Subnets for application
resource "aws_subnet" "app_a" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.10.0/24"
  availability_zone       = "${var.aws_region}a"
  map_public_ip_on_launch = true

  tags = {
    Name = "webhook-receiver-app-a"
  }
}

resource "aws_subnet" "app_b" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.11.0/24"
  availability_zone       = "${var.aws_region}b"
  map_public_ip_on_launch = true

  tags = {
    Name = "webhook-receiver-app-b"
  }
}

# Internet Gateway
resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name = "webhook-receiver-igw"
  }
}

# Route table for app subnets
resource "aws_route_table" "app" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block      = "0.0.0.0/0"
    gateway_id      = aws_internet_gateway.main.id
  }

  tags = {
    Name = "webhook-receiver-app-rt"
  }
}

resource "aws_route_table_association" "app_a" {
  subnet_id      = aws_subnet.app_a.id
  route_table_id = aws_route_table.app.id
}

resource "aws_route_table_association" "app_b" {
  subnet_id      = aws_subnet.app_b.id
  route_table_id = aws_route_table.app.id
}

# Security group for RDS
resource "aws_security_group" "rds" {
  name        = "webhook-receiver-rds"
  description = "Security group for RDS database"
  vpc_id      = aws_vpc.main.id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.app.id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "webhook-receiver-rds"
  }
}

# Security group for application
resource "aws_security_group" "app" {
  name        = "webhook-receiver-app"
  description = "Security group for application"
  vpc_id      = aws_vpc.main.id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 8080
    to_port     = 8080
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "webhook-receiver-app"
  }
}

# DB Subnet Group
resource "aws_db_subnet_group" "webhooks" {
  name       = "webhook-receiver-subnet-group"
  subnet_ids = [aws_subnet.db_a.id, aws_subnet.db_b.id]

  tags = {
    Name = "webhook-receiver-db-subnet-group"
  }
}

# RDS PostgreSQL Database
resource "aws_db_instance" "webhooks" {
  identifier     = "webhook-receiver-db"
  engine         = "postgres"
  engine_version = "15.4"
  instance_class = "db.t4g.micro"

  db_name  = "webhooks"
  username = "webhook_user"
  password = var.db_password

  db_subnet_group_name   = aws_db_subnet_group.webhooks.name
  vpc_security_group_ids = [aws_security_group.rds.id]

  allocated_storage = 100

  storage_type      = "gp3"
  storage_encrypted = true
  kms_key_id        = aws_kms_key.rds.arn

  multi_az = true

  backup_retention_period = 35
  backup_window           = "03:00-04:00"
  maintenance_window      = "mon:04:00-mon:05:00"
  copy_tags_to_snapshot   = true

  skip_final_snapshot       = false
  final_snapshot_identifier = "webhook-receiver-final-snapshot-${formatdate("YYYY-MM-DD-hhmm", timestamp())}"

  deletion_protection = true

  enabled_cloudwatch_logs_exports = ["postgresql"]

  tags = {
    Name = "webhook-receiver-db"
  }

  depends_on = [aws_kms_key.rds]
}

# KMS key for RDS encryption
resource "aws_kms_key" "rds" {
  description             = "KMS key for RDS encryption"
  deletion_window_in_days = 10
  enable_key_rotation     = true

  lifecycle {
    prevent_destroy = true
  }

  tags = {
    Name = "webhook-receiver-rds-key"
  }
}

resource "aws_kms_alias" "rds" {
  name          = "alias/webhook-receiver-rds"
  target_key_id = aws_kms_key.rds.key_id
}

# EKS Cluster
resource "aws_eks_cluster" "main" {
  name     = "webhook-receiver"
  role_arn = aws_iam_role.eks_cluster.arn
  version  = "1.28"

  vpc_config {
    subnet_ids              = [aws_subnet.app_a.id, aws_subnet.app_b.id]
    security_group_ids      = [aws_security_group.app.id]
    endpoint_private_access = true
    endpoint_public_access  = false
  }

  enabled_cluster_log_types = ["api", "audit", "authenticator", "controllerManager", "scheduler"]

  depends_on = [
    aws_iam_role_policy_attachment.eks_cluster_policy
  ]

  tags = {
    Name = "webhook-receiver-cluster"
  }
}

# EKS Node Group
resource "aws_eks_node_group" "main" {
  cluster_name    = aws_eks_cluster.main.name
  node_group_name = "webhook-receiver-nodes"
  node_role_arn   = aws_iam_role.eks_node.arn
  subnet_ids      = [aws_subnet.app_a.id, aws_subnet.app_b.id]

  scaling_config {
    desired_size = 2
    max_size     = 4
    min_size     = 2
  }

  instance_types = ["t3.small"]

  tags = {
    Name = "webhook-receiver-nodes"
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_worker_node_policy,
    aws_iam_role_policy_attachment.eks_cni_policy,
    aws_iam_role_policy_attachment.eks_container_registry_policy
  ]
}

# IAM Role for EKS Cluster
resource "aws_iam_role" "eks_cluster" {
  name = "webhook-receiver-eks-cluster-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "eks.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "eks_cluster_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"
  role       = aws_iam_role.eks_cluster.name
}

# IAM Role for EKS Nodes
resource "aws_iam_role" "eks_node" {
  name = "webhook-receiver-eks-node-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ec2.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "eks_worker_node_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
  role       = aws_iam_role.eks_node.name
}

resource "aws_iam_role_policy_attachment" "eks_cni_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
  role       = aws_iam_role.eks_node.name
}

resource "aws_iam_role_policy_attachment" "eks_container_registry_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
  role       = aws_iam_role.eks_node.name
}

# AWS Backup Vault for long-term retention
resource "aws_backup_vault" "webhooks" {
  name = "webhook-receiver-vault"

  tags = {
    Name = "webhook-receiver-backup-vault"
  }
}

# Backup Plan for 7-year retention
resource "aws_backup_plan" "webhooks" {
  name = "webhook-receiver-7year-retention"

  rule {
    rule_name         = "daily_snapshots"
    target_vault_name = aws_backup_vault.webhooks.name
    schedule          = "cron(0 2 * * ? *)"

    lifecycle {
      cold_storage_after = 30
      delete_after       = 2555
    }

    recovery_point_tags = {
      Name = "webhook-receiver-backup"
    }
  }

  tags = {
    Name = "webhook-receiver-backup-plan"
  }
}

# Backup Selection for RDS
resource "aws_backup_selection" "webhooks" {
  name         = "webhook-receiver-db-selection"
  plan_id      = aws_backup_plan.webhooks.id
  iam_role_arn = aws_iam_role.backup.arn

  resources = [
    aws_db_instance.webhooks.arn
  ]
}

# IAM Role for AWS Backup
resource "aws_iam_role" "backup" {
  name = "webhook-receiver-backup-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "backup.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "backup_policy" {
  role       = aws_iam_role.backup.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSBackupServiceRolePolicyForBackup"
}

resource "aws_iam_role_policy_attachment" "restore_policy" {
  role       = aws_iam_role.backup.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSBackupServiceRolePolicyForRestores"
}

# CloudWatch Log Group for RDS
resource "aws_cloudwatch_log_group" "rds_postgres" {
  name              = "/aws/rds/instance/webhook-receiver-db/postgresql"
  retention_in_days = 30

  tags = {
    Name = "webhook-receiver-rds-logs"
  }
}
