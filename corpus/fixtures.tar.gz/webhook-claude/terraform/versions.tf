terraform {
  required_version = ">= 1.7.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.60"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
    tls = {
      source  = "hashicorp/tls"
      version = "~> 4.0"
    }
  }

  # Remote state is expected in production (an S3 backend with a DynamoDB lock table); left
  # unconfigured here so this root plans standalone in any environment, including this review.
  # backend "s3" {}
}
