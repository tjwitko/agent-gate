import { constantTimeEqual } from '../signature.js';
import { unauthorized } from '../errors.js';

const BEARER_RE = /^Bearer\s+(.+)$/i;

/**
 * Only the support team may read past callbacks. The provider is the only party that may submit
 * them, and that is enforced separately by the signature check on the write path — this is the
 * other half, gating every read behind a credential the provider never sees.
 */
export function createRequireSupportAuth(secretsProvider, supportTokenSecretId) {
  return async function requireSupportAuth(req, res, next) {
    try {
      const header = req.get('authorization') || '';
      const match = BEARER_RE.exec(header);
      if (!match) {
        next(unauthorized('a support bearer token is required'));
        return;
      }

      const provided = match[1];
      let expected = await secretsProvider.getSupportToken(supportTokenSecretId);
      if (!expected || !constantTimeEqual(Buffer.from(provided), Buffer.from(expected))) {
        // The token in hand may simply be stale relative to a recent rotation — refetch once
        // before rejecting, the same courtesy the signature check gets on the write path.
        expected = await secretsProvider.getSupportToken(supportTokenSecretId, { forceRefresh: true });
      }
      if (!expected || !constantTimeEqual(Buffer.from(provided), Buffer.from(expected))) {
        next(unauthorized('invalid support token'));
        return;
      }

      next();
    } catch (err) {
      next(err);
    }
  };
}
