import { randomUUID } from "crypto";
import { createServer } from "http";
import { ClientError } from "./lib/errors.js";
import { logger } from "./lib/logger.js";

const MAX_BODY_BYTES = 1024 * 1024; // 1 MiB is generous for a payment event payload.

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new ClientError(413, "request body too large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", (err) => reject(err));
  });
}

function respondJson(res, statusCode, body) {
  const payload = JSON.stringify(body);
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(payload),
  });
  res.end(payload);
}

// The load balancer's health check and, separately, the provider's callback both need to work
// with no support-team credential in play, so this route is intentionally unauthenticated.
function handleHealth(res) {
  respondJson(res, 200, { status: "ok" });
}

async function handleWebhook(req, res, webhookService) {
  const rawBody = await readRawBody(req);
  const signatureHeader = req.headers["x-webhook-signature"];
  const result = await webhookService.receive(rawBody, signatureHeader);
  // A first delivery is genuinely new (201); a redelivery of an event id already on file is
  // acknowledged the same way -- 2xx, so the provider doesn't treat it as a failure and retry
  // again -- but distinguished in the body and status so a caller can tell the two apart.
  respondJson(res, result.stored ? 201 : 200, {
    eventId: result.eventId,
    stored: result.stored,
    duplicate: !result.stored,
  });
}

async function handleGetCallback(req, res, eventId, webhookService, supportAuth) {
  const authResult = await supportAuth(req.headers.authorization);
  if (!authResult.authorized) {
    throw new ClientError(
      authResult.reason === "invalid token" ? 403 : 401,
      "not authorized to read past callbacks"
    );
  }
  const record = await webhookService.getByEventId(decodeURIComponent(eventId));
  respondJson(res, 200, record);
}

function handleError(err, res, requestId) {
  if (err instanceof ClientError) {
    logger.clientError(err.message, { requestId, statusCode: err.statusCode });
    respondJson(res, err.statusCode, { error: err.message, requestId });
    return;
  }
  // Anything else is a fault in this service, not something the caller did -- logged and reported
  // distinctly from a ClientError so a bad request from the provider is never mistaken for us
  // failing (see logger.js).
  logger.fault(err && err.message ? err.message : String(err), {
    requestId,
    stack: err && err.stack,
  });
  respondJson(res, 500, { error: "internal server error", requestId });
}

const CALLBACK_PATH = /^\/callbacks\/([^/]+)$/;

// Dependencies are injected rather than constructed here so this file never imports an AWS SDK
// module -- server.js wires it to the real Secrets-Manager/DynamoDB-backed services, tests wire
// it to fakes, and either way `node --test` never needs a package that isn't already part of
// Node itself.
export function createApp({ webhookService, supportAuth }) {
  return createServer((req, res) => {
    const requestId = randomUUID();
    const url = new URL(req.url, "http://localhost");

    Promise.resolve()
      .then(() => {
        if (req.method === "GET" && (url.pathname === "/healthz" || url.pathname === "/health")) {
          return handleHealth(res);
        }
        if (req.method === "POST" && url.pathname === "/webhooks/payment-provider") {
          return handleWebhook(req, res, webhookService);
        }
        const match = CALLBACK_PATH.exec(url.pathname);
        if (req.method === "GET" && match) {
          return handleGetCallback(req, res, match[1], webhookService, supportAuth);
        }
        throw new ClientError(404, "not found");
      })
      .catch((err) => handleError(err, res, requestId));
  });
}
