import { test } from 'node:test';
import assert from 'node:assert';
import { createHmac } from 'crypto';
import request from 'supertest';
import { rm } from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const testDbPath = path.join(__dirname, '../data/test-callbacks.db');

// Override DB path for tests BEFORE importing app
process.env.DB_PATH = testDbPath;
process.env.SIGNING_SECRET = 'test-signing-key';
process.env.SUPPORT_AUTH_TOKEN = 'test-support-token';

import app from './app.js';

async function cleanupTestDB() {
  try {
    await rm(testDbPath);
  } catch (e) {
    // File may not exist yet
  }
}

// Clean up before all tests
await cleanupTestDB();

function createSignature(body, timestamp, secret) {
  const message = `${timestamp}.${body}`;
  return createHmac('sha256', secret)
    .update(message)
    .digest('hex');
}

function createWebhookPayload(eventId = 'evt_123') {
  return JSON.stringify({
    event_id: eventId,
    event_type: 'payment.completed',
    amount: 10000,
    currency: 'USD',
    timestamp: new Date().toISOString()
  });
}

test('Health endpoint returns 200', async () => {
  const response = await request(app).get('/health');
  assert.strictEqual(response.status, 200);
  assert.strictEqual(response.body.status, 'ok');
});

test('Webhook with valid signature is accepted', async () => {
  const payload = createWebhookPayload('evt_valid_sig_' + Date.now());
  const timestamp = Date.now().toString();
  const signature = createSignature(payload, timestamp, 'test-signing-key');

  const response = await request(app)
    .post('/webhook')
    .set('x-webhook-signature', signature)
    .set('x-webhook-timestamp', timestamp)
    .set('Content-Type', 'application/json')
    .send(payload);

  assert.strictEqual(response.status, 201);
  assert.strictEqual(response.body.received, true);
  assert.ok(response.body.callback_id);
});

test('Webhook with invalid signature is rejected', async () => {
  const payload = createWebhookPayload('evt_invalid_sig_' + Date.now());
  const timestamp = Date.now().toString();
  const invalidSignature = 'invalid-signature-here';

  const response = await request(app)
    .post('/webhook')
    .set('x-webhook-signature', invalidSignature)
    .set('x-webhook-timestamp', timestamp)
    .set('Content-Type', 'application/json')
    .send(payload);

  assert.strictEqual(response.status, 401);
  assert.strictEqual(response.body.error, 'Invalid signature');
});

test('Webhook without signature header is rejected', async () => {
  const payload = createWebhookPayload('evt_no_sig_' + Date.now());

  const response = await request(app)
    .post('/webhook')
    .set('Content-Type', 'application/json')
    .send(payload);

  assert.strictEqual(response.status, 400);
  assert.ok(response.body.error);
});

test('Webhook without event_id is rejected', async () => {
  const payload = JSON.stringify({
    event_type: 'payment.completed',
    amount: 10000
  });
  const timestamp = Date.now().toString();
  const signature = createSignature(payload, timestamp, 'test-signing-key');

  const response = await request(app)
    .post('/webhook')
    .set('x-webhook-signature', signature)
    .set('x-webhook-timestamp', timestamp)
    .set('Content-Type', 'application/json')
    .send(payload);

  assert.strictEqual(response.status, 400);
  assert.strictEqual(response.body.error, 'Missing event_id in payload');
});

test('Duplicate event_id returns error and does not overwrite', async () => {
  const eventId = 'evt_duplicate_' + Date.now();
  const payload1 = createWebhookPayload(eventId);
  const timestamp1 = Date.now().toString();
  const signature1 = createSignature(payload1, timestamp1, 'test-signing-key');

  // Send first callback
  const response1 = await request(app)
    .post('/webhook')
    .set('x-webhook-signature', signature1)
    .set('x-webhook-timestamp', timestamp1)
    .set('Content-Type', 'application/json')
    .send(payload1);

  assert.strictEqual(response1.status, 201);

  // Try to send duplicate with different data
  const payload2 = JSON.stringify({
    event_id: eventId,
    event_type: 'payment.refunded',
    amount: 5000,
    timestamp: new Date().toISOString()
  });
  const timestamp2 = (Date.now() + 1000).toString();
  const signature2 = createSignature(payload2, timestamp2, 'test-signing-key');

  const response2 = await request(app)
    .post('/webhook')
    .set('x-webhook-signature', signature2)
    .set('x-webhook-timestamp', timestamp2)
    .set('Content-Type', 'application/json')
    .send(payload2);

  assert.strictEqual(response2.status, 409);

  // Query the original callback - it should be unchanged
  const queryResponse = await request(app)
    .get(`/callbacks/${eventId}`)
    .set('Authorization', 'Bearer test-support-token');

  assert.strictEqual(queryResponse.status, 200);
  const originalPayload = JSON.parse(queryResponse.body.payload);
  assert.strictEqual(originalPayload.event_type, 'payment.completed');
  assert.strictEqual(originalPayload.amount, 10000);
});

test('Support team can retrieve callback by event_id', async () => {
  const eventId = 'evt_query_' + Date.now();
  const payload = createWebhookPayload(eventId);
  const timestamp = Date.now().toString();
  const signature = createSignature(payload, timestamp, 'test-signing-key');

  // Record callback
  await request(app)
    .post('/webhook')
    .set('x-webhook-signature', signature)
    .set('x-webhook-timestamp', timestamp)
    .set('Content-Type', 'application/json')
    .send(payload);

  // Query with valid auth token
  const queryResponse = await request(app)
    .get(`/callbacks/${eventId}`)
    .set('Authorization', 'Bearer test-support-token');

  assert.strictEqual(queryResponse.status, 200);
  assert.ok(queryResponse.body.id);
  assert.strictEqual(queryResponse.body.event_id, eventId);
  assert.ok(queryResponse.body.payload);
  assert.ok(queryResponse.body.signature);
});

test('Query without auth token is rejected', async () => {
  const response = await request(app)
    .get('/callbacks/evt_123');

  assert.strictEqual(response.status, 401);
});

test('Query with invalid auth token is rejected', async () => {
  const response = await request(app)
    .get('/callbacks/evt_123')
    .set('Authorization', 'Bearer invalid-token');

  assert.strictEqual(response.status, 401);
});

test('Query for non-existent callback returns 404', async () => {
  const response = await request(app)
    .get('/callbacks/evt_nonexistent')
    .set('Authorization', 'Bearer test-support-token');

  assert.strictEqual(response.status, 404);
});

test('Invalid JSON in payload is rejected', async () => {
  const payload = 'not valid json';
  const timestamp = Date.now().toString();
  const signature = createSignature(payload, timestamp, 'test-signing-key');

  const response = await request(app)
    .post('/webhook')
    .set('x-webhook-signature', signature)
    .set('x-webhook-timestamp', timestamp)
    .set('Content-Type', 'application/json')
    .send(payload);

  assert.strictEqual(response.status, 400);
  assert.strictEqual(response.body.error, 'Invalid JSON in request body');
});
