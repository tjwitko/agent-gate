/** Splits a duration in milliseconds into whole days, hours, minutes and seconds. */
export function breakdown(ms) {
  if (!Number.isFinite(ms) || ms < 0) throw new RangeError("ms must be a non-negative finite number");
  const seconds = Math.floor(ms / 1000);
  return {
    days: Math.floor(seconds / 86400),
    hours: Math.floor((seconds % 86400) / 3600),
    minutes: Math.floor((seconds % 3600) / 60),
    seconds: seconds % 60,
  };
}

/** Renders a duration as "2d 3h 4m", omitting leading zero units. Always returns at least "0s". */
export function humanize(ms) {
  const { days, hours, minutes, seconds } = breakdown(ms);
  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (minutes) parts.push(`${minutes}m`);
  if (seconds || parts.length === 0) parts.push(`${seconds}s`);
  return parts.join(" ");
}
