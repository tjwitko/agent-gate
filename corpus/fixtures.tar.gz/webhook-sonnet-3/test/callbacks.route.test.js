import { test } from 'node:test';
import assert from 'node:assert/strict';

import { mockClient } from 'aws-sdk-client-mock';
import { DynamoDBDocumentClient, GetCommand } from '@aws-sdk/lib-dynamodb';
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import request from 'supertest';

import { createApp } from '../src/app.js';
import { createStore } from '../src/store.js';
import { createSecretsProvider } from '../src/secretsProvider.js';

const SIGNING_SECRET_ID = 'webhook/signing-secret';
const SUPPORT_TOKEN_SECRET_ID = 'webhook/support-token';
const SUPPORT_TOKEN = 'support-team-token';

function buildApp() {
  const ddb = mockClient(DynamoDBDocumentClient);
  const secretsManager = mockClient(SecretsManagerClient);

  secretsManager.on(GetSecretValueCommand, { SecretId: SIGNING_SECRET_ID }).resolves({
    SecretString: JSON.stringify({ current: 'x', previous: null }),
  });
  secretsManager.on(GetSecretValueCommand, { SecretId: SUPPORT_TOKEN_SECRET_ID }).resolves({
    SecretString: SUPPORT_TOKEN,
  });

  const store = createStore(ddb, 'webhook-callbacks');
  const secretsProvider = createSecretsProvider(secretsManager);
  const app = createApp({
    store,
    secretsProvider,
    signingSecretId: SIGNING_SECRET_ID,
    supportTokenSecretId: SUPPORT_TOKEN_SECRET_ID,
  });

  return { app, ddb };
}

test('a lookup with no bearer token is rejected', async () => {
  const { app } = buildApp();
  const res = await request(app).get('/callbacks/evt_1');
  assert.equal(res.status, 401);
});

test('a lookup with the wrong bearer token is rejected', async () => {
  const { app } = buildApp();
  const res = await request(app).get('/callbacks/evt_1').set('Authorization', 'Bearer not-the-token');
  assert.equal(res.status, 401);
});

test('a lookup with a valid support token returns the stored callback', async () => {
  const { app, ddb } = buildApp();
  ddb.on(GetCommand).resolves({
    Item: { event_id: 'evt_1', received_at: '2026-01-01T00:00:00.000Z', raw_body: '{"event_id":"evt_1"}' },
  });

  const res = await request(app).get('/callbacks/evt_1').set('Authorization', `Bearer ${SUPPORT_TOKEN}`);
  assert.equal(res.status, 200);
  assert.equal(res.body.event_id, 'evt_1');
});

test('a lookup for an unknown event id returns 404, not 401 or 500', async () => {
  const { app, ddb } = buildApp();
  ddb.on(GetCommand).resolves({});

  const res = await request(app).get('/callbacks/unknown').set('Authorization', `Bearer ${SUPPORT_TOKEN}`);
  assert.equal(res.status, 404);
});
