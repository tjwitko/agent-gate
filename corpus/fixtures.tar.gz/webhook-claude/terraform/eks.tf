resource "aws_iam_role" "eks_cluster" {
  name = "${var.project_name}-eks-cluster-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "eks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "eks_cluster_policy" {
  role       = aws_iam_role.eks_cluster.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"
}

# Required for the cluster's Kubernetes Secrets envelope encryption (encryption_config below) —
# EKS uses this role to call kms:Encrypt/Decrypt/DescribeKey against the CMK on every Secret
# read and write.
resource "aws_iam_role_policy" "eks_cluster_kms" {
  name = "eks-cluster-kms-secrets-encryption"
  role = aws_iam_role.eks_cluster.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["kms:Encrypt", "kms:Decrypt", "kms:DescribeKey", "kms:CreateGrant"]
      Resource = aws_kms_key.app.arn
    }]
  })
}

resource "aws_cloudwatch_log_group" "eks_cluster" {
  name              = "/aws/eks/${var.project_name}-eks/cluster"
  retention_in_days = 400
  kms_key_id        = aws_kms_key.app.arn
}

# The Kubernetes API server endpoint is private-only: reachable from inside this VPC (and
# anything peered or VPN'd into it), never from the public internet. This is a payment-data
# system, so the control plane gets the same "no public exposure" treatment as the data it fronts
# — applying manifests or running `helm install` requires a runner inside the VPC (a CI runner
# with VPC connectivity, a bastion, or SSM Session Manager port-forwarding). The public HTTP
# endpoint the provider actually calls is the NLB in front of the webhook-ingest Service
# (k8s/03-webhook-ingest-service.yaml), which is a completely separate thing from this API server.
resource "aws_eks_cluster" "this" {
  name     = "${var.project_name}-eks"
  role_arn = aws_iam_role.eks_cluster.arn
  version  = var.eks_cluster_version

  vpc_config {
    subnet_ids              = concat(aws_subnet.public[*].id, aws_subnet.private[*].id)
    endpoint_private_access = true
    endpoint_public_access  = false
  }

  enabled_cluster_log_types = ["api", "audit", "authenticator", "controllerManager", "scheduler"]

  encryption_config {
    resources = ["secrets"]
    provider {
      key_arn = aws_kms_key.app.arn
    }
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_cluster_policy,
    aws_cloudwatch_log_group.eks_cluster,
  ]
}
