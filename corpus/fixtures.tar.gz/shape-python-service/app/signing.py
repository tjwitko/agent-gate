"""Signature helpers. Deliberately standard-library only: the gate never installs dependencies,
so a test that imports Flask could not run on any machine that had not already installed it."""

import hashlib
import hmac


def sign(secret: str, payload: bytes) -> str:
    """Returns the hex HMAC-SHA256 of payload under secret."""
    if not secret:
        raise ValueError("secret must not be empty")
    return hmac.new(secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()


def verify(secret: str, payload: bytes, signature: str) -> bool:
    """Constant-time comparison, so a caller cannot learn the signature one byte at a time."""
    return hmac.compare_digest(sign(secret, payload), signature)
