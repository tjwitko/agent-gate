require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const pino = require('pino');
const { Pool } = require('pg');

const logger = pino();
const app = express();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

app.use(express.json());

pool.on('error', (err) => {
  logger.error({ err }, 'Unexpected error on idle client');
});

const verifySignature = (payload, signature, secret) => {
  const computed = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
  return crypto.timingSafeEqual(
    Buffer.from(computed),
    Buffer.from(signature)
  );
};

const getCurrentSecret = async () => {
  const result = await pool.query(
    'SELECT secret FROM signing_secrets WHERE active = true ORDER BY created_at DESC LIMIT 1'
  );
  if (result.rows.length === 0) {
    throw new Error('No active signing secret found');
  }
  return result.rows[0].secret;
};

const getPreviousSecrets = async (days = 90) => {
  const result = await pool.query(
    `SELECT secret FROM signing_secrets
     WHERE created_at > NOW() - INTERVAL '1 day' * $1
     ORDER BY created_at DESC`,
    [days]
  );
  return result.rows.map(row => row.secret);
};

app.post('/webhook', async (req, res) => {
  try {
    const signature = req.headers['x-provider-signature'];
    const eventId = req.headers['x-event-id'];

    if (!signature || !eventId) {
      logger.info({ headers: req.headers }, 'Missing required headers');
      return res.status(400).json({
        error: 'Missing required headers: x-provider-signature, x-event-id'
      });
    }

    const payload = JSON.stringify(req.body);

    let isValid = false;
    let usedSecret = null;

    try {
      const currentSecret = await getCurrentSecret();
      if (verifySignature(payload, signature, currentSecret)) {
        isValid = true;
        usedSecret = currentSecret;
      }
    } catch (err) {
      logger.error({ err }, 'Failed to verify with current secret');
    }

    if (!isValid) {
      const previousSecrets = await getPreviousSecrets();
      for (const secret of previousSecrets) {
        try {
          if (verifySignature(payload, signature, secret)) {
            isValid = true;
            usedSecret = secret;
            break;
          }
        } catch (err) {
          continue;
        }
      }
    }

    if (!isValid) {
      logger.warn({ eventId, signature }, 'Signature verification failed');
      return res.status(401).json({ error: 'Signature verification failed' });
    }

    const existingEvent = await pool.query(
      'SELECT event_id FROM webhook_events WHERE event_id = $1',
      [eventId]
    );

    if (existingEvent.rows.length > 0) {
      logger.info({ eventId }, 'Duplicate webhook received');
      return res.status(200).json({
        status: 'duplicate',
        message: 'Event already recorded'
      });
    }

    await pool.query(
      `INSERT INTO webhook_events (event_id, payload, signature, received_at)
       VALUES ($1, $2, $3, NOW())`,
      [eventId, payload, signature]
    );

    logger.info({ eventId }, 'Webhook recorded successfully');
    res.status(201).json({ status: 'recorded', event_id: eventId });
  } catch (err) {
    logger.error({ err }, 'Internal server error processing webhook');
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/webhook/:eventId', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing or invalid authorization' });
    }

    const token = authHeader.slice(7);
    const supportToken = process.env.SUPPORT_TOKEN;

    if (!supportToken) {
      logger.error({}, 'Support token not configured');
      return res.status(500).json({ error: 'Internal server error' });
    }

    try {
      if (!crypto.timingSafeEqual(Buffer.from(token), Buffer.from(supportToken))) {
        logger.warn({ eventId: req.params.eventId }, 'Unauthorized read attempt');
        return res.status(403).json({ error: 'Forbidden' });
      }
    } catch (err) {
      logger.warn({ eventId: req.params.eventId }, 'Unauthorized read attempt');
      return res.status(403).json({ error: 'Forbidden' });
    }

    const { eventId } = req.params;
    const result = await pool.query(
      'SELECT event_id, payload, received_at FROM webhook_events WHERE event_id = $1',
      [eventId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Event not found' });
    }

    const event = result.rows[0];
    res.json({
      event_id: event.event_id,
      payload: JSON.parse(event.payload),
      received_at: event.received_at
    });
  } catch (err) {
    logger.error({ err }, 'Internal server error reading webhook');
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/health', (req, res) => {
  res.json({ status: 'healthy' });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  logger.info({ port: PORT }, 'Webhook receiver started');
});

module.exports = app;
