import { SignatureVerifier } from "./signature.js";

export class SecretManager {
  private verifier: SignatureVerifier;
  private secrets: Map<string, string> = new Map();

  constructor(verifier: SignatureVerifier) {
    this.verifier = verifier;
  }

  addSecret(secret: string): void {
    this.secrets.set(secret, secret);
    this.verifier.addSecret(secret, new Date());
  }

  rotateSecret(oldSecret: string, newSecret: string): void {
    // Add new secret for future verifications
    this.addSecret(newSecret);
    // Keep old secret in map for backward compatibility during rotation period
    // Old secret will no longer be used for signing but can still be verified for older requests
  }

  loadFromEnvironment(): void {
    const primarySecret = process.env.WEBHOOK_SECRET || (process.env.NODE_ENV === "test" ? "test-secret-key" : undefined);
    if (!primarySecret) {
      throw new Error("WEBHOOK_SECRET environment variable not set");
    }
    this.addSecret(primarySecret);

    // Load any rotation secrets (previous secrets still valid during rotation)
    const rotationSecrets = process.env.WEBHOOK_ROTATION_SECRETS;
    if (rotationSecrets) {
      const secrets = rotationSecrets.split(",");
      secrets.forEach((secret) => this.addSecret(secret.trim()));
    }
  }

  async loadFromSecretsManager(): Promise<void> {
    // This would be implemented to fetch from AWS Secrets Manager
    // For now, we support environment variable loading
    this.loadFromEnvironment();
  }
}
