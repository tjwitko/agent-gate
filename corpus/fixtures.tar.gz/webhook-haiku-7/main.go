package main

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
)

type App struct {
	db              *dynamodb.Client
	signingSecrets  map[string]string // secret ID -> secret value
	apiKey          string             // for support team lookups
	callbacksTable  string
	secretsTable    string
}

type Callback struct {
	EventID   string    `dynamodb:"event_id" json:"event_id"`
	Timestamp time.Time `dynamodb:"timestamp" json:"timestamp"`
	Signature string    `dynamodb:"signature" json:"signature"`
	Body      string    `dynamodb:"body" json:"body"`
	Provider  string    `dynamodb:"provider" json:"provider"`
}

type ErrorResponse struct {
	Error string `json:"error"`
	Code  string `json:"code"`
}

type LookupResponse struct {
	Callback *Callback `json:"callback,omitempty"`
	Error    string    `json:"error,omitempty"`
}

func newApp(ctx context.Context) (*App, error) {
	cfg, err := config.LoadDefaultConfig(ctx)
	if err != nil {
		return nil, fmt.Errorf("load aws config: %w", err)
	}

	db := dynamodb.NewFromConfig(cfg)
	app := &App{
		db:             db,
		callbacksTable: os.Getenv("CALLBACKS_TABLE"),
		secretsTable:   os.Getenv("SECRETS_TABLE"),
		apiKey:         os.Getenv("API_KEY"),
		signingSecrets: make(map[string]string),
	}

	if app.callbacksTable == "" {
		app.callbacksTable = "webhook-callbacks"
	}
	if app.secretsTable == "" {
		app.secretsTable = "webhook-secrets"
	}

	if err := app.loadSecrets(ctx); err != nil {
		return nil, fmt.Errorf("load signing secrets: %w", err)
	}

	return app, nil
}

func (a *App) loadSecrets(ctx context.Context) error {
	out, err := a.db.Scan(ctx, &dynamodb.ScanInput{
		TableName: &a.secretsTable,
	})
	if err != nil {
		return fmt.Errorf("scan secrets table: %w", err)
	}

	for _, item := range out.Items {
		var secret struct {
			SecretID string `dynamodb:"secret_id"`
			Value    string `dynamodb:"value"`
			Active   bool   `dynamodb:"active"`
		}
		if err := attributevalue.UnmarshalMap(item, &secret); err != nil {
			continue
		}
		if secret.Active {
			a.signingSecrets[secret.SecretID] = secret.Value
		}
	}

	return nil
}

func (a *App) handleWebhook(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "METHOD_NOT_ALLOWED", "Method not allowed")
		return
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		writeError(w, http.StatusBadRequest, "BAD_REQUEST", "Failed to read request body")
		return
	}
	defer r.Body.Close()

	sig := r.Header.Get("X-Webhook-Signature")
	if sig == "" {
		writeError(w, http.StatusUnauthorized, "MISSING_SIGNATURE", "Missing X-Webhook-Signature header")
		return
	}

	sigID := r.Header.Get("X-Signature-ID")
	if sigID == "" {
		writeError(w, http.StatusUnauthorized, "MISSING_SIGNATURE_ID", "Missing X-Signature-ID header")
		return
	}

	secret, exists := a.signingSecrets[sigID]
	if !exists {
		writeError(w, http.StatusUnauthorized, "INVALID_SIGNATURE_ID", "Unknown signature ID")
		return
	}

	// Verify HMAC-SHA256
	expected := hmac.New(sha256.New, []byte(secret))
	expected.Write(body)
	expectedSig := hex.EncodeToString(expected.Sum(nil))

	if !hmac.Equal([]byte(sig), []byte(expectedSig)) {
		writeError(w, http.StatusUnauthorized, "INVALID_SIGNATURE", "Invalid signature")
		return
	}

	// Parse event to get event_id
	var event map[string]interface{}
	if err := json.Unmarshal(body, &event); err != nil {
		writeError(w, http.StatusBadRequest, "INVALID_JSON", "Invalid JSON in request body")
		return
	}

	eventID, ok := event["event_id"].(string)
	if !ok || eventID == "" {
		writeError(w, http.StatusBadRequest, "MISSING_EVENT_ID", "Missing or invalid event_id in body")
		return
	}

	// Store callback (idempotent - duplicate event_ids overwrite)
	callback := Callback{
		EventID:   eventID,
		Timestamp: time.Now().UTC(),
		Signature: sig,
		Body:      string(body),
		Provider:  "payment-provider",
	}

	item, err := attributevalue.MarshalMap(callback)
	if err != nil {
		log.Printf("Marshal callback: %v", err)
		writeError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Failed to process callback")
		return
	}

	immutabilityProtection := "attribute_not_exists(event_id)"
	_, err = a.db.PutItem(r.Context(), &dynamodb.PutItemInput{
		TableName:           &a.callbacksTable,
		Item:                item,
		ConditionExpression: &immutabilityProtection,
	})
	if err != nil {
		if strings.Contains(err.Error(), "ConditionalCheckFailedException") {
			writeError(w, http.StatusConflict, "DUPLICATE_EVENT", "Event already recorded")
			return
		}
		log.Printf("Store callback: %v", err)
		writeError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Failed to store callback")
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
}

func (a *App) handleLookup(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "METHOD_NOT_ALLOWED", "Method not allowed")
		return
	}

	// Check API key
	authHeader := r.Header.Get("Authorization")
	expectedAuth := "Bearer " + a.apiKey
	if authHeader != expectedAuth {
		writeError(w, http.StatusUnauthorized, "INVALID_AUTH", "Invalid or missing authorization")
		return
	}

	eventID := r.URL.Query().Get("event_id")
	if eventID == "" {
		writeError(w, http.StatusBadRequest, "MISSING_EVENT_ID", "Missing event_id query parameter")
		return
	}

	out, err := a.db.GetItem(r.Context(), &dynamodb.GetItemInput{
		TableName: &a.callbacksTable,
		Key: map[string]types.AttributeValue{
			"event_id": &types.AttributeValueMemberS{Value: eventID},
		},
	})
	if err != nil {
		log.Printf("Get item: %v", err)
		writeError(w, http.StatusInternalServerError, "INTERNAL_ERROR", "Failed to retrieve callback")
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	if out.Item == nil {
		json.NewEncoder(w).Encode(LookupResponse{Error: "Not found"})
		return
	}

	var callback Callback
	if err := attributevalue.UnmarshalMap(out.Item, &callback); err != nil {
		log.Printf("Unmarshal callback: %v", err)
		json.NewEncoder(w).Encode(LookupResponse{Error: "Failed to unmarshal callback"})
		return
	}

	json.NewEncoder(w).Encode(LookupResponse{Callback: &callback})
}

func (a *App) handleHealth(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(map[string]string{"status": "healthy"})
}

func writeError(w http.ResponseWriter, status int, code, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(ErrorResponse{
		Error: message,
		Code:  code,
	})
}

func main() {
	ctx := context.Background()
	app, err := newApp(ctx)
	if err != nil {
		log.Fatalf("Initialize app: %v", err)
	}

	http.HandleFunc("/webhook", app.handleWebhook)
	http.HandleFunc("/lookup", app.handleLookup)
	http.HandleFunc("/health", app.handleHealth)

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	log.Printf("Starting webhook receiver on port %s", port)
	if err := http.ListenAndServe(":"+port, nil); err != nil {
		log.Fatalf("Listen: %v", err)
	}
}
