variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name"
  type        = string
}

variable "vpc_cidr" {
  description = "CIDR block for VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "availability_zones" {
  description = "List of availability zones"
  type        = list(string)
  default     = ["us-east-1a", "us-east-1b", "us-east-1c"]
}

variable "db_name" {
  description = "Database name"
  type        = string
  default     = "webhook_receiver"
}

variable "db_username" {
  description = "Database username"
  type        = string
  default     = "webhookadmin"
  sensitive   = true
}

variable "db_password" {
  description = "Database password"
  type        = string
  sensitive   = true
}

variable "retention_days" {
  description = "RDS backup retention days"
  type        = number
  default     = 30
}

variable "backup_window" {
  description = "RDS backup window (UTC)"
  type        = string
  default     = "03:00-04:00"
}

variable "eks_cluster_version" {
  description = "EKS cluster version"
  type        = string
  default     = "1.28"
}

variable "node_group_desired_size" {
  description = "EKS node group desired size"
  type        = number
  default     = 3
}

variable "node_group_min_size" {
  description = "EKS node group minimum size"
  type        = number
  default     = 1
}

variable "node_group_max_size" {
  description = "EKS node group maximum size"
  type        = number
  default     = 10
}

variable "node_instance_types" {
  description = "EKS node instance types"
  type        = list(string)
  default     = ["t3.medium"]
}
