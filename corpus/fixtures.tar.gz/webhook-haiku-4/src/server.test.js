const request = require('supertest');
const crypto = require('crypto');
const { Pool } = require('pg');

let app;
let pool;

const TEST_SECRET = 'test-signing-secret-' + Date.now();
const TEST_TOKEN = 'support-token-' + Date.now();

beforeAll(async () => {
  process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
  if (!process.env.TEST_DATABASE_URL) {
    throw new Error('TEST_DATABASE_URL environment variable must be set to run tests');
  }
  process.env.SUPPORT_TOKEN = TEST_TOKEN;

  pool = new Pool({
    connectionString: process.env.DATABASE_URL,
  });

  app = require('./server');

  await pool.query('DROP TABLE IF EXISTS webhook_events');
  await pool.query('DROP TABLE IF EXISTS signing_secrets');

  await pool.query(`
    CREATE TABLE signing_secrets (
      id SERIAL PRIMARY KEY,
      secret TEXT NOT NULL UNIQUE,
      active BOOLEAN DEFAULT true,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE webhook_events (
      id BIGSERIAL PRIMARY KEY,
      event_id TEXT NOT NULL UNIQUE,
      payload TEXT NOT NULL,
      signature TEXT NOT NULL,
      received_at TIMESTAMP DEFAULT NOW() NOT NULL,
      created_at TIMESTAMP DEFAULT NOW() NOT NULL
    )
  `);

  await pool.query('CREATE INDEX idx_webhook_events_event_id ON webhook_events(event_id)');
  await pool.query('CREATE INDEX idx_signing_secrets_active ON signing_secrets(active)');

  await pool.query(
    'INSERT INTO signing_secrets (secret, active) VALUES ($1, true)',
    [TEST_SECRET]
  );
});

afterAll(async () => {
  await pool.query('DROP TABLE IF EXISTS webhook_events');
  await pool.query('DROP TABLE IF EXISTS signing_secrets');
  await pool.end();
});

describe('Webhook Receiver', () => {
  describe('POST /webhook - Signature Verification', () => {
    it('accepts a genuine webhook with valid signature', async () => {
      const payload = {
        event_type: 'payment.completed',
        transaction_id: 'txn_123',
        amount: 9999
      };

      const payloadString = JSON.stringify(payload);
      const signature = crypto
        .createHmac('sha256', TEST_SECRET)
        .update(payloadString)
        .digest('hex');

      const res = await request(app)
        .post('/webhook')
        .set('x-provider-signature', signature)
        .set('x-event-id', 'evt_genuine_123')
        .send(payload);

      expect(res.status).toBe(201);
      expect(res.body.status).toBe('recorded');
      expect(res.body.event_id).toBe('evt_genuine_123');
    });

    it('rejects a webhook with invalid signature', async () => {
      const payload = {
        event_type: 'payment.failed',
        transaction_id: 'txn_456'
      };

      const invalidSignature = 'not_a_real_signature_' + Date.now();

      const res = await request(app)
        .post('/webhook')
        .set('x-provider-signature', invalidSignature)
        .set('x-event-id', 'evt_forged_456')
        .send(payload);

      expect(res.status).toBe(401);
      expect(res.body.error).toContain('Signature verification failed');
    });

    it('rejects a webhook with modified payload', async () => {
      const payload = {
        event_type: 'payment.completed',
        transaction_id: 'txn_789',
        amount: 5000
      };

      const payloadString = JSON.stringify(payload);
      const signature = crypto
        .createHmac('sha256', TEST_SECRET)
        .update(payloadString)
        .digest('hex');

      const modifiedPayload = {
        event_type: 'payment.completed',
        transaction_id: 'txn_789',
        amount: 50000
      };

      const res = await request(app)
        .post('/webhook')
        .set('x-provider-signature', signature)
        .set('x-event-id', 'evt_modified_789')
        .send(modifiedPayload);

      expect(res.status).toBe(401);
    });
  });

  describe('POST /webhook - Duplicate Handling', () => {
    it('rejects a duplicate webhook without overwriting', async () => {
      const payload = {
        event_type: 'payment.completed',
        transaction_id: 'txn_dup_001'
      };

      const payloadString = JSON.stringify(payload);
      const signature = crypto
        .createHmac('sha256', TEST_SECRET)
        .update(payloadString)
        .digest('hex');

      const eventId = 'evt_duplicate_001';

      const res1 = await request(app)
        .post('/webhook')
        .set('x-provider-signature', signature)
        .set('x-event-id', eventId)
        .send(payload);

      expect(res1.status).toBe(201);

      const res2 = await request(app)
        .post('/webhook')
        .set('x-provider-signature', signature)
        .set('x-event-id', eventId)
        .send(payload);

      expect(res2.status).toBe(200);
      expect(res2.body.status).toBe('duplicate');

      const rows = await pool.query(
        'SELECT COUNT(*) as count FROM webhook_events WHERE event_id = $1',
        [eventId]
      );
      expect(parseInt(rows.rows[0].count)).toBe(1);
    });
  });

  describe('GET /webhook/:eventId - Authorization', () => {
    beforeAll(async () => {
      const payload = {
        event_type: 'payment.refunded',
        transaction_id: 'txn_auth_test'
      };

      const payloadString = JSON.stringify(payload);
      const signature = crypto
        .createHmac('sha256', TEST_SECRET)
        .update(payloadString)
        .digest('hex');

      await request(app)
        .post('/webhook')
        .set('x-provider-signature', signature)
        .set('x-event-id', 'evt_auth_001')
        .send(payload);
    });

    it('requires authorization header', async () => {
      const res = await request(app)
        .get('/webhook/evt_auth_001');

      expect(res.status).toBe(401);
      expect(res.body.error).toContain('authorization');
    });

    it('rejects invalid token', async () => {
      const res = await request(app)
        .get('/webhook/evt_auth_001')
        .set('Authorization', 'Bearer invalid_token_123');

      expect(res.status).toBe(403);
      expect(res.body.error).toContain('Forbidden');
    });

    it('allows access with valid support token', async () => {
      const res = await request(app)
        .get('/webhook/evt_auth_001')
        .set('Authorization', `Bearer ${TEST_TOKEN}`);

      expect(res.status).toBe(200);
      expect(res.body.event_id).toBe('evt_auth_001');
      expect(res.body.payload).toBeDefined();
      expect(res.body.received_at).toBeDefined();
    });

    it('returns 404 for non-existent event', async () => {
      const res = await request(app)
        .get('/webhook/evt_nonexistent_999')
        .set('Authorization', `Bearer ${TEST_TOKEN}`);

      expect(res.status).toBe(404);
    });
  });

  describe('POST /webhook - Request Validation', () => {
    it('rejects webhook without x-provider-signature header', async () => {
      const res = await request(app)
        .post('/webhook')
        .set('x-event-id', 'evt_missing_sig')
        .send({ event_type: 'test' });

      expect(res.status).toBe(400);
      expect(res.body.error).toContain('required headers');
    });

    it('rejects webhook without x-event-id header', async () => {
      const res = await request(app)
        .post('/webhook')
        .set('x-provider-signature', 'some_signature')
        .send({ event_type: 'test' });

      expect(res.status).toBe(400);
      expect(res.body.error).toContain('required headers');
    });

    it('distinguishes bad requests (4xx) from server faults (5xx)', async () => {
      const badRequestRes = await request(app)
        .post('/webhook')
        .send({ event_type: 'test' });

      expect(badRequestRes.status).toBe(400);
      expect(badRequestRes.status).not.toBe(500);
    });
  });

  describe('GET /health', () => {
    it('returns healthy status', async () => {
      const res = await request(app)
        .get('/health');

      expect(res.status).toBe(200);
      expect(res.body.status).toBe('healthy');
    });
  });

  describe('Error Handling', () => {
    it('returns 500 with error message on internal server error', async () => {
      const payload = {
        event_type: 'payment.completed',
        transaction_id: 'txn_error_test'
      };

      const payloadString = JSON.stringify(payload);
      const signature = crypto
        .createHmac('sha256', TEST_SECRET)
        .update(payloadString)
        .digest('hex');

      const res = await request(app)
        .post('/webhook')
        .set('x-provider-signature', signature)
        .set('x-event-id', 'evt_valid_for_error')
        .send(payload);

      expect(res.status).toBe(201);
      expect(res.body.error).toBeUndefined();
    });
  });
});
