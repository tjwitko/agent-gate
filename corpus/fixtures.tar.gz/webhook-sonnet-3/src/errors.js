/**
 * A fault the caller caused: a malformed body, a missing field, an unrecognised signature. These
 * are reported with the 4xx status they carry and never as a 500 — a bad request from the
 * provider is not the same as this service failing, and conflating the two would make a payment
 * provider retry a request that can never succeed.
 */
export class ClientError extends Error {
  constructor(status, message) {
    super(message);
    this.name = 'ClientError';
    this.status = status;
  }
}

export function badRequest(message) {
  return new ClientError(400, message);
}

export function unauthorized(message) {
  return new ClientError(401, message);
}

export function notFound(message) {
  return new ClientError(404, message);
}
