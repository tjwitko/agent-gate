variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Project name"
  type        = string
  default     = "webhook-receiver"
}

variable "vpc_cidr" {
  description = "VPC CIDR block"
  type        = string
  default     = "10.0.0.0/16"
}

variable "db_instance_class" {
  description = "RDS instance class"
  type        = string
  default     = "db.t3.micro"
}

variable "db_name" {
  description = "Database name"
  type        = string
  default     = "webhook_db"
}

variable "db_username" {
  description = "Database username"
  type        = string
  default     = "webhook"
  sensitive   = true
}

variable "db_password" {
  description = "Database password"
  type        = string
  sensitive   = true
}

variable "provider_secret" {
  description = "Payment provider signing secret"
  type        = string
  sensitive   = true
}

variable "admin_token" {
  description = "Admin access token"
  type        = string
  sensitive   = true
}

variable "ecr_repository" {
  description = "ECR repository URL"
  type        = string
  default     = "123456789012.dkr.ecr.us-east-1.amazonaws.com/webhook-receiver"
}

variable "image_tag" {
  description = "Docker image tag"
  type        = string
  default     = "latest"
}

variable "availability_zones" {
  description = "Availability zones for the region"
  type        = list(string)
  default     = ["us-east-1a", "us-east-1b"]
}
