output "database_endpoint" {
  description = "RDS database endpoint"
  value       = aws_db_instance.webhooks.endpoint
}

output "database_connection_string" {
  description = "Connection string for the database"
  value       = "postgresql://webhook_user:${var.db_password}@${aws_db_instance.webhooks.endpoint}/webhooks"
  sensitive   = true
}

output "eks_cluster_name" {
  description = "EKS cluster name"
  value       = aws_eks_cluster.main.name
}

output "eks_cluster_endpoint" {
  description = "EKS cluster endpoint"
  value       = aws_eks_cluster.main.endpoint
}

output "vpc_id" {
  description = "VPC ID"
  value       = aws_vpc.main.id
}
