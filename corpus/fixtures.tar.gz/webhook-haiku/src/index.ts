import express, { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import crypto from 'crypto';
import { WebhookService } from './service/webhookService';
import { SignatureVerifier } from './service/signatureVerifier';
import { Database } from './db/database';

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

const db = new Database();
const webhookService = new WebhookService(db);
const verifier = new SignatureVerifier(db);

// Constant-time string comparison helper
function constantTimeEqual(a: string, b: string): boolean {
  try {
    return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
  } catch {
    return false;
  }
}

// Middleware to authenticate support team access
async function authenticateSupportTeam(req: Request, res: Response, next: NextFunction) {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || typeof apiKey !== 'string') {
    return res.status(401).json({ error: 'Missing or invalid API key' });
  }

  const isValid = await db.validateSupportTeamApiKey(apiKey);
  if (!isValid) {
    return res.status(403).json({ error: 'Invalid API key' });
  }

  next();
}

// Middleware to authenticate provider access
async function authenticateProvider(req: Request, res: Response, next: NextFunction) {
  const providerApiKey = req.headers['x-provider-api-key'];
  if (!providerApiKey || typeof providerApiKey !== 'string') {
    return res.status(401).json({ error: 'Missing or invalid provider API key' });
  }

  const isValid = await db.validateProviderApiKey(providerApiKey);
  if (!isValid) {
    return res.status(403).json({ error: 'Invalid provider API key' });
  }

  next();
}

// Health check endpoint
app.get('/health', async (req: Request, res: Response) => {
  try {
    await db.ping();
    res.status(200).json({ status: 'healthy' });
  } catch (error) {
    res.status(503).json({ status: 'unhealthy', error: (error as Error).message });
  }
});

// Webhook receiver endpoint
app.post('/webhook', authenticateProvider, express.raw({ type: 'application/json' }), async (req: Request, res: Response) => {
  try {
    const signature = req.headers['x-signature'] as string;
    const providerId = req.headers['x-provider-id'] as string;

    if (!signature || !providerId) {
      return res.status(400).json({ error: 'Missing signature or provider ID header' });
    }

    const rawBody = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);

    // Verify signature
    const isValid = await verifier.verify(rawBody, signature, providerId);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid signature' });
    }

    // Parse and store the webhook
    const payload = JSON.parse(rawBody);
    const eventId = payload.event_id;

    if (!eventId) {
      return res.status(400).json({ error: 'Missing event_id in payload' });
    }

    const webhookId = await webhookService.storeWebhook({
      eventId,
      providerId,
      payload: rawBody,
      signature,
      receivedAt: new Date()
    });

    res.status(202).json({
      id: webhookId,
      status: 'received',
      message: 'Webhook received and stored for processing'
    });
  } catch (error) {
    const err = error as Error;
    if (err.message.includes('JSON')) {
      return res.status(400).json({ error: 'Invalid JSON in request body' });
    }
    console.error('Error processing webhook:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Support team lookup endpoint
app.get('/webhooks/:eventId', authenticateSupportTeam, async (req: Request, res: Response) => {
  try {
    const { eventId } = req.params;
    const webhook = await webhookService.getWebhookByEventId(eventId);

    if (!webhook) {
      return res.status(404).json({ error: 'Webhook not found' });
    }

    res.json(webhook);
  } catch (error) {
    console.error('Error retrieving webhook:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Initialize database and start server
async function start() {
  try {
    await db.initialize();
    console.log('Database initialized');

    app.listen(port, () => {
      console.log(`Webhook receiver listening on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

start();
