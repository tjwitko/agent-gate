package webhook

import (
	"encoding/json"
	"io"
	"log"
	"net/http"
	"time"

	"webhook-receiver/internal/signature"
	"webhook-receiver/internal/storage"
)

type Handler struct {
	verifier *signature.Verifier
	store    *storage.Store
}

type Webhook struct {
	EventID   string          `json:"event_id"`
	Type      string          `json:"type"`
	Timestamp int64           `json:"timestamp"`
	Data      json.RawMessage `json:"data"`
}

type LookupRequest struct {
	EventID string `json:"event_id"`
}

type ErrorResponse struct {
	Code    string `json:"code"`
	Message string `json:"message"`
}

type SuccessResponse struct {
	EventID    string          `json:"event_id"`
	Data       json.RawMessage `json:"data"`
	ReceivedAt string          `json:"received_at"`
}

func NewHandler(verifier *signature.Verifier, store *storage.Store) *Handler {
	return &Handler{
		verifier: verifier,
		store:    store,
	}
}

// ReceiveWebhook handles incoming webhook callbacks
func (h *Handler) ReceiveWebhook(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		sendError(w, http.StatusMethodNotAllowed, "method_not_allowed", "only POST is allowed")
		return
	}

	// Read body
	body, err := io.ReadAll(r.Body)
	if err != nil {
		sendError(w, http.StatusBadRequest, "bad_request", "failed to read body")
		return
	}
	defer r.Body.Close()

	// Verify signature
	signature := r.Header.Get("X-Webhook-Signature")
	if err := h.verifier.Verify(body, signature); err != nil {
		log.Printf("signature verification failed: %v", err)
		sendError(w, http.StatusUnauthorized, "invalid_signature", "signature verification failed")
		return
	}

	// Parse webhook
	var webhook Webhook
	if err := json.Unmarshal(body, &webhook); err != nil {
		sendError(w, http.StatusBadRequest, "invalid_json", "failed to parse webhook")
		return
	}

	// Validate required fields
	if webhook.EventID == "" {
		sendError(w, http.StatusBadRequest, "missing_event_id", "event_id is required")
		return
	}

	// Store webhook (immutably)
	if err := h.store.StoreWebhook(r.Context(), &storage.Record{
		EventID:    webhook.EventID,
		Type:       webhook.Type,
		RawPayload: body,
		ReceivedAt: time.Now().UTC(),
	}); err != nil {
		log.Printf("failed to store webhook: %v", err)
		sendError(w, http.StatusInternalServerError, "storage_error", "failed to store webhook")
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusAccepted)
	json.NewEncoder(w).Encode(map[string]string{"status": "accepted"})
}

// LookupWebhook allows support team to retrieve past webhooks by event ID
func (h *Handler) LookupWebhook(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		sendError(w, http.StatusMethodNotAllowed, "method_not_allowed", "only POST is allowed")
		return
	}

	var req LookupRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		sendError(w, http.StatusBadRequest, "invalid_json", "failed to parse request")
		return
	}

	if req.EventID == "" {
		sendError(w, http.StatusBadRequest, "missing_event_id", "event_id is required")
		return
	}

	record, err := h.store.GetWebhook(r.Context(), req.EventID)
	if err != nil {
		log.Printf("failed to retrieve webhook: %v", err)
		sendError(w, http.StatusInternalServerError, "storage_error", "failed to retrieve webhook")
		return
	}

	if record == nil {
		sendError(w, http.StatusNotFound, "not_found", "webhook not found")
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(SuccessResponse{
		EventID:    record.EventID,
		Data:       json.RawMessage(record.RawPayload),
		ReceivedAt: record.ReceivedAt.Format(time.RFC3339),
	})
}

func sendError(w http.ResponseWriter, statusCode int, code, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(ErrorResponse{
		Code:    code,
		Message: message,
	})
}
