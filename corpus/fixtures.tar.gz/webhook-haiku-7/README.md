# Webhook Receiver for Payment Provider Events

A secure, immutable webhook receiver for payment provider event notifications, built with Go, AWS, and Kubernetes.

## Architecture

### Components

- **Go Backend**: HTTP service for receiving and validating webhooks
  - HMAC-SHA256 signature verification
  - Event deduplication by event_id
  - Distinct error handling (4xx for client errors, 5xx for service errors)

- **AWS Infrastructure** (Terraform):
  - DynamoDB tables for callbacks (immutable) and secrets (rotated)
  - IAM roles for secure service access
  - CloudWatch logging and monitoring
  - ECR repository for container images
  - SNS alerts for operational issues

- **Kubernetes Deployment**:
  - Replicated service with rolling updates
  - Network policies for security
  - Pod disruption budgets for high availability
  - Health checks and resource limits

## API Endpoints

### POST /webhook
Accepts webhook callbacks from the payment provider.

**Headers:**
- `X-Webhook-Signature`: HMAC-SHA256 signature of the request body
- `X-Signature-ID`: ID of the signing secret (provider rotates quarterly)

**Request Body:**
```json
{
  "event_id": "evt_123",
  "type": "charge.succeeded",
  "amount": 1000,
  "currency": "USD"
}
```

**Responses:**
- `200 OK`: Callback recorded
- `400 Bad Request`: Invalid JSON or missing event_id
- `401 Unauthorized`: Missing or invalid signature
- `500 Internal Server Error`: Service failure

### GET /lookup?event_id={eventId}
Look up a previously received callback (support team only).

**Headers:**
- `Authorization`: Bearer {API_KEY}

**Response:**
```json
{
  "callback": {
    "event_id": "evt_123",
    "timestamp": "2026-09-03T21:30:00Z",
    "signature": "abc123...",
    "body": "{...}",
    "provider": "payment-provider"
  }
}
```

### GET /health
Health check endpoint for load balancers.

**Response:**
```json
{
  "status": "healthy"
}
```

## Security Features

- **Immutable Records**: Once stored, callback contents cannot be changed or removed
- **Signature Verification**: HMAC-SHA256 validates callbacks from the provider
- **Access Control**: Only support team can query callbacks via bearer token
- **Provider-Only Submission**: Only the provider can submit new callbacks
- **Secret Rotation**: Support for quarterly secret rotation via DynamoDB
- **Read-Only Root Filesystem**: Container runs with minimal privileges
- **Network Policies**: Kubernetes restricts traffic to/from the service

## Deployment

### Prerequisites
- AWS account with appropriate permissions
- Kubernetes cluster with OIDC provider configured
- Terraform and kubectl installed

### Steps

1. **Set up AWS resources:**
```bash
cd /Users/tomwitkowski/LLM/webhook-haiku-7
terraform init
terraform plan -var="oidc_provider_arn=arn:aws:iam::ACCOUNT:oidc-provider/OIDC_URL"
terraform apply
```

2. **Build and push container:**
```bash
docker build -t webhook-receiver:latest .
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin ACCOUNT.dkr.ecr.us-east-1.amazonaws.com
docker tag webhook-receiver:latest ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/webhook-receiver:latest
docker push ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/webhook-receiver:latest
```

3. **Deploy to Kubernetes:**
```bash
kubectl apply -f k8s-deployment.yaml
kubectl create secret generic webhook-receiver-secrets \
  -n webhook-receiver \
  --from-literal=api-key=YOUR_API_KEY
```

## Testing

Run tests to verify signature verification and duplicate handling:

```bash
go test -v
```

Test cases cover:
- Accepting genuine signatures
- Rejecting forged signatures
- Rejecting missing event_id
- Preventing invalid requests from being reported as service failures
- Supporting repeated callbacks without overwriting existing records

## Environment Variables

- `PORT`: HTTP port (default: 8080)
- `CALLBACKS_TABLE`: DynamoDB table for callbacks (default: webhook-callbacks)
- `SECRETS_TABLE`: DynamoDB table for signing secrets (default: webhook-secrets)
- `API_KEY`: Bearer token for support team lookups
- `AWS_REGION`: AWS region for DynamoDB (default: us-east-1)

## Data Retention

- Callbacks: 7 years (immutable, point-in-time recovery enabled)
- Logs: 10 years
- Automatic backups: Continuous via DynamoDB PITR

## Monitoring

CloudWatch alarms monitor:
- DynamoDB user errors (threshold: 5 per 5 minutes)
- Service availability via health endpoints

Alerts are sent to SNS topic `webhook-receiver-alerts`.

## File Structure

```
webhook-haiku-7/
├── main.go                 # HTTP service implementation
├── main_test.go            # Unit tests
├── Dockerfile              # Container image definition
├── k8s-deployment.yaml     # Kubernetes manifests
├── main.tf                 # Terraform infrastructure
├── variables.tf            # Terraform variables
└── README.md               # This file
```
