# --- control plane -----------------------------------------------------------

resource "aws_iam_role" "eks_cluster" {
  name = "${var.project_name}-eks-cluster"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "eks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = local.tags
}

resource "aws_iam_role_policy_attachment" "eks_cluster_policy" {
  role       = aws_iam_role.eks_cluster.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"
}

# EKS envelope-encrypts Kubernetes Secrets with this key on the cluster's own behalf, which
# requires the cluster role to be able to use it.
resource "aws_iam_role_policy" "eks_cluster_kms" {
  name = "${var.project_name}-eks-cluster-kms"
  role = aws_iam_role.eks_cluster.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["kms:Decrypt", "kms:DescribeKey"]
      Resource = aws_kms_key.app.arn
    }]
  })
}

resource "aws_cloudwatch_log_group" "eks_cluster" {
  # EKS's own control-plane logs -- not the callback records, which live in DynamoDB and are never
  # expired by this stack. A modest operational retention is appropriate here.
  name              = "/aws/eks/${var.project_name}/cluster"
  retention_in_days = 365
  kms_key_id        = aws_kms_key.app.arn

  tags = local.tags
}

resource "aws_eks_cluster" "this" {
  name     = var.project_name
  role_arn = aws_iam_role.eks_cluster.arn
  version  = "1.30"

  vpc_config {
    subnet_ids = concat(values(aws_subnet.public)[*].id, values(aws_subnet.private)[*].id)

    # The private endpoint is always on, so nodes and pods inside the VPC never depend on the
    # public one. The public endpoint stays available too, but only from the CIDRs an operator
    # supplies -- see the warning on var.eks_api_public_cidrs. Never 0.0.0.0/0 on either.
    endpoint_private_access = true
    endpoint_public_access  = true
    public_access_cidrs     = var.eks_api_public_cidrs
  }

  enabled_cluster_log_types = ["api", "audit", "authenticator", "controllerManager", "scheduler"]

  encryption_config {
    provider {
      key_arn = aws_kms_key.app.arn
    }
    resources = ["secrets"]
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_cluster_policy,
    aws_iam_role_policy.eks_cluster_kms,
    aws_cloudwatch_log_group.eks_cluster,
  ]

  tags = local.tags
}

# --- OIDC provider, so pods can assume roles via IRSA -------------------------

data "tls_certificate" "eks" {
  url = aws_eks_cluster.this.identity[0].oidc[0].issuer
}

resource "aws_iam_openid_connect_provider" "eks" {
  url             = aws_eks_cluster.this.identity[0].oidc[0].issuer
  client_id_list  = ["sts.amazonaws.com"]
  thumbprint_list = [data.tls_certificate.eks.certificates[0].sha1_fingerprint]

  tags = local.tags
}

# --- worker nodes ---------------------------------------------------------------

resource "aws_iam_role" "eks_node" {
  name = "${var.project_name}-eks-node"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = local.tags
}

resource "aws_iam_role_policy_attachment" "eks_node_worker" {
  role       = aws_iam_role.eks_node.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
}

resource "aws_iam_role_policy_attachment" "eks_node_cni" {
  role       = aws_iam_role.eks_node.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
}

resource "aws_iam_role_policy_attachment" "eks_node_ecr" {
  role       = aws_iam_role.eks_node.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}

# The container image repository (ecr.tf) is encrypted with the same customer-managed key, so
# pulling an image also requires the node's own role to be able to decrypt with it.
resource "aws_iam_role_policy" "eks_node_kms" {
  name = "${var.project_name}-eks-node-kms"
  role = aws_iam_role.eks_node.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["kms:Decrypt"]
      Resource = aws_kms_key.app.arn
    }]
  })
}

resource "aws_launch_template" "eks_node" {
  name_prefix = "${var.project_name}-node-"

  # Requires IMDSv2, and caps the hop limit at 1 so a pod cannot reach the instance metadata
  # endpoint at all (doing so takes an extra network hop past the node). The application
  # authenticates to AWS via IRSA, never via the node's own instance role, so pods have no
  # legitimate reason to read node-level credentials from IMDS in the first place.
  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 1
  }

  tag_specifications {
    resource_type = "instance"
    tags          = merge(local.tags, { Name = "${var.project_name}-node" })
  }
}

resource "aws_eks_node_group" "this" {
  cluster_name    = aws_eks_cluster.this.name
  node_group_name = "${var.project_name}-default"
  node_role_arn   = aws_iam_role.eks_node.arn
  subnet_ids      = values(aws_subnet.private)[*].id
  instance_types  = var.node_instance_types

  launch_template {
    id      = aws_launch_template.eks_node.id
    version = aws_launch_template.eks_node.latest_version
  }

  scaling_config {
    desired_size = var.node_desired_size
    min_size     = var.node_min_size
    max_size     = var.node_max_size
  }

  update_config {
    max_unavailable = 1
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_node_worker,
    aws_iam_role_policy_attachment.eks_node_cni,
    aws_iam_role_policy_attachment.eks_node_ecr,
  ]

  tags = local.tags
}

# --- namespace + service account for the application ---------------------------
#
# Created here, through the kubernetes provider, rather than as a static YAML manifest: the
# ServiceAccount's IRSA annotation must carry this account's real IAM role ARN, and Kubernetes
# never expands ${...} the way Terraform does, so a static manifest has no way to carry a value
# this stack computes. The Deployment and Service in k8s/ are applied separately, by name, against
# the namespace and ServiceAccount created here.

resource "kubernetes_namespace_v1" "webhook_receiver" {
  metadata {
    name = "webhook-receiver"
  }

  depends_on = [aws_eks_node_group.this]
}

resource "kubernetes_service_account_v1" "webhook_app" {
  metadata {
    name      = "webhook-receiver"
    namespace = "webhook-receiver"
    annotations = {
      "eks.amazonaws.com/role-arn" = aws_iam_role.webhook_app.arn
    }
  }

  depends_on = [kubernetes_namespace_v1.webhook_receiver]
}
