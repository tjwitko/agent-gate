locals {
  oidc_provider = replace(aws_iam_openid_connect_provider.eks.url, "https://", "")
}

# The role the webhook-receiver pod runs as. Deliberately narrow: it can write a new callback
# (conditionally -- see the application's ConditionExpression) and read one back, and it can read
# the two secrets it needs. It is never granted UpdateItem, DeleteItem or BatchWriteItem, so
# nothing this credential can do -- from inside the running service or from anywhere else it might
# be used -- can change or remove a record once written. That is the control the immutability
# requirement asks for: not an API surface that happens not to offer an update, but a credential
# that cannot perform one at all.
resource "aws_iam_role" "webhook_app" {
  name = "${var.project_name}-webhook-app"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = aws_iam_openid_connect_provider.eks.arn
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${local.oidc_provider}:sub" = "system:serviceaccount:webhook-receiver:webhook-receiver"
          "${local.oidc_provider}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })

  tags = local.tags
}

resource "aws_iam_policy" "webhook_app_dynamodb" {
  name = "${var.project_name}-webhook-app-dynamodb"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      # No UpdateItem, DeleteItem or BatchWriteItem. See the note on the role above.
      Action   = ["dynamodb:PutItem", "dynamodb:GetItem"]
      Resource = aws_dynamodb_table.callbacks.arn
    }]
  })

  tags = local.tags
}

resource "aws_iam_policy" "webhook_app_secrets" {
  name = "${var.project_name}-webhook-app-secrets"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = ["secretsmanager:GetSecretValue"]
      Resource = [
        aws_secretsmanager_secret.signing_secret.arn,
        aws_secretsmanager_secret.support_token.arn,
      ]
    }]
  })

  tags = local.tags
}

resource "aws_iam_policy" "webhook_app_kms" {
  name = "${var.project_name}-webhook-app-kms"

  # Both the callbacks table and the two secrets this role reads are encrypted with the shared
  # customer-managed key (kms.tf); generating a data key is needed for the DynamoDB write path,
  # decrypt for reading either.
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["kms:Decrypt", "kms:GenerateDataKey"]
      Resource = aws_kms_key.app.arn
    }]
  })

  tags = local.tags
}

resource "aws_iam_role_policy_attachment" "webhook_app_dynamodb" {
  role       = aws_iam_role.webhook_app.name
  policy_arn = aws_iam_policy.webhook_app_dynamodb.arn
}

resource "aws_iam_role_policy_attachment" "webhook_app_secrets" {
  role       = aws_iam_role.webhook_app.name
  policy_arn = aws_iam_policy.webhook_app_secrets.arn
}

resource "aws_iam_role_policy_attachment" "webhook_app_kms" {
  role       = aws_iam_role.webhook_app.name
  policy_arn = aws_iam_policy.webhook_app_kms.arn
}
