export interface Callback {
  id: string;
  eventId: string;
  receivedAt: Date;
  body: Record<string, unknown>;
}

export interface SigningSecret {
  secret: string;
  activeFrom: Date;
}

export interface WebhookRequest {
  eventId: string;
  signature: string;
  timestamp: string;
  body: Record<string, unknown>;
}
