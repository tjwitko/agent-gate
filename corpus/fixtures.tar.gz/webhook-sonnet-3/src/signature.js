import { createHash, createHmac, timingSafeEqual } from 'node:crypto';

const SIGNATURE_HEADER = 'x-provider-signature';
const SIGNATURE_PREFIX = 'sha256=';

/**
 * Constant-time comparison of two arbitrary-length values. Both sides are hashed to a fixed
 * length first so a length mismatch never short-circuits the comparison or throws.
 */
export function constantTimeEqual(a, b) {
  const bufA = createHash('sha256').update(a).digest();
  const bufB = createHash('sha256').update(b).digest();
  return timingSafeEqual(bufA, bufB);
}

function computeSignature(secret, rawBody) {
  return createHmac('sha256', secret).update(rawBody).digest();
}

/**
 * Verifies a provider callback's signature against every currently-valid signing secret
 * (typically the current secret and the one being retired during a quarterly rotation window).
 * Accepting any match in the set is what lets a rotation roll over without rejecting the
 * provider's real traffic or, in the other direction, keeping a revoked secret honoured forever
 * once it has actually been dropped from the set.
 */
export function verifySignature(rawBody, headerValue, candidateSecrets) {
  if (!headerValue || typeof headerValue !== 'string') return false;
  const hex = headerValue.startsWith(SIGNATURE_PREFIX)
    ? headerValue.slice(SIGNATURE_PREFIX.length)
    : headerValue;

  let providedDigest;
  try {
    providedDigest = Buffer.from(hex, 'hex');
  } catch {
    return false;
  }
  if (providedDigest.length === 0) return false;

  for (const secret of candidateSecrets) {
    if (!secret) continue;
    const expectedDigest = computeSignature(secret, rawBody);
    if (constantTimeEqual(expectedDigest, providedDigest)) {
      return true;
    }
  }
  return false;
}

export { SIGNATURE_HEADER };
