package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"flag"
	"io"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/jackc/pgx/v5/stdlib"
)

type WebhookReceiver struct {
	db *sql.DB
}

type WebhookEvent struct {
	EventID     string    `json:"event_id"`
	ReceivedAt  time.Time `json:"received_at"`
	OriginalBody string    `json:"original_body"`
}

type HealthResponse struct {
	Status string `json:"status"`
	Time   string `json:"time"`
}

type ErrorResponse struct {
	Error     string `json:"error"`
	ErrorType string `json:"error_type"`
}

func verifySignature(body []byte, signature string, secret string) bool {
	h := hmac.New(sha256.New, []byte(secret))
	h.Write(body)
	expected := hex.EncodeToString(h.Sum(nil))
	return hmac.Equal([]byte(signature), []byte(expected))
}

func constantTimeEqual(a, b string) bool {
	return hmac.Equal([]byte(a), []byte(b))
}

func (wr *WebhookReceiver) handleWebhook(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusMethodNotAllowed)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "method not allowed",
			ErrorType: "client_error",
		})
		return
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "failed to read request body",
			ErrorType: "client_error",
		})
		return
	}
	defer r.Body.Close()

	signature := r.Header.Get("X-Webhook-Signature")
	if signature == "" {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusUnauthorized)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "missing signature header",
			ErrorType: "client_error",
		})
		return
	}

	secret := os.Getenv("WEBHOOK_SECRET")
	if secret == "" {
		log.Println("ERROR: WEBHOOK_SECRET not configured")
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "server misconfiguration",
			ErrorType: "server_error",
		})
		return
	}

	if !verifySignature(body, signature, secret) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusUnauthorized)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "invalid signature",
			ErrorType: "client_error",
		})
		return
	}

	var payload map[string]interface{}
	if err := json.Unmarshal(body, &payload); err != nil {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "invalid json",
			ErrorType: "client_error",
		})
		return
	}

	eventID, ok := payload["event_id"].(string)
	if !ok || eventID == "" {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "missing or invalid event_id",
			ErrorType: "client_error",
		})
		return
	}

	event := WebhookEvent{
		EventID:     eventID,
		ReceivedAt:  time.Now().UTC(),
		OriginalBody: string(body),
	}

	if err := wr.storeEvent(event); err != nil {
		log.Printf("ERROR storing event: %v", err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "failed to store event",
			ErrorType: "server_error",
		})
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusAccepted)
	json.NewEncoder(w).Encode(map[string]string{
		"status": "accepted",
	})
}

func (wr *WebhookReceiver) storeEvent(event WebhookEvent) error {
	_, err := wr.db.Exec(
		`INSERT INTO webhooks (event_id, received_at, original_body)
		 VALUES ($1, $2, $3)
		 ON CONFLICT (event_id) DO NOTHING`,
		event.EventID,
		event.ReceivedAt,
		event.OriginalBody,
	)
	return err
}

func (wr *WebhookReceiver) handleLookup(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusMethodNotAllowed)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "method not allowed",
			ErrorType: "client_error",
		})
		return
	}

	// Require authentication for support team access
	authToken := r.Header.Get("Authorization")
	if authToken == "" {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusUnauthorized)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "missing authorization header",
			ErrorType: "client_error",
		})
		return
	}

	expectedToken := os.Getenv("SUPPORT_TOKEN")
	if expectedToken == "" {
		log.Println("ERROR: SUPPORT_TOKEN not configured")
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "server misconfiguration",
			ErrorType: "server_error",
		})
		return
	}

	expectedAuth := "Bearer " + expectedToken
	if !constantTimeEqual(authToken, expectedAuth) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusUnauthorized)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "invalid authorization",
			ErrorType: "client_error",
		})
		return
	}

	eventID := r.URL.Query().Get("event_id")
	if eventID == "" {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "event_id parameter required",
			ErrorType: "client_error",
		})
		return
	}

	var event WebhookEvent
	err := wr.db.QueryRow(
		`SELECT event_id, received_at, original_body FROM webhooks WHERE event_id = $1`,
		eventID,
	).Scan(&event.EventID, &event.ReceivedAt, &event.OriginalBody)

	if err == sql.ErrNoRows {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusNotFound)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "event not found",
			ErrorType: "client_error",
		})
		return
	}

	if err != nil {
		log.Printf("ERROR querying event: %v", err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(ErrorResponse{
			Error:     "failed to query event",
			ErrorType: "server_error",
		})
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(event)
}

func (wr *WebhookReceiver) handleHealth(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}

	err := wr.db.Ping()
	if err != nil {
		log.Printf("Health check failed: %v", err)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusServiceUnavailable)
		json.NewEncoder(w).Encode(HealthResponse{
			Status: "unhealthy",
			Time:   time.Now().UTC().Format(time.RFC3339),
		})
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(HealthResponse{
		Status: "healthy",
		Time:   time.Now().UTC().Format(time.RFC3339),
	})
}

func initDB(connString string) (*sql.DB, error) {
	config, err := pgxpool.ParseConfig(connString)
	if err != nil {
		return nil, err
	}

	pool, err := pgxpool.NewWithConfig(nil, config)
	if err != nil {
		return nil, err
	}

	db := stdlib.OpenDBFromPool(pool)

	if err := db.Ping(); err != nil {
		return nil, err
	}

	_, err = db.Exec(`
		CREATE TABLE IF NOT EXISTS webhooks (
			event_id TEXT PRIMARY KEY,
			received_at TIMESTAMP NOT NULL,
			original_body TEXT NOT NULL
		)
	`)
	if err != nil {
		return nil, err
	}

	// Create immutability triggers and revoke dangerous permissions
	_, err = db.Exec(`
		CREATE OR REPLACE FUNCTION webhook_immutable() RETURNS TRIGGER AS $$
		BEGIN
			RAISE EXCEPTION 'Webhook records are immutable and cannot be modified';
		END;
		$$ LANGUAGE plpgsql;
	`)
	if err != nil {
		log.Printf("Warning: could not create immutability function: %v", err)
	}

	_, err = db.Exec(`
		DROP TRIGGER IF EXISTS webhooks_update_protection ON webhooks;
	`)
	if err != nil {
		log.Printf("Warning: could not drop existing trigger: %v", err)
	}

	_, err = db.Exec(`
		CREATE TRIGGER webhooks_update_protection
		BEFORE UPDATE ON webhooks
		FOR EACH ROW
		EXECUTE FUNCTION webhook_immutable();
	`)
	if err != nil {
		log.Printf("Warning: could not create update protection trigger: %v", err)
	}

	_, err = db.Exec(`
		DROP TRIGGER IF EXISTS webhooks_delete_protection ON webhooks;
	`)
	if err != nil {
		log.Printf("Warning: could not drop existing trigger: %v", err)
	}

	_, err = db.Exec(`
		CREATE TRIGGER webhooks_delete_protection
		BEFORE DELETE ON webhooks
		FOR EACH ROW
		EXECUTE FUNCTION webhook_immutable();
	`)
	if err != nil {
		log.Printf("Warning: could not create delete protection trigger: %v", err)
	}

	// Revoke dangerous permissions to ensure immutability
	// This prevents UPDATE, DELETE, and TRUNCATE operations via database
	_, err = db.Exec(`
		REVOKE UPDATE, DELETE ON TABLE webhooks FROM webhook_user
	`)
	if err != nil {
		log.Printf("Note: Could not revoke permissions (role may not exist yet): %v", err)
	}

	_, err = db.Exec(`
		ALTER TABLE webhooks DISABLE TRIGGER USER
	`)
	if err != nil {
		log.Printf("Note: Could not disable user triggers: %v", err)
	}

	return db, nil
}

func main() {
	port := flag.String("port", "8080", "port to listen on")
	dbConnString := flag.String("db", "", "database connection string")
	flag.Parse()

	if *dbConnString == "" {
		*dbConnString = os.Getenv("DATABASE_URL")
		if *dbConnString == "" {
			log.Fatal("DATABASE_URL environment variable or -db flag required")
		}
	}

	db, err := initDB(*dbConnString)
	if err != nil {
		log.Fatalf("Failed to initialize database: %v", err)
	}
	defer db.Close()

	wr := &WebhookReceiver{db: db}

	http.HandleFunc("/webhook", wr.handleWebhook)
	http.HandleFunc("/lookup", wr.handleLookup)
	http.HandleFunc("/health", wr.handleHealth)

	log.Printf("Starting webhook receiver on port %s", *port)
	if err := http.ListenAndServe(":"+*port, nil); err != nil {
		log.Fatalf("Server error: %v", err)
	}
}
