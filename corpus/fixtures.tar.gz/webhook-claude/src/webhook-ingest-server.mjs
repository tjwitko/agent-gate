// Entry point for the provider-facing service. Wires real AWS-backed dependencies and starts
// listening; all the actual logic lives in webhookIngestApp.mjs, which takes its dependencies as
// plain objects so the test suite never needs a live AWS account.

import { createWebhookIngestApp } from "./webhookIngestApp.mjs";
import { AwsSecretsManagerProvider } from "./lib/secretsManagerProvider.mjs";
import { SigningSecretSource } from "./lib/signingSecretSource.mjs";
import { DynamoCallbackStore } from "./lib/storage/dynamoCallbackStore.mjs";
import { TtlCache } from "./lib/ttlCache.mjs";
import { consoleLogger } from "./lib/errorMiddleware.mjs";

const SECRET_CACHE_TTL_MS = 5 * 60 * 1000; // well under the provider's quarterly rotation cadence

function requireEnv(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`required environment variable ${name} is not set`);
  }
  return value;
}

const region = process.env.AWS_REGION;
const tableName = requireEnv("DYNAMODB_TABLE_NAME");
const signingSecretId = requireEnv("SIGNING_SECRET_ID");
const port = Number(process.env.PORT) || 8080;

const secretsProvider = new AwsSecretsManagerProvider(region);
const signingSecretSource = new SigningSecretSource(secretsProvider, signingSecretId, new TtlCache(SECRET_CACHE_TTL_MS));
const store = new DynamoCallbackStore(region, tableName);

const app = createWebhookIngestApp({ signingSecretSource, store, logger: consoleLogger });

app.listen(port, () => {
  consoleLogger.info({ port }, "webhook-ingest listening");
});
