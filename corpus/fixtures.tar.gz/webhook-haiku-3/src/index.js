import express from 'express';
import crypto from 'crypto';
import { verifySignature } from './signature.js';
import { storeWebhook, getWebhookByEventId } from './storage.js';
import { initDatabase } from './database.js';
import dotenv from 'dotenv';

dotenv.config();

// Validate required environment variables at startup
const requiredEnvVars = ['PROVIDER_SECRET', 'ADMIN_TOKEN'];
for (const envVar of requiredEnvVars) {
  if (!process.env[envVar]) {
    console.error(`FATAL: Required environment variable ${envVar} is not set`);
    process.exit(1);
  }
}

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

app.use(express.json());

// Health endpoint for load balancer
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Webhook endpoint for receiving callbacks from payment provider
app.post('/webhook', async (req, res) => {
  try {
    const signature = req.headers['x-signature'];
    const timestamp = req.headers['x-timestamp'];
    const body = req.body;

    if (!signature || !timestamp) {
      return res.status(400).json({ error: 'Missing signature or timestamp' });
    }

    // Verify signature
    const isValid = await verifySignature(body, signature, timestamp);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid signature' });
    }

    // Store the webhook
    const eventId = body.event_id;
    if (!eventId) {
      return res.status(400).json({ error: 'Missing event_id in payload' });
    }

    const result = await storeWebhook(eventId, body, signature, timestamp);
    res.status(200).json({ success: true, id: result.id });
  } catch (error) {
    console.error('Error processing webhook:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Support team endpoint to look up past callbacks by event id
app.get('/admin/webhook/:eventId', async (req, res) => {
  try {
    const authToken = req.headers.authorization?.replace('Bearer ', '') || '';

    // Use timing-safe comparison to prevent timing attacks
    let isAuthorized = false;
    try {
      isAuthorized = crypto.timingSafeEqual(
        Buffer.from(authToken),
        Buffer.from(ADMIN_TOKEN)
      );
    } catch (e) {
      // timingSafeEqual throws if buffers have different lengths
      isAuthorized = false;
    }

    if (!isAuthorized) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const webhook = await getWebhookByEventId(req.params.eventId);
    if (!webhook) {
      return res.status(404).json({ error: 'Webhook not found' });
    }

    res.json(webhook);
  } catch (error) {
    console.error('Error retrieving webhook:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

async function start() {
  try {
    await initDatabase();
    app.listen(PORT, () => {
      console.log(`Webhook receiver listening on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

start();

export default app;
