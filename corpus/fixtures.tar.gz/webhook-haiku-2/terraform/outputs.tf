output "alb_dns_name" {
  description = "DNS name of the load balancer"
  value       = aws_lb.webhook.dns_name
}

output "dynamodb_table_name" {
  description = "Name of the DynamoDB table storing callbacks"
  value       = aws_dynamodb_table.callbacks.name
}

output "ecs_cluster_name" {
  description = "Name of the ECS cluster"
  value       = aws_ecs_cluster.webhook.name
}

output "ecs_service_name" {
  description = "Name of the ECS service"
  value       = aws_ecs_service.webhook.name
}

output "cloudwatch_log_group" {
  description = "CloudWatch log group name"
  value       = aws_cloudwatch_log_group.webhook.name
}

output "s3_backup_bucket" {
  description = "S3 bucket for callback backups"
  value       = aws_s3_bucket.callback_backups.id
}
