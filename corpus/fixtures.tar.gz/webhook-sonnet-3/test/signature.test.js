import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';

import { verifySignature, constantTimeEqual } from '../src/signature.js';

function sign(secret, body) {
  return 'sha256=' + createHmac('sha256', secret).update(body).digest('hex');
}

test('accepts a callback signed with the current secret', () => {
  const body = Buffer.from('{"event_id":"evt_1"}');
  const header = sign('current-secret', body);
  assert.equal(verifySignature(body, header, ['current-secret']), true);
});

test('accepts a callback signed with the previous secret during a rotation window', () => {
  const body = Buffer.from('{"event_id":"evt_1"}');
  const header = sign('old-secret', body);
  assert.equal(verifySignature(body, header, ['new-secret', 'old-secret']), true);
});

test('rejects a forged callback signed with none of the known secrets', () => {
  const body = Buffer.from('{"event_id":"evt_1"}');
  const header = sign('attacker-secret', body);
  assert.equal(verifySignature(body, header, ['current-secret', 'previous-secret']), false);
});

test('rejects a callback whose body was tampered with after signing', () => {
  const original = Buffer.from('{"event_id":"evt_1","amount":100}');
  const header = sign('current-secret', original);
  const tampered = Buffer.from('{"event_id":"evt_1","amount":100000}');
  assert.equal(verifySignature(tampered, header, ['current-secret']), false);
});

test('rejects a missing or empty signature header', () => {
  const body = Buffer.from('{"event_id":"evt_1"}');
  assert.equal(verifySignature(body, undefined, ['current-secret']), false);
  assert.equal(verifySignature(body, '', ['current-secret']), false);
  assert.equal(verifySignature(body, 'sha256=', ['current-secret']), false);
});

test('constantTimeEqual compares equal and unequal buffers correctly regardless of length', () => {
  assert.equal(constantTimeEqual(Buffer.from('abc'), Buffer.from('abc')), true);
  assert.equal(constantTimeEqual(Buffer.from('abc'), Buffer.from('abcd')), false);
  assert.equal(constantTimeEqual(Buffer.from('abc'), Buffer.from('xyz')), false);
});
