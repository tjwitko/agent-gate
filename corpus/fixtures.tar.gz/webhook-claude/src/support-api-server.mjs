// Entry point for the support-facing read service. See webhook-ingest-server.mjs for the same
// wiring pattern; this process holds a different, read-only IAM role and a different secret.

import { createSupportApiApp } from "./supportApiApp.mjs";
import { AwsSecretsManagerProvider } from "./lib/secretsManagerProvider.mjs";
import { SingleSecretSource } from "./lib/singleSecretSource.mjs";
import { DynamoCallbackStore } from "./lib/storage/dynamoCallbackStore.mjs";
import { TtlCache } from "./lib/ttlCache.mjs";
import { consoleLogger } from "./lib/errorMiddleware.mjs";

const SECRET_CACHE_TTL_MS = 5 * 60 * 1000;

function requireEnv(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`required environment variable ${name} is not set`);
  }
  return value;
}

const region = process.env.AWS_REGION;
const tableName = requireEnv("DYNAMODB_TABLE_NAME");
const supportApiKeySecretId = requireEnv("SUPPORT_API_KEY_SECRET_ID");
const port = Number(process.env.PORT) || 8080;

const secretsProvider = new AwsSecretsManagerProvider(region);
const supportApiKeySource = new SingleSecretSource(secretsProvider, supportApiKeySecretId, new TtlCache(SECRET_CACHE_TTL_MS));
const store = new DynamoCallbackStore(region, tableName);

const app = createSupportApiApp({ supportApiKeySource, store, logger: consoleLogger });

app.listen(port, () => {
  consoleLogger.info({ port }, "support-api listening");
});
