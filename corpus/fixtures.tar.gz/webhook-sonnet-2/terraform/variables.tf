variable "aws_region" {
  description = "Single AWS region hosting all infrastructure for this service."
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Deployment environment tag."
  type        = string
  default     = "production"
}

variable "app_name" {
  description = "Base name used to derive resource names."
  type        = string
  default     = "webhook-receiver"
}

variable "eks_oidc_provider_url" {
  description = "OIDC issuer URL (without the https:// prefix) of the existing EKS cluster this service is deployed to, e.g. oidc.eks.us-east-1.amazonaws.com/id/EXAMPLED539D4633E53DE1B71EXAMPLE. The cluster itself is provisioned separately; this module only wires IAM trust to it."
  type        = string
}

variable "eks_oidc_thumbprint" {
  description = "SHA1 thumbprint of the EKS OIDC provider's TLS certificate. Defaults to the thumbprint of Amazon Root CA 1, which every regional oidc.eks.*.amazonaws.com endpoint chains to today -- confirm it still matches your cluster's endpoint (`openssl s_client -connect oidc.eks.<region>.amazonaws.com:443 -showcerts`) before relying on the default, since AWS could change the issuing chain."
  type        = string
  default     = "9e99a48a9960b14926bb7f3b02e22da2b0ab7280"

  validation {
    condition     = can(regex("^[0-9a-fA-F]{40}$", var.eks_oidc_thumbprint))
    error_message = "Must be a 40-character hex SHA1 thumbprint."
  }
}

variable "k8s_namespace" {
  description = "Kubernetes namespace the service runs in; must match k8s/namespace.yaml."
  type        = string
  default     = "webhook-receiver"
}

variable "k8s_service_account_name" {
  description = "Kubernetes ServiceAccount name the pod runs as; must match k8s/serviceaccount.yaml."
  type        = string
  default     = "webhook-receiver"
}

variable "backup_retention_days" {
  description = "How long AWS Backup keeps recovery points for the events log, in days. The task requires seven years of retention; this must never be set below that."
  type        = number
  default     = 2555 # 7 years
  validation {
    condition     = var.backup_retention_days >= 2555
    error_message = "Retention must be at least seven years (2555 days) to meet the retention requirement."
  }
}
