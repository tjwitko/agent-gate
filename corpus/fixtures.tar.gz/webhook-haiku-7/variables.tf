variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Project name for resource naming"
  type        = string
  default     = "webhook-receiver"
}

variable "oidc_provider_arn" {
  description = "ARN of the OIDC provider for EKS service accounts"
  type        = string
  default     = ""
}

variable "common_tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default = {
    Project     = "webhook-receiver"
    Environment = "production"
    ManagedBy   = "terraform"
  }
}
