# The system of record. Immutability is enforced two ways at once, deliberately redundant:
#   1. The application always writes with ConditionExpression "attribute_not_exists(event_id)"
#      (src/lib/storage/dynamoCallbackStore.mjs) — a retried or replayed delivery cannot overwrite
#      what is already stored.
#   2. The IAM policies granted to every role in this account (iam_irsa.tf) never include
#      UpdateItem, DeleteItem or BatchWriteItem — so even a compromised or misbehaving copy of the
#      application has no credential capable of changing or removing a record, regardless of what
#      its own code does.
# Point-in-time recovery and deletion protection add a second line of defense against operator
# error, not against the application itself.
resource "aws_dynamodb_table" "callback_audit_log" {
  name         = "webhook-callback-audit-log"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "event_id"

  attribute {
    name = "event_id"
    type = "S"
  }

  point_in_time_recovery {
    enabled = true
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = aws_kms_key.app.arn
  }

  deletion_protection_enabled = true

  tags = {
    Purpose = "immutable-webhook-callback-audit-log"
  }
}
