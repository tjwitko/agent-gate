import { describe, it, expect, beforeEach } from "vitest";
import crypto from "crypto";
import { app, store, verifier } from "./server.js";
import { InMemoryStore } from "./database.js";

const SECRET = "test-webhook-secret";
const EVENT_ID = "evt_123456";
const TIMESTAMP = "1234567890";
const TEST_BODY = { action: "charge.completed", amount: 10000 };

function computeSignature(eventId: string, timestamp: string, body: Record<string, unknown>, secret: string): string {
  const payload = `${eventId}.${timestamp}.${JSON.stringify(body)}`;
  return crypto.createHmac("sha256", secret).update(payload).digest("hex");
}

function createValidSignature(eventId: string, timestamp: string, body: Record<string, unknown>): string {
  return computeSignature(eventId, timestamp, body, SECRET);
}

describe("Webhook Receiver", () => {
  beforeEach(async () => {
    // Reset store
    if (store instanceof InMemoryStore) {
      await store.clear();
    }
  });

  describe("Health endpoint", () => {
    it("should return healthy status", async () => {
      const response = await fetch("http://localhost:3000/health");
      expect(response.status).toBe(200);
      const data = (await response.json()) as Record<string, unknown>;
      expect(data).toEqual({ status: "healthy" });
    });
  });

  describe("Signature verification", () => {
    it("should accept a webhook with a valid signature", async () => {
      const signature = createValidSignature(EVENT_ID, TIMESTAMP, TEST_BODY);

      const response = await fetch("http://localhost:3000/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-event-id": EVENT_ID,
          "x-timestamp": TIMESTAMP,
          "x-signature": signature,
        },
        body: JSON.stringify(TEST_BODY),
      });

      expect(response.status).toBe(202);
      const data = (await response.json()) as Record<string, unknown>;
      expect(data).toHaveProperty("id");
      expect((data as {eventId: unknown}).eventId).toBe(EVENT_ID);
    });

    it("should reject a webhook with an invalid signature", async () => {
      const invalidSignature = "invalid_signature_" + crypto.randomBytes(32).toString("hex");

      const response = await fetch("http://localhost:3000/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-event-id": EVENT_ID,
          "x-timestamp": TIMESTAMP,
          "x-signature": invalidSignature,
        },
        body: JSON.stringify(TEST_BODY),
      });

      expect(response.status).toBe(401);
      const data = (await response.json()) as Record<string, unknown>;
      expect(data.error).toBeDefined();
    });

    it("should reject a webhook with a tampered body", async () => {
      const signature = createValidSignature(EVENT_ID, TIMESTAMP, TEST_BODY);
      const tamperedBody = { ...TEST_BODY, amount: 99999 };

      const response = await fetch("http://localhost:3000/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-event-id": EVENT_ID,
          "x-timestamp": TIMESTAMP,
          "x-signature": signature,
        },
        body: JSON.stringify(tamperedBody),
      });

      expect(response.status).toBe(401);
    });
  });

  describe("Duplicate handling", () => {
    it("should reject a repeated webhook with the same event id", async () => {
      const signature = createValidSignature(EVENT_ID, TIMESTAMP, TEST_BODY);

      // First request should succeed
      const response1 = await fetch("http://localhost:3000/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-event-id": EVENT_ID,
          "x-timestamp": TIMESTAMP,
          "x-signature": signature,
        },
        body: JSON.stringify(TEST_BODY),
      });

      expect(response1.status).toBe(202);

      // Second request with same event id should fail
      const response2 = await fetch("http://localhost:3000/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-event-id": EVENT_ID,
          "x-timestamp": TIMESTAMP,
          "x-signature": signature,
        },
        body: JSON.stringify(TEST_BODY),
      });

      expect(response2.status).toBe(409);
      const data = (await response2.json()) as Record<string, unknown>;
      expect((data.error as string)).toContain("already recorded");
    });
  });

  describe("Request validation", () => {
    it("should reject requests missing x-event-id header", async () => {
      const signature = createValidSignature(EVENT_ID, TIMESTAMP, TEST_BODY);

      const response = await fetch("http://localhost:3000/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-timestamp": TIMESTAMP,
          "x-signature": signature,
        },
        body: JSON.stringify(TEST_BODY),
      });

      expect(response.status).toBe(400);
    });

    it("should reject requests missing x-timestamp header", async () => {
      const signature = createValidSignature(EVENT_ID, TIMESTAMP, TEST_BODY);

      const response = await fetch("http://localhost:3000/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-event-id": EVENT_ID,
          "x-signature": signature,
        },
        body: JSON.stringify(TEST_BODY),
      });

      expect(response.status).toBe(400);
    });

    it("should reject requests missing x-signature header", async () => {
      const response = await fetch("http://localhost:3000/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-event-id": EVENT_ID,
          "x-timestamp": TIMESTAMP,
        },
        body: JSON.stringify(TEST_BODY),
      });

      expect(response.status).toBe(400);
    });
  });

  describe("Callback storage", () => {
    it("should preserve the exact content of received callbacks", async () => {
      const signature = createValidSignature(EVENT_ID, TIMESTAMP, TEST_BODY);

      const response = await fetch("http://localhost:3000/webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-event-id": EVENT_ID,
          "x-timestamp": TIMESTAMP,
          "x-signature": signature,
        },
        body: JSON.stringify(TEST_BODY),
      });

      const data = (await response.json()) as Record<string, unknown>;
      const id = data.id;

      // Retrieve the callback
      const getResponse = await fetch(`http://localhost:3000/callbacks/${EVENT_ID}`, {
        headers: {
          "Authorization": "Bearer test-api-key",
        },
      });
      expect(getResponse.status).toBe(200);

      const callback = (await getResponse.json()) as Record<string, unknown>;
      expect(callback.body).toEqual(TEST_BODY);
      expect((callback.eventId as string)).toBe(EVENT_ID);
      expect((callback.id as string)).toBe(id as string);
    });
  });
});
