# The pod authenticates to AWS as an issued identity (IRSA), never with a long-lived credential
# it holds: the ServiceAccount it runs as (k8s/serviceaccount.yaml) is federated to this role via
# the cluster's OIDC provider, and AWS issues short-lived credentials scoped to that role for the
# lifetime of the pod. No IAM user or access key exists anywhere in this module.
resource "aws_iam_openid_connect_provider" "eks" {
  url             = "https://${var.eks_oidc_provider_url}"
  client_id_list  = ["sts.amazonaws.com"]
  thumbprint_list = [var.eks_oidc_thumbprint]
}

# Inlined (rather than built through a separate aws_iam_policy_document data source) so the whole
# trust boundary for this role -- which federated identity provider, which action, which
# ServiceAccount it's pinned to -- is readable in one place: this is the statement that makes it
# IRSA rather than an instance-profile-style trust, and it's worth being able to see it directly.
resource "aws_iam_role" "app" {
  name = "${var.app_name}-app"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRoleWithWebIdentity"
      Principal = { Federated = aws_iam_openid_connect_provider.eks.arn }
      Condition = {
        StringEquals = {
          # Pins the trust to exactly this ServiceAccount, not to "anything in this cluster" --
          # without this, any workload on the cluster with a token for this OIDC provider could
          # assume the role.
          "${var.eks_oidc_provider_url}:sub" = "system:serviceaccount:${var.k8s_namespace}:${var.k8s_service_account_name}"
          "${var.eks_oidc_provider_url}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })
}

# Least privilege, and specifically no dynamodb:UpdateItem/DeleteItem/BatchWriteItem: this is the
# other half of what makes the events log immutable in practice, alongside the conditional put in
# application code. Even a compromised or buggy deployment of this service cannot alter or delete
# a recorded callback, because the credentials it can obtain don't permit it.
data "aws_iam_policy_document" "app_permissions" {
  statement {
    sid       = "WriteAndReadEventsLog"
    effect    = "Allow"
    actions   = ["dynamodb:PutItem", "dynamodb:GetItem", "dynamodb:Query"]
    resources = [aws_dynamodb_table.webhook_events_log.arn]
  }

  statement {
    sid     = "ReadRotatedSecrets"
    effect  = "Allow"
    actions = ["secretsmanager:GetSecretValue"]
    resources = [
      aws_secretsmanager_secret.webhook_signing_secret.arn,
      aws_secretsmanager_secret.support_api_token.arn,
    ]
  }

  # The events log and both secrets are encrypted under the customer-managed key (kms.tf); the
  # key's own policy delegates access control to IAM (no explicit key policy is set), so this is
  # the statement that actually grants the app role the ability to decrypt them.
  statement {
    sid       = "UseEncryptionKey"
    effect    = "Allow"
    actions   = ["kms:Decrypt", "kms:GenerateDataKey", "kms:DescribeKey"]
    resources = [aws_kms_key.app.arn]
  }
}

resource "aws_iam_role_policy" "app_permissions" {
  name   = "${var.app_name}-app-permissions"
  role   = aws_iam_role.app.id
  policy = data.aws_iam_policy_document.app_permissions.json
}
