# webhook-haiku-4

- started: 2026-09-03T16:59Z
- model: haiku
- controls: local-delegate-mcp @ bd22a4b
- task: agent/fixtures/webhook-receiver-task.txt @ 4d80886

Freeze the controls for the duration. A defect found mid-run goes in
docs/candidate-rules.md, not into the code — changing a gate while a run is live
means the run measured two different gates.
