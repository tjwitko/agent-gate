# Webhook Receiver

A secure, immutable webhook receiver for payment provider event notifications built with Node.js, PostgreSQL, and AWS.

## Features

- **Signature Verification**: HMAC-SHA256 verification of incoming webhooks
- **Immutable Storage**: Once recorded, webhook contents cannot be modified
- **Secret Rotation**: Support for quarterly signing secret rotation
- **Idempotent Processing**: Duplicate events are safely deduplicated
- **Access Control**: Role-based access for support team lookups
- **Health Checks**: Load balancer health endpoint
- **Audit Trail**: Complete audit log of all webhook operations
- **7-Year Retention**: Automatic retention for compliance

## Architecture

```
Payment Provider
       ↓
   [HTTPS]
       ↓
  [ALB + TLS]
       ↓
  [Kubernetes Cluster]
       ├─ webhook-receiver (3 replicas)
       └─ [RDS Aurora PostgreSQL]
```

## Quick Start

### Prerequisites

- Node.js 20+
- npm or yarn
- Docker (for container builds)
- PostgreSQL 15+

### Development

```bash
# Install dependencies
npm install

# Build TypeScript
npm run build

# Run tests
npm test

# Start development server
npm run dev
```

### Environment Variables

```bash
DB_HOST=localhost
DB_PORT=5432
DB_NAME=webhook_receiver
DB_USER=postgres
DB_PASSWORD=postgres
PORT=3000
NODE_ENV=development
```

## API Endpoints

### POST /webhook

Receives webhook callbacks from the payment provider.

**Headers:**
- `X-Signature`: HMAC-SHA256 signature (hex-encoded)
- `X-Provider-ID`: Provider identifier
- `Content-Type: application/json`

**Request Body:**
```json
{
  "event_id": "evt_123456",
  "type": "payment.success",
  "amount": 10000,
  "currency": "USD",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

**Response:**
```json
{
  "id": "uuid-string",
  "status": "received",
  "message": "Webhook received and stored for processing"
}
```

### GET /health

Health check endpoint for load balancer.

**Response:**
```json
{
  "status": "healthy"
}
```

### GET /webhooks/:eventId

Retrieve a webhook by event ID (requires API key).

**Headers:**
- `X-API-Key`: Support team API key

**Response:**
```json
{
  "id": "uuid-string",
  "eventId": "evt_123456",
  "providerId": "stripe",
  "payload": "{...}",
  "signature": "abc123...",
  "receivedAt": "2024-01-15T10:30:00Z"
}
```

## Database Schema

### webhooks table
- `id` (UUID, PK): Unique webhook identifier
- `event_id` (VARCHAR): Provider's event ID
- `provider_id` (VARCHAR): Payment provider identifier
- `payload` (TEXT): Original webhook payload (immutable)
- `signature` (TEXT): HMAC signature
- `received_at` (TIMESTAMP): When webhook was received
- `created_at` (TIMESTAMP): When record was created

**Constraints:**
- UNIQUE(event_id, provider_id) - Prevents duplicates
- Immutability enforced at application and database level

### provider_secrets table
- `id` (SERIAL, PK): Primary key
- `provider_id` (VARCHAR): Payment provider identifier
- `secret_value` (TEXT): HMAC signing secret
- `created_at` (TIMESTAMP): When secret was created
- `rotates_at` (TIMESTAMP): When secret rotates
- `is_active` (BOOLEAN): Whether secret is active

### support_team_api_keys table
- `id` (SERIAL, PK): Primary key
- `key_hash` (VARCHAR): SHA-256 hash of API key
- `created_at` (TIMESTAMP): When key was created
- `revoked_at` (TIMESTAMP): When key was revoked (NULL if active)

## Signature Verification

Webhooks are signed using HMAC-SHA256:

```
HMAC-SHA256(secret, payload) = signature
```

The signature is transmitted in the `X-Signature` header as a hex-encoded string.

### Secret Rotation

During secret rotation:
1. New secret is added to `provider_secrets` with `is_active = true`
2. Old secret remains active for 24 hours
3. Both signatures are accepted during transition
4. Old secret is deactivated after transition period

## Kubernetes Deployment

### Prerequisites
- EKS cluster running
- kubectl configured

### Deploy

```bash
# Create namespace and apply configurations
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml

# Verify deployment
kubectl get pods -n payment-webhooks
kubectl get svc -n payment-webhooks
```

## Terraform Deployment

### Prerequisites
- AWS account configured
- Terraform 1.0+
- S3 bucket and DynamoDB table for state

### Deploy Infrastructure

```bash
cd terraform

# Initialize Terraform
terraform init

# Plan deployment
terraform plan -var-file=production.tfvars

# Apply deployment
terraform apply -var-file=production.tfvars
```

### Variables

Create `production.tfvars`:
```hcl
aws_region          = "us-east-1"
environment         = "production"
db_master_username  = "admin"
db_master_password  = "SecurePassword123!"
```

## Testing

The test suite covers:
- Valid signature acceptance
- Invalid signature rejection
- Tampered payload detection
- Secret rotation support
- Idempotent event storage
- Duplicate prevention
- Exact payload retention

```bash
npm test
npm test -- --coverage
```

## Security Considerations

### Immutability
- Webhook records are append-only
- No UPDATE or DELETE operations on webhooks
- Audit trail tracks all operations
- Database constraints enforce uniqueness

### Signature Verification
- HMAC-SHA256 with timing-safe comparison
- Protects against forgery and tampering
- Supports secret rotation for compliance

### Access Control
- Provider: Can only POST to /webhook endpoint
- Support Team: Can only GET webhooks with valid API key
- No cross-provider access
- All API keys hashed in database

### Data Protection
- TLS for all network communication
- Encryption at rest (RDS + KMS)
- Encryption in transit (TLS/HTTPS)
- Regular backups with 35-day retention
- Deletion protection on production database

## Monitoring

### CloudWatch Metrics
- Database CPU utilization (alert if > 80%)
- Database storage (alert if < 1 GB free)
- Application error rates
- Request latency

### Health Checks
- Kubernetes liveness probe: /health
- Kubernetes readiness probe: /health
- ALB health check: /health

## Incident Response

### Database Failure
1. RDS Multi-AZ failover automatic
2. Application automatically reconnects
3. No data loss due to backups

### Webhook Loss
- Not possible: immutable append-only design
- All received webhooks permanently stored

### Signature Verification Failure
- Webhook rejected with 401 Unauthorized
- Provider retried or contacted support

## Compliance

- **7-year retention**: RDS backup policy
- **Audit trail**: webhook_audit_log table
- **Immutability**: Database constraints
- **Encryption**: KMS + TLS
- **Access logs**: CloudWatch logs enabled

## Troubleshooting

### Database Connection Failed
```bash
# Check RDS security groups
aws ec2 describe-security-groups --region us-east-1

# Verify pod can reach RDS
kubectl exec -it webhook-receiver-xxx -- ping rds-endpoint
```

### Invalid Signature
1. Verify X-Signature header format (hex string)
2. Verify X-Provider-ID matches configured provider
3. Check provider secret is active
4. Verify payload is not tampered

### Out of Memory
- Increase container memory limits in k8s/deployment.yaml
- Review connection pooling settings
- Check for memory leaks in logs

## Contributing

Follow these practices:
- Write tests for new features
- Run tests before committing
- Use TypeScript strict mode
- Document security implications
- Run Terraform validation

## License

Internal use only.
