import { ClientError } from './errors.js';

/**
 * The single place that turns a thrown error into a response. A ClientError carries the status
 * the caller earned (a bad signature, a malformed body, a missing record) and is returned as-is.
 * Anything else is this service's own fault: it is logged in full for operators and answered with
 * a generic 500 that names nothing about the internal failure, so a datastore outage is reported
 * as what it is rather than dressed up as a rejected request.
 */
// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, _next) {
  if (err instanceof ClientError) {
    res.status(err.status).json({ error: err.message });
    return;
  }

  console.error(JSON.stringify({
    level: 'error',
    msg: 'unhandled fault',
    path: req.path,
    method: req.method,
    error: err && err.stack ? err.stack : String(err),
  }));
  res.status(500).json({ error: 'internal server error' });
}

export function notFoundHandler(req, res) {
  res.status(404).json({ error: 'not found' });
}
