import crypto from 'crypto';
import { testAcceptGenuineSignature, testRejectForgedSignature } from './signature-verification.test.js';
import { testRepeatedCallbackDoesNotOverwrite } from './duplicate-handling.test.js';

process.env.NODE_ENV = 'test';
process.env.PROVIDER_SECRET = 'test-secret-key';
process.env.ADMIN_TOKEN = 'test-admin-token';
process.env.DATABASE_URL = 'postgresql://user:password@localhost/test_db';

let passed = 0;
let failed = 0;
const failures = [];

function assert(condition, message) {
  if (!condition) {
    throw new Error(`Assertion failed: ${message}`);
  }
}

function assertEqual(actual, expected, message) {
  if (actual !== expected) {
    throw new Error(`Expected ${expected}, got ${actual}: ${message}`);
  }
}

function test(name, fn) {
  try {
    fn();
    console.log(`✓ ${name}`);
    passed++;
  } catch (error) {
    console.log(`✗ ${name}`);
    console.log(`  ${error.message}`);
    failed++;
    failures.push({ name, error });
  }
}

// Test Suite
console.log('\nWebhook Receiver Tests\n');

console.log('Signature Verification:');
test('accepts a genuine callback with valid signature', testAcceptGenuineSignature);
test('rejects a forged callback with invalid signature', testRejectForgedSignature);
test('should accept a valid signature', () => {
  const secret = 'test-secret-key';
  const payload = { event_id: 'evt_123', type: 'payment.completed' };
  const timestamp = '1234567890';
  const message = `${timestamp}.${JSON.stringify(payload)}`;
  const signature = crypto
    .createHmac('sha256', secret)
    .update(message)
    .digest('hex');

  const computed = crypto
    .createHmac('sha256', secret)
    .update(message)
    .digest('hex');

  assertEqual(signature, computed, 'signatures should match');
});

test('should reject a forged signature with wrong secret', () => {
  const secret = 'test-secret-key';
  const wrongSecret = 'wrong-secret';
  const payload = { event_id: 'evt_123', type: 'payment.completed' };
  const timestamp = '1234567890';
  const message = `${timestamp}.${JSON.stringify(payload)}`;

  const signature = crypto
    .createHmac('sha256', secret)
    .update(message)
    .digest('hex');

  const computed = crypto
    .createHmac('sha256', wrongSecret)
    .update(message)
    .digest('hex');

  assert(signature !== computed, 'signatures should not match');
});

test('should reject an invalid signature format', () => {
  const signature = 'not-a-valid-hex';
  assert(!signature.match(/^[a-f0-9]{64}$/), 'invalid hex should not match pattern');
});

console.log('\nDuplicate Event Handling:');
test('repeated callback does not overwrite what was already recorded', testRepeatedCallbackDoesNotOverwrite);
test('should use UNIQUE constraint on event_id to prevent duplicates', () => {
  const event1 = { event_id: 'evt_same', type: 'payment.completed' };
  const event2 = { event_id: 'evt_same', type: 'payment.completed' };
  assertEqual(event1.event_id, event2.event_id, 'event IDs should match');
});

console.log('\nAuthentication:');
test('should use timing-safe comparison for authorization tokens', () => {
  const validToken = 'test-token-123';
  const providedToken = 'test-token-123';

  let isAuthorized = false;
  try {
    isAuthorized = crypto.timingSafeEqual(
      Buffer.from(providedToken),
      Buffer.from(validToken)
    );
  } catch (e) {
    isAuthorized = false;
  }

  assert(isAuthorized === true, 'tokens should match');
});

test('should reject mismatched authorization tokens', () => {
  const validToken = 'test-token-123';
  const providedToken = 'wrong-token-456';

  let isAuthorized = false;
  try {
    isAuthorized = crypto.timingSafeEqual(
      Buffer.from(providedToken),
      Buffer.from(validToken)
    );
  } catch (e) {
    isAuthorized = false;
  }

  assert(isAuthorized === false, 'tokens should not match');
});

console.log('\nEnvironment Validation:');
test('should require PROVIDER_SECRET environment variable', () => {
  assert(process.env.PROVIDER_SECRET !== undefined, 'PROVIDER_SECRET should be set');
  assertEqual(process.env.PROVIDER_SECRET, 'test-secret-key', 'PROVIDER_SECRET should have correct value');
});

test('should require ADMIN_TOKEN environment variable', () => {
  assert(process.env.ADMIN_TOKEN !== undefined, 'ADMIN_TOKEN should be set');
  assertEqual(process.env.ADMIN_TOKEN, 'test-admin-token', 'ADMIN_TOKEN should have correct value');
});

console.log('\nRetention:');
test('should calculate 7-year retention period', () => {
  const now = new Date();
  const retentionUntil = new Date();
  retentionUntil.setFullYear(retentionUntil.getFullYear() + 7);

  assertEqual(
    retentionUntil.getFullYear(),
    now.getFullYear() + 7,
    'retention year should be 7 years ahead'
  );
});

console.log('\nHealth Endpoint:');
test('should return health status as JSON', () => {
  const healthResponse = { status: 'ok' };
  assert(healthResponse.hasOwnProperty('status'), 'health response should have status property');
  assertEqual(healthResponse.status, 'ok', 'health status should be ok');
});

console.log(`\n${passed} passing, ${failed} failing\n`);

if (failed > 0) {
  process.exit(1);
}
