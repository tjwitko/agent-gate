function required(name, value) {
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

export function loadConfig() {
  return {
    tableName: required('TABLE_NAME', process.env.TABLE_NAME),
    signingSecretId: required('SIGNING_SECRET_ID', process.env.SIGNING_SECRET_ID),
    supportTokenSecretId: required('SUPPORT_TOKEN_SECRET_ID', process.env.SUPPORT_TOKEN_SECRET_ID),
    port: Number(process.env.PORT) || 8080,
  };
}
