resource "aws_db_instance" "webhook_receiver" {
  identifier     = "webhook-receiver-${var.environment}"
  engine         = "postgres"
  engine_version = "15.3"
  instance_class = var.environment == "production" ? "db.t3.large" : "db.t3.micro"

  db_name  = var.db_name
  username = var.db_username
  password = var.db_password

  allocated_storage     = 100
  max_allocated_storage = 1000
  storage_type          = "gp3"
  storage_encrypted     = true

  db_subnet_group_name            = var.db_subnet_group_name
  vpc_security_group_ids          = [var.db_security_group_id]
  publicly_accessible             = false
  parameter_group_name            = aws_db_parameter_group.webhook_receiver.name
  option_group_name               = aws_db_option_group.webhook_receiver.name

  backup_retention_period = var.retention_days
  backup_window           = var.backup_window
  maintenance_window      = "sun:04:00-sun:05:00"
  copy_tags_to_snapshot   = true

  multi_az               = var.environment == "production" ? true : false
  deletion_protection    = true
  skip_final_snapshot    = var.environment != "production" ? true : false
  final_snapshot_identifier = var.environment == "production" ? "webhook-receiver-final-snapshot-${formatdate("YYYY-MM-DD-hhmm", timestamp())}" : null

  enabled_cloudwatch_logs_exports = ["postgresql"]

  lifecycle {
    prevent_destroy = true
  }

  tags = merge(var.tags, {
    Name = "webhook-receiver-db-${var.environment}"
  })
}

resource "aws_db_parameter_group" "webhook_receiver" {
  name_prefix = "webhook-receiver-"
  family      = "postgres15"
  description = "Parameter group for webhook receiver"

  parameter {
    name  = "max_connections"
    value = "100"
  }

  parameter {
    name  = "shared_preload_libraries"
    value = "pg_stat_statements"
  }

  tags = merge(var.tags, {
    Name = "webhook-receiver-pg-${var.environment}"
  })

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_db_option_group" "webhook_receiver" {
  name_prefix          = "webhook-receiver-"
  option_group_description = "Option group for webhook receiver"
  engine_name          = "postgres"
  major_engine_version = "15"

  tags = merge(var.tags, {
    Name = "webhook-receiver-og-${var.environment}"
  })

  lifecycle {
    create_before_destroy = true
  }
}

