import { Router } from 'express';

import { createRequireSupportAuth } from '../middleware/requireSupportAuth.js';
import { notFound } from '../errors.js';

/**
 * Lets the support team look up a past callback by the provider's event id. Only a caller holding
 * a valid support token reaches this handler at all — enforced by requireSupportAuth below.
 */
export function createCallbacksRouter({ store, secretsProvider, supportTokenSecretId }) {
  const router = Router();
  const requireSupportAuth = createRequireSupportAuth(secretsProvider, supportTokenSecretId);

  router.get('/callbacks/:eventId', requireSupportAuth, getCallback);

  async function getCallback(req, res, next) {
    try {
      const record = await store.getCallback(req.params.eventId);
      if (!record) {
        next(notFound('no callback recorded for that event id'));
        return;
      }
      res.status(200).json(record);
    } catch (err) {
      next(err);
    }
  }

  return router;
}
