resource "aws_dynamodb_table" "callbacks" {
  name         = "${var.project_name}-callbacks"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "event_id"

  attribute {
    name = "event_id"
    type = "S"
  }

  server_side_encryption {
    enabled     = true
    kms_key_arn = aws_kms_key.app.arn
  }

  # A 35-day restore window, not record retention. Kept in addition to, never instead of, the
  # actual retention guarantee below.
  point_in_time_recovery {
    enabled = true
  }

  # No TTL is configured on this table, deliberately. Records must be retained for seven years,
  # and a table with no expiry mechanism satisfies that outright: nothing here ever deletes a
  # record on its own. Do not add a ttl block without first computing an expiry at least seven
  # years out at write time.
  #
  # The other half of immutability -- nothing can change or remove a record once written -- is
  # enforced by the application's ConditionExpression on every write (src/store.js) together with
  # the IAM policy attached to the role that writes here, which grants PutItem and GetItem only
  # (terraform/iam.tf). Deleting this table itself is a Terraform-level operation, gated by
  # whatever restricts who can run terraform apply against this state -- not by anything this
  # resource block can express on its own.
  lifecycle {
    prevent_destroy = true
  }

  tags = local.tags
}
