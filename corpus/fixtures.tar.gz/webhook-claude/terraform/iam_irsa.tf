# IRSA (IAM Roles for Service Accounts) for the two application identities and for the AWS Load
# Balancer Controller. Each role's trust policy pins one specific Kubernetes ServiceAccount by
# namespace and name via the OIDC `sub` claim — the projected pod token only has to prove it comes
# from that ServiceAccount, so no long-lived AWS credential is ever handed to a pod.
#
# Trust policies are written inline with jsonencode rather than through a separate
# aws_iam_policy_document data source, deliberately: the Federated principal, the
# sts:AssumeRoleWithWebIdentity action and the pinned ServiceAccount subject all need to be
# readable directly in the aws_iam_role block that uses them, not indirected through a data
# source declared elsewhere in the file.
#
# Role names here (webhook-ingest-irsa-role, support-api-irsa-role) are literal strings, not built
# from variables, so they can be matched byte-for-byte against the eks.amazonaws.com/role-arn
# annotations in k8s/01-serviceaccounts.yaml without any interpolation to resolve. Keep the two in
# sync by hand if either changes.

locals {
  oidc_provider = replace(aws_iam_openid_connect_provider.eks.url, "https://", "")
}

# ---------------------------------------------------------------------------------------------
# webhook-ingest: write-only. Can PutItem into the audit log and read the provider's signing
# secret. Cannot update or delete a record, and cannot read the support API key.
# ---------------------------------------------------------------------------------------------

resource "aws_iam_role" "webhook_ingest" {
  name = "webhook-ingest-irsa-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRoleWithWebIdentity"
      Principal = { Federated = aws_iam_openid_connect_provider.eks.arn }
      Condition = {
        StringEquals = {
          "${local.oidc_provider}:sub" = "system:serviceaccount:webhook-receiver:webhook-ingest-sa"
          "${local.oidc_provider}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })
}

data "aws_iam_policy_document" "webhook_ingest_permissions" {
  statement {
    sid       = "WriteNewCallbacksOnly"
    effect    = "Allow"
    actions   = ["dynamodb:PutItem"]
    resources = [aws_dynamodb_table.callback_audit_log.arn]
  }
  statement {
    sid       = "ReadSigningSecret"
    effect    = "Allow"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.signing_secret.arn]
  }
  statement {
    sid       = "UseAppKmsKey"
    effect    = "Allow"
    actions   = ["kms:Decrypt", "kms:GenerateDataKey", "kms:DescribeKey"]
    resources = [aws_kms_key.app.arn]
  }
}

resource "aws_iam_role_policy" "webhook_ingest" {
  name   = "webhook-ingest-permissions"
  role   = aws_iam_role.webhook_ingest.id
  policy = data.aws_iam_policy_document.webhook_ingest_permissions.json
}

# ---------------------------------------------------------------------------------------------
# support-api: read-only. Can GetItem/Query the audit log and read the support API key. Cannot
# write, update or delete anything, and cannot read the provider's signing secret.
# ---------------------------------------------------------------------------------------------

resource "aws_iam_role" "support_api" {
  name = "support-api-irsa-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRoleWithWebIdentity"
      Principal = { Federated = aws_iam_openid_connect_provider.eks.arn }
      Condition = {
        StringEquals = {
          "${local.oidc_provider}:sub" = "system:serviceaccount:webhook-receiver:support-api-sa"
          "${local.oidc_provider}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })
}

data "aws_iam_policy_document" "support_api_permissions" {
  statement {
    sid       = "ReadCallbacksOnly"
    effect    = "Allow"
    actions   = ["dynamodb:GetItem", "dynamodb:Query"]
    resources = [aws_dynamodb_table.callback_audit_log.arn]
  }
  statement {
    sid       = "ReadSupportApiKey"
    effect    = "Allow"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.support_api_key.arn]
  }
  statement {
    sid       = "UseAppKmsKey"
    effect    = "Allow"
    actions   = ["kms:Decrypt", "kms:GenerateDataKey", "kms:DescribeKey"]
    resources = [aws_kms_key.app.arn]
  }
}

resource "aws_iam_role_policy" "support_api" {
  name   = "support-api-permissions"
  role   = aws_iam_role.support_api.id
  policy = data.aws_iam_policy_document.support_api_permissions.json
}

# ---------------------------------------------------------------------------------------------
# AWS Load Balancer Controller: cluster-wide add-on, installed via `helm install` as a bootstrap
# step (see README) rather than through Terraform's kubernetes/helm providers — configuring those
# providers from this same root's own not-yet-created cluster is the well-known EKS
# two-stage-apply problem, and splitting the controller install out avoids it entirely. This role
# and its policy (the upstream project's own published IAM policy, vendored at
# iam/aws-load-balancer-controller-policy.json) are provisioned here so the bootstrap step has
# something to reference.
# ---------------------------------------------------------------------------------------------

resource "aws_iam_role" "lb_controller" {
  name = "${var.project_name}-lb-controller-irsa-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRoleWithWebIdentity"
      Principal = { Federated = aws_iam_openid_connect_provider.eks.arn }
      Condition = {
        StringEquals = {
          "${local.oidc_provider}:sub" = "system:serviceaccount:kube-system:aws-load-balancer-controller"
          "${local.oidc_provider}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })
}

resource "aws_iam_policy" "lb_controller" {
  name   = "${var.project_name}-lb-controller-policy"
  policy = file("${path.module}/iam/aws-load-balancer-controller-policy.json")
}

resource "aws_iam_role_policy_attachment" "lb_controller" {
  role       = aws_iam_role.lb_controller.name
  policy_arn = aws_iam_policy.lb_controller.arn
}
