import crypto from 'crypto';
import { Database } from '../db/database';

export class SignatureVerifier {
  constructor(private db: Database) {}

  async verify(payload: string, signature: string, providerId: string): Promise<boolean> {
    // Get all active secrets for this provider (including recently rotated ones)
    const secrets = await this.db.getProviderSecrets(providerId);

    if (secrets.length === 0) {
      console.warn(`No secrets found for provider ${providerId}`);
      return false;
    }

    // Try to verify with any of the active secrets
    // This allows for graceful rotation - old secret still works during transition
    for (const secret of secrets) {
      if (this.verifySignature(payload, signature, secret.value)) {
        return true;
      }
    }

    return false;
  }

  private verifySignature(payload: string, signature: string, secret: string): boolean {
    const hmac = crypto.createHmac('sha256', secret);
    hmac.update(payload);
    const expectedSignature = hmac.digest('hex');

    // Constant-time comparison to prevent timing attacks
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );
  }
}
