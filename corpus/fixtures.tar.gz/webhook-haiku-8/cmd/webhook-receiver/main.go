package main

import (
	"context"
	"encoding/json"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"webhook-receiver/internal/middleware"
	"webhook-receiver/internal/signature"
	"webhook-receiver/internal/storage"
	"webhook-receiver/internal/webhook"
)

func main() {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Initialize signature verifier with secret rotation support
	verifier := signature.NewVerifier(
		os.Getenv("WEBHOOK_SECRET"),
		os.Getenv("WEBHOOK_SECRET_OLD"),
	)

	// Initialize storage backend (S3 for immutable records, DynamoDB for indexing)
	store, err := storage.New(ctx, os.Getenv("AWS_REGION"))
	if err != nil {
		log.Fatalf("failed to initialize storage: %v", err)
	}
	defer store.Close()

	// Create webhook handler
	handler := webhook.NewHandler(verifier, store)

	// Set up HTTP server
	mux := http.NewServeMux()

	// Health check endpoint
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
	})

	// Webhook receive endpoint
	mux.HandleFunc("/webhook", middleware.LogRequest(handler.ReceiveWebhook))

	// Support team lookup endpoint (requires auth)
	mux.HandleFunc("/api/webhooks/lookup", middleware.Authenticate(middleware.LogRequest(handler.LookupWebhook)))

	server := &http.Server{
		Addr:         ":8080",
		Handler:      mux,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	// Start server in goroutine
	go func() {
		log.Printf("Server starting on %s", server.Addr)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("server error: %v", err)
		}
	}()

	// Graceful shutdown
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	<-sigChan

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	log.Println("Shutting down server...")
	if err := server.Shutdown(shutdownCtx); err != nil {
		log.Fatalf("shutdown error: %v", err)
	}
}
