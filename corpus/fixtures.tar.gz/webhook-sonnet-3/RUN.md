# webhook-sonnet-3

- started: 2026-09-02T20:22Z
- model: sonnet
- controls: local-delegate-mcp @ 12c1f3c
- task: agent/fixtures/webhook-receiver-task.txt @ 4d80886

Freeze the controls for the duration. A defect found mid-run goes in
docs/candidate-rules.md, not into the code — changing a gate while a run is live
means the run measured two different gates.
