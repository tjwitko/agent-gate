variable "aws_region" {
  description = "Single AWS region this stack deploys into."
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Base name applied to every resource this stack creates."
  type        = string
  default     = "webhook-receiver"
}

variable "environment" {
  type    = string
  default = "production"
}

variable "vpc_cidr" {
  type    = string
  default = "10.42.0.0/16"
}

variable "eks_api_public_cidrs" {
  description = <<-EOT
    CIDR ranges allowed to reach the EKS public API endpoint (CI runners, office/VPN egress).
    Never set this to 0.0.0.0/0 -- the private endpoint (always enabled) is how nodes and pods in
    the VPC reach the API; the public endpoint exists only for operator/CI access from outside it.
  EOT
  type        = list(string)
}

variable "node_instance_types" {
  type    = list(string)
  default = ["t3.medium"]
}

variable "node_desired_size" {
  type    = number
  default = 2
}

variable "node_min_size" {
  type    = number
  default = 2
}

variable "node_max_size" {
  type    = number
  default = 4
}

locals {
  tags = {
    Project     = var.project_name
    Environment = var.environment
    ManagedBy   = "terraform"
  }
}
