# Webhook Receiver

A secure, immutable webhook receiver for payment provider event notifications.

## Architecture

The service is built with:
- **Node.js + Express**: HTTP server
- **HMAC-SHA256**: Webhook signature verification
- **DynamoDB**: Immutable event storage
- **AWS Fargate**: Container orchestration
- **Kubernetes**: Optional alternative deployment
- **Terraform**: Infrastructure as code

## Features

- ✅ HMAC-SHA256 signature verification
- ✅ Immutable event storage
- ✅ Support secret rotation
- ✅ Duplicate detection
- ✅ Health check endpoint
- ✅ Event lookup by provider event ID
- ✅ 7-year retention with DynamoDB TTL
- ✅ CloudWatch logging and monitoring

## Development

### Prerequisites
- Node.js 20+
- npm

### Setup

```bash
npm install
npm run build
npm run dev
```

### Testing

```bash
npm test          # Watch mode
npm run test:run  # Single run
```

## API Endpoints

### POST /webhook
Accepts webhook callbacks from the payment provider.

**Headers:**
- `x-event-id`: Provider's unique event ID
- `x-timestamp`: Event timestamp
- `x-signature`: HMAC-SHA256 signature

**Body:** Event payload (JSON)

**Response:**
- 202: Successfully recorded
- 400: Missing headers
- 401: Invalid signature
- 409: Duplicate event ID

### GET /health
Health check for load balancer.

**Response:**
- 200: Service healthy

### GET /callbacks/:eventId
Retrieve a recorded callback (support team only).

**Response:**
- 200: Callback found
- 404: Callback not found

## Signature Format

The provider computes the signature as:

```
HMAC-SHA256(SECRET, eventId.timestamp.JSON(body))
```

## Secret Rotation

The service supports quarterly secret rotation without downtime:

1. **During Rotation**: Set `WEBHOOK_ROTATION_SECRETS` environment variable to comma-separated list of previous secrets
   ```
   WEBHOOK_SECRET=<new-secret>
   WEBHOOK_ROTATION_SECRETS=<old-secret-1>,<old-secret-2>
   ```

2. **Provider Updates**: The provider starts signing with the new secret

3. **Validation**: The service accepts both old and new secrets during the transition period

4. **Complete**: Once all provider requests use the new secret, remove old secrets from `WEBHOOK_ROTATION_SECRETS`

This allows safe rotation without requiring the service to be offline.

## Deployment

### AWS with Terraform

```bash
cd terraform
terraform init
terraform apply \
  -var="container_image=<ECR_URI>" \
  -var="webhook_secret=<SECRET>"
```

### Kubernetes

```bash
# Update secret
kubectl apply -f k8s/secret.yaml

# Deploy service
kubectl apply -f k8s/rbac.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
kubectl apply -f k8s/ingress.yaml
kubectl apply -f k8s/hpa.yaml
```

## Building Docker Image

```bash
docker build -t webhook-receiver:latest .
```

## Security Considerations

- Signatures are verified using timing-safe comparison
- Callbacks are immutable once stored
- DynamoDB encryption at rest
- Support access is controlled at the API gateway level
- Secrets are managed via AWS Secrets Manager (Terraform) or Kubernetes Secrets
- Containers run as non-root users
- Read-only root filesystem in Kubernetes

## Monitoring

- CloudWatch logs in `/ecs/webhook-receiver`
- Container Insights enabled on ECS cluster
- Auto-scaling based on CPU (70%) and memory (80%)
- Health checks every 30 seconds
