package main

import (
	"bytes"
	"crypto/hmac"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib"
)

func setupTestDB(t *testing.T) *sql.DB {
	// Use TEST_DATABASE_URL environment variable for testing
	connStr := os.Getenv("TEST_DATABASE_URL")
	if connStr == "" {
		t.Skip("TEST_DATABASE_URL environment variable not set, skipping database tests")
	}
	db, err := sql.Open("pgx", connStr)
	if err != nil {
		t.Skipf("Could not connect to test database: %v", err)
	}

	if err := db.Ping(); err != nil {
		t.Skipf("Test database not available: %v", err)
	}

	// Clean up old test data
	db.Exec("TRUNCATE webhooks")

	_, err = db.Exec(`
		CREATE TABLE IF NOT EXISTS webhooks (
			event_id TEXT PRIMARY KEY,
			received_at TIMESTAMP NOT NULL,
			original_body TEXT NOT NULL
		)
	`)
	if err != nil {
		t.Fatalf("Failed to create test table: %v", err)
	}

	return db
}

func createSignature(body []byte, secret string) string {
	h := hmac.New(sha256.New, []byte(secret))
	h.Write(body)
	return hex.EncodeToString(h.Sum(nil))
}

func TestVerifySignature(t *testing.T) {
	secret := "test-secret-key"
	body := []byte(`{"event_id":"evt_123","amount":1000}`)

	signature := createSignature(body, secret)

	if !verifySignature(body, signature, secret) {
		t.Error("Expected signature verification to pass for valid signature")
	}

	forgedSig := "invalidsignature"
	if verifySignature(body, forgedSig, secret) {
		t.Error("Expected signature verification to fail for forged signature")
	}

	differentSecret := "different-secret"
	wrongSig := createSignature(body, differentSecret)
	if verifySignature(body, wrongSig, secret) {
		t.Error("Expected signature verification to fail for signature with wrong secret")
	}
}

func TestWebhookAcceptValid(t *testing.T) {
	db := setupTestDB(t)
	defer db.Close()

	wr := &WebhookReceiver{db: db}

	secret := "test-secret"
	eventID := "evt_" + fmt.Sprintf("%d", time.Now().UnixNano())
	payload := []byte(`{"event_id":"` + eventID + `","amount":1000}`)
	signature := createSignature(payload, secret)

	req := httptest.NewRequest(http.MethodPost, "/webhook", bytes.NewReader(payload))
	req.Header.Set("X-Webhook-Signature", signature)

	t.Setenv("WEBHOOK_SECRET", secret)

	w := httptest.NewRecorder()
	wr.handleWebhook(w, req)

	if w.Code != http.StatusAccepted {
		t.Errorf("Expected status %d, got %d", http.StatusAccepted, w.Code)
	}

	var resp map[string]string
	if err := json.NewDecoder(w.Body).Decode(&resp); err != nil {
		t.Fatalf("Failed to decode response: %v", err)
	}

	if resp["status"] != "accepted" {
		t.Errorf("Expected status 'accepted', got '%s'", resp["status"])
	}

	// Verify event was stored
	var stored WebhookEvent
	err := db.QueryRow(
		"SELECT event_id, original_body FROM webhooks WHERE event_id = $1",
		eventID,
	).Scan(&stored.EventID, &stored.OriginalBody)

	if err != nil {
		t.Fatalf("Failed to find stored event: %v", err)
	}

	if stored.EventID != eventID {
		t.Errorf("Expected event_id %s, got %s", eventID, stored.EventID)
	}

	if stored.OriginalBody != string(payload) {
		t.Errorf("Expected body to be preserved exactly")
	}
}

func TestWebhookRejectForged(t *testing.T) {
	db := setupTestDB(t)
	defer db.Close()

	wr := &WebhookReceiver{db: db}

	secret := "test-secret"
	payload := []byte(`{"event_id":"evt_123","amount":1000}`)
	forgedSignature := "invalidsignature"

	req := httptest.NewRequest(http.MethodPost, "/webhook", bytes.NewReader(payload))
	req.Header.Set("X-Webhook-Signature", forgedSignature)

	t.Setenv("WEBHOOK_SECRET", secret)

	w := httptest.NewRecorder()
	wr.handleWebhook(w, req)

	if w.Code != http.StatusUnauthorized {
		t.Errorf("Expected status %d, got %d", http.StatusUnauthorized, w.Code)
	}

	var resp ErrorResponse
	if err := json.NewDecoder(w.Body).Decode(&resp); err != nil {
		t.Fatalf("Failed to decode response: %v", err)
	}

	if resp.ErrorType != "client_error" {
		t.Errorf("Expected error_type 'client_error', got '%s'", resp.ErrorType)
	}
}

func TestRepeatedCallbackNotOverwritten(t *testing.T) {
	db := setupTestDB(t)
	defer db.Close()

	wr := &WebhookReceiver{db: db}

	secret := "test-secret"
	eventID := "evt_repeated"
	payload1 := []byte(`{"event_id":"` + eventID + `","amount":1000,"timestamp":"2026-09-03T10:00:00Z"}`)
	signature1 := createSignature(payload1, secret)

	t.Setenv("WEBHOOK_SECRET", secret)

	// First submission
	req1 := httptest.NewRequest(http.MethodPost, "/webhook", bytes.NewReader(payload1))
	req1.Header.Set("X-Webhook-Signature", signature1)
	w1 := httptest.NewRecorder()
	wr.handleWebhook(w1, req1)

	if w1.Code != http.StatusAccepted {
		t.Fatalf("First submission failed with status %d", w1.Code)
	}

	// Get first stored version
	var stored1 WebhookEvent
	err := db.QueryRow(
		"SELECT event_id, original_body, received_at FROM webhooks WHERE event_id = $1",
		eventID,
	).Scan(&stored1.EventID, &stored1.OriginalBody, &stored1.ReceivedAt)

	if err != nil {
		t.Fatalf("Failed to find first stored event: %v", err)
	}

	firstReceivedAt := stored1.ReceivedAt

	time.Sleep(100 * time.Millisecond)

	// Second submission with different content
	payload2 := []byte(`{"event_id":"` + eventID + `","amount":2000,"timestamp":"2026-09-03T10:00:10Z"}`)
	signature2 := createSignature(payload2, secret)

	req2 := httptest.NewRequest(http.MethodPost, "/webhook", bytes.NewReader(payload2))
	req2.Header.Set("X-Webhook-Signature", signature2)
	w2 := httptest.NewRecorder()
	wr.handleWebhook(w2, req2)

	if w2.Code != http.StatusAccepted {
		t.Fatalf("Second submission failed with status %d", w2.Code)
	}

	// Verify original content is unchanged
	var stored2 WebhookEvent
	err = db.QueryRow(
		"SELECT event_id, original_body, received_at FROM webhooks WHERE event_id = $1",
		eventID,
	).Scan(&stored2.EventID, &stored2.OriginalBody, &stored2.ReceivedAt)

	if err != nil {
		t.Fatalf("Failed to find second stored event: %v", err)
	}

	if stored2.OriginalBody != stored1.OriginalBody {
		t.Errorf("Original body was overwritten. Expected '%s', got '%s'", stored1.OriginalBody, stored2.OriginalBody)
	}

	if !stored2.ReceivedAt.Equal(firstReceivedAt) {
		t.Errorf("Received timestamp changed. Expected '%v', got '%v'", firstReceivedAt, stored2.ReceivedAt)
	}
}

func TestMissingSignature(t *testing.T) {
	db := setupTestDB(t)
	defer db.Close()

	wr := &WebhookReceiver{db: db}

	payload := []byte(`{"event_id":"evt_123","amount":1000}`)

	req := httptest.NewRequest(http.MethodPost, "/webhook", bytes.NewReader(payload))
	// Intentionally not setting signature header

	w := httptest.NewRecorder()
	wr.handleWebhook(w, req)

	if w.Code != http.StatusUnauthorized {
		t.Errorf("Expected status %d, got %d", http.StatusUnauthorized, w.Code)
	}

	var resp ErrorResponse
	if err := json.NewDecoder(w.Body).Decode(&resp); err != nil {
		t.Fatalf("Failed to decode response: %v", err)
	}

	if resp.ErrorType != "client_error" {
		t.Errorf("Expected error_type 'client_error', got '%s'", resp.ErrorType)
	}
}

func TestHealthEndpoint(t *testing.T) {
	db := setupTestDB(t)
	defer db.Close()

	wr := &WebhookReceiver{db: db}

	req := httptest.NewRequest(http.MethodGet, "/health", nil)
	w := httptest.NewRecorder()
	wr.handleHealth(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("Expected status %d, got %d", http.StatusOK, w.Code)
	}

	var resp HealthResponse
	if err := json.NewDecoder(w.Body).Decode(&resp); err != nil {
		t.Fatalf("Failed to decode response: %v", err)
	}

	if resp.Status != "healthy" {
		t.Errorf("Expected status 'healthy', got '%s'", resp.Status)
	}
}

func TestErrorDistinction(t *testing.T) {
	db := setupTestDB(t)
	defer db.Close()

	wr := &WebhookReceiver{db: db}

	tests := []struct {
		name          string
		setup         func(*http.Request)
		expectedCode  int
		expectedType  string
		description   string
	}{
		{
			name: "invalid json",
			setup: func(req *http.Request) {
				req.Body = nil
				secret := "test-secret"
				body := []byte("invalid json")
				req.Header.Set("X-Webhook-Signature", createSignature(body, secret))
				t.Setenv("WEBHOOK_SECRET", secret)
			},
			expectedCode: http.StatusBadRequest,
			expectedType: "client_error",
			description:  "Bad request from provider",
		},
		{
			name: "missing event_id",
			setup: func(req *http.Request) {
				secret := "test-secret"
				body := []byte(`{"amount":1000}`)
				req.Body = bytes.NewReader(body)
				req.Header.Set("X-Webhook-Signature", createSignature(body, secret))
				t.Setenv("WEBHOOK_SECRET", secret)
			},
			expectedCode: http.StatusBadRequest,
			expectedType: "client_error",
			description:  "Bad request from provider",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req := httptest.NewRequest(http.MethodPost, "/webhook", nil)
			tt.setup(req)
			w := httptest.NewRecorder()
			wr.handleWebhook(w, req)

			if w.Code != tt.expectedCode {
				t.Errorf("Expected status %d, got %d", tt.expectedCode, w.Code)
			}

			var resp ErrorResponse
			if err := json.NewDecoder(w.Body).Decode(&resp); err != nil {
				t.Fatalf("Failed to decode response: %v", err)
			}

			if resp.ErrorType != tt.expectedType {
				t.Errorf("Expected error_type '%s', got '%s'", tt.expectedType, resp.ErrorType)
			}
		})
	}
}

func TestLookupRequiresAuthentication(t *testing.T) {
	db := setupTestDB(t)
	defer db.Close()

	wr := &WebhookReceiver{db: db}

	t.Run("missing authorization header", func(t *testing.T) {
		req := httptest.NewRequest(http.MethodGet, "/lookup?event_id=evt_123", nil)
		w := httptest.NewRecorder()
		wr.handleLookup(w, req)

		if w.Code != http.StatusUnauthorized {
			t.Errorf("Expected status %d, got %d", http.StatusUnauthorized, w.Code)
		}

		var resp ErrorResponse
		if err := json.NewDecoder(w.Body).Decode(&resp); err != nil {
			t.Fatalf("Failed to decode response: %v", err)
		}

		if resp.ErrorType != "client_error" {
			t.Errorf("Expected error_type 'client_error', got '%s'", resp.ErrorType)
		}
	})

	t.Run("invalid authorization token", func(t *testing.T) {
		t.Setenv("SUPPORT_TOKEN", "valid-token")
		req := httptest.NewRequest(http.MethodGet, "/lookup?event_id=evt_123", nil)
		req.Header.Set("Authorization", "Bearer invalid-token")
		w := httptest.NewRecorder()
		wr.handleLookup(w, req)

		if w.Code != http.StatusUnauthorized {
			t.Errorf("Expected status %d, got %d", http.StatusUnauthorized, w.Code)
		}
	})

	t.Run("valid authorization token", func(t *testing.T) {
		token := "valid-test-token"
		t.Setenv("SUPPORT_TOKEN", token)

		// First store an event
		event := WebhookEvent{
			EventID:     "evt_auth_test",
			ReceivedAt:  time.Now().UTC(),
			OriginalBody: `{"event_id":"evt_auth_test","amount":1000}`,
		}
		err := wr.storeEvent(event)
		if err != nil {
			t.Fatalf("Failed to store test event: %v", err)
		}

		req := httptest.NewRequest(http.MethodGet, "/lookup?event_id=evt_auth_test", nil)
		req.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		wr.handleLookup(w, req)

		if w.Code != http.StatusOK {
			t.Errorf("Expected status %d, got %d", http.StatusOK, w.Code)
		}

		var resp WebhookEvent
		if err := json.NewDecoder(w.Body).Decode(&resp); err != nil {
			t.Fatalf("Failed to decode response: %v", err)
		}

		if resp.EventID != "evt_auth_test" {
			t.Errorf("Expected event_id 'evt_auth_test', got '%s'", resp.EventID)
		}
	})
}
