# webhook-claude

A webhook receiver for a payment provider's event notifications: verifies each callback's HMAC
signature, records it exactly once in an append-only store, and lets support look up a past
callback by the provider's event id.

## Architecture

Two separate services share one codebase and one container image, each with its own IAM identity
and its own network exposure — a deliberate split, not an accident of factoring:

- **webhook-ingest** (`src/webhook-ingest-server.mjs`) — the only thing the provider talks to.
  Verifies the HMAC-SHA256 signature on `POST /webhooks/payment-provider` against the current (and,
  during a rotation grace window, the just-retired) signing secret, then writes the callback to
  DynamoDB with `ConditionExpression: attribute_not_exists(event_id)` — a retried or replayed
  delivery cannot overwrite what is already stored. Its IAM role can `PutItem` and nothing else.
- **support-api** (`src/support-api-server.mjs`) — the only thing the support team talks to.
  `GET /support/callbacks/:eventId` requires a support API key, checked with a constant-time
  comparison. Its IAM role can `GetItem`/`Query` and nothing else — it cannot write, so even a
  fully compromised copy of this service cannot alter or remove a record.

Both expose `GET /healthz` for the load balancer, unauthenticated by convention.

Immutability is enforced twice, deliberately redundant: the application's own conditional write,
and the fact that no IAM policy anywhere in `terraform/` grants `UpdateItem`, `DeleteItem` or
`BatchWriteItem` on the table — so there is no credential in the running system that could change
or remove a record even if application code tried to.

Secrets (the provider's signing secret, the support API key) are never read from Kubernetes
Secrets or environment variables — only from AWS Secrets Manager via IRSA, cached with a TTL well
under the provider's quarterly rotation cadence, with a refresh-and-retry on verification failure
so a just-rotated secret does not cause real traffic to be rejected for a whole cache lifetime.

## Repository layout

```
src/            application code (two entry points, shared lib/)
test/           automated tests — node:test, no live AWS account needed
Dockerfile      one image, two entry points selected by k8s command:
k8s/            Kubernetes manifests for both services
terraform/      all AWS infrastructure (VPC, EKS, IAM/IRSA, DynamoDB, Secrets Manager, ECR, KMS)
```

## Running the tests

```sh
npm install
npm test
```

Covers, among other things: a genuine signature is accepted, a forged one is rejected, a
repeated delivery of the same event id does not overwrite the first record, a malformed request
is answered with 4xx while an infrastructure fault is answered with 5xx (and never leaks fault
detail to the caller), and a callback signed with the secret from just before a rotation is still
accepted.

## Deploying

1. **Terraform.** From `terraform/`:
   ```sh
   terraform init
   terraform apply -var="aws_account_id=<your account id>" -var="aws_region=<your region>"
   ```
   `aws_account_id` has no default and is not looked up live (no `aws_caller_identity` data
   source) — this keeps `terraform plan` schema/security-scannable without real AWS credentials,
   e.g. in CI.

2. **Populate the provider's signing secret** (Terraform declares the secret but not its value,
   since the value has to match the provider's own and Terraform does not control their rotation
   schedule):
   ```sh
   aws secretsmanager put-secret-value \
     --secret-id webhook-receiver/provider-signing-secret \
     --secret-string '<value the provider gave you>'
   ```
   Every later quarterly rotation is another `put-secret-value` call — Secrets Manager
   automatically keeps the version being replaced as `AWSPREVIOUS`, which is the grace-window
   secret `src/lib/signingSecretSource.mjs` also accepts.

3. **Install the AWS Load Balancer Controller** (a cluster-wide add-on, installed once per
   cluster rather than through Terraform's kubernetes/helm providers — see the comment in
   `terraform/iam_irsa.tf` for why). The API server is private-only, so this and the next step run
   from inside the VPC (a CI runner with VPC connectivity, a bastion, or SSM Session Manager
   port-forwarding):
   ```sh
   helm repo add eks https://aws.github.io/eks-charts && helm repo update
   helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
     -n kube-system \
     --set clusterName="$(terraform output -raw eks_cluster_name)" \
     --set serviceAccount.create=true \
     --set serviceAccount.annotations."eks\.amazonaws\.com/role-arn"="$(terraform output -raw lb_controller_role_arn)"
   ```

4. **Build and push the image**, then apply the Kubernetes manifests. Both the image reference
   (`k8s/02-webhook-ingest-deployment.yaml`, `k8s/04-support-api-deployment.yaml`) and the IRSA
   role ARNs (`k8s/01-serviceaccounts.yaml`) carry a placeholder AWS account id
   (`111111111111`) — substitute the real one (e.g. `kustomize edit set image`, or a CI-time
   `sed`) before applying. They are literal, well-formed placeholders rather than `${...}`
   expressions on purpose: Kubernetes never expands that syntax, so a template marker left in
   place would reach the cluster as a literal string and silently break IRSA.
   ```sh
   docker build -t "$(terraform output -raw ecr_repository_url):$(git rev-parse --short HEAD)" .
   docker push "$(terraform output -raw ecr_repository_url):$(git rev-parse --short HEAD)"
   kubectl apply -f k8s/
   ```
   `k8s/03-webhook-ingest-service.yaml` also carries a placeholder ACM certificate ARN — issue a
   real certificate for the provider-facing hostname and substitute it there before applying.

## Retention

The DynamoDB table has no TTL configured and deletion protection enabled, so records are kept
indefinitely by default — satisfying the seven-year retention requirement without a mechanism
that could also delete records early. Point-in-time recovery is enabled as a second line of
defense against operator error, not as a substitute for the table's own conditional-write
immutability.
