package storage

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/aws/aws-sdk-go-v2/service/s3"
)

var ErrAlreadyExists = errors.New("webhook already exists")

type Record struct {
	EventID    string
	Type       string
	RawPayload []byte
	ReceivedAt time.Time
}

type Store struct {
	s3Client       *s3.Client
	dynamodbClient *dynamodb.Client
	s3Bucket       string
	dynamodbTable  string
}

func New(ctx context.Context, region string) (*Store, error) {
	cfg, err := config.LoadDefaultConfig(ctx, config.WithRegion(region))
	if err != nil {
		return nil, fmt.Errorf("unable to load SDK config: %w", err)
	}

	return &Store{
		s3Client:       s3.NewFromConfig(cfg),
		dynamodbClient: dynamodb.NewFromConfig(cfg),
		s3Bucket:       "webhook-payloads",
		dynamodbTable:  "webhook-index",
	}, nil
}

// StoreWebhook stores a webhook record immutably in S3 and indexes it in DynamoDB.
// Returns error if record already exists (prevents overwriting).
func (s *Store) StoreWebhook(ctx context.Context, record *Record) error {
	// Check if event already exists
	existing, err := s.GetWebhook(ctx, record.EventID)
	if err != nil {
		return fmt.Errorf("failed to check existing record: %w", err)
	}
	if existing != nil {
		// Record already exists - do not overwrite (immutability)
		return ErrAlreadyExists
	}

	// Generate unique S3 key with timestamp for uniqueness
	s3Key := fmt.Sprintf("webhooks/%s/%d-%s", record.Type, time.Now().UnixNano(), record.EventID)

	// Store raw payload in S3 with object lock (retention handled by bucket policy)
	_, err = s.s3Client.PutObject(ctx, &s3.PutObjectInput{
		Bucket:      aws.String(s.s3Bucket),
		Key:         aws.String(s3Key),
		Body:        bytes.NewReader(record.RawPayload),
		ContentType: aws.String("application/json"),
	})
	if err != nil {
		return fmt.Errorf("failed to store in S3: %w", err)
	}

	// Index in DynamoDB for quick lookup
	_, err = s.dynamodbClient.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(s.dynamodbTable),
		Item: map[string]types.AttributeValue{
			"event_id":    &types.AttributeValueMemberS{Value: record.EventID},
			"s3_key":      &types.AttributeValueMemberS{Value: s3Key},
			"received_at": &types.AttributeValueMemberN{Value: fmt.Sprintf("%d", record.ReceivedAt.Unix())},
			"event_type":  &types.AttributeValueMemberS{Value: record.Type},
		},
		ConditionExpression: aws.String("attribute_not_exists(event_id)"),
	})
	if err != nil {
		return fmt.Errorf("failed to index in DynamoDB: %w", err)
	}

	return nil
}

// GetWebhook retrieves a webhook record by event ID.
// Returns nil if not found.
func (s *Store) GetWebhook(ctx context.Context, eventID string) (*Record, error) {
	// Query DynamoDB for the index entry
	result, err := s.dynamodbClient.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(s.dynamodbTable),
		Key: map[string]types.AttributeValue{
			"event_id": &types.AttributeValueMemberS{Value: eventID},
		},
	})
	if err != nil {
		return nil, fmt.Errorf("failed to query DynamoDB: %w", err)
	}

	if result.Item == nil {
		return nil, nil
	}

	// Extract S3 key from index
	s3KeyAttr, ok := result.Item["s3_key"].(*types.AttributeValueMemberS)
	if !ok {
		return nil, fmt.Errorf("invalid s3_key in index")
	}

	receivedAtAttr, ok := result.Item["received_at"].(*types.AttributeValueMemberN)
	if !ok {
		return nil, fmt.Errorf("invalid received_at in index")
	}

	eventTypeAttr, ok := result.Item["event_type"].(*types.AttributeValueMemberS)
	if !ok {
		return nil, fmt.Errorf("invalid event_type in index")
	}

	// Retrieve payload from S3
	s3Result, err := s.s3Client.GetObject(ctx, &s3.GetObjectInput{
		Bucket: aws.String(s.s3Bucket),
		Key:    aws.String(s3KeyAttr.Value),
	})
	if err != nil {
		return nil, fmt.Errorf("failed to retrieve from S3: %w", err)
	}
	defer s3Result.Body.Close()

	body, err := io.ReadAll(s3Result.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read S3 body: %w", err)
	}

	var unixTime int64
	_, err = fmt.Sscanf(receivedAtAttr.Value, "%d", &unixTime)
	if err != nil {
		return nil, fmt.Errorf("invalid timestamp: %w", err)
	}

	return &Record{
		EventID:    eventID,
		Type:       eventTypeAttr.Value,
		RawPayload: body,
		ReceivedAt: time.Unix(unixTime, 0).UTC(),
	}, nil
}

func (s *Store) Close() error {
	return nil
}
