# webhook-haiku-12

- started: 2026-09-07T19:11Z
- model: haiku
- task: agent/fixtures/webhook-receiver-task.txt @ 4d80886

## Controls
- local-delegate-mcp: 03677a9
- terraform-guard-mcp: 8cea08e
- dep-audit-mcp: b6c6327
- secret-guard-mcp: 35f85ea
- identity-guard-mcp: cb0caa6

Freeze the controls for the duration. A defect found mid-run goes in
docs/candidate-rules.md, not into the code — changing a gate while a run is live
means the run measured two different gates.
