import assert from "node:assert/strict";
import { test } from "node:test";
import { computeSignature, verifySignature } from "../src/lib/signature.js";

const SECRET = "test-signing-secret";
const BODY = Buffer.from(JSON.stringify({ id: "evt_1", type: "payment.succeeded" }));

test("accepts a callback signed with a genuine secret", () => {
  const header = `sha256=${computeSignature(SECRET, BODY)}`;
  assert.equal(verifySignature([SECRET], BODY, header), true);
});

test("rejects a callback signed with the wrong secret", () => {
  const header = `sha256=${computeSignature("wrong-secret", BODY)}`;
  assert.equal(verifySignature([SECRET], BODY, header), false);
});

test("rejects a forged signature of the right shape", () => {
  const forged = "sha256=" + "a".repeat(64);
  assert.equal(verifySignature([SECRET], BODY, forged), false);
});

test("rejects a signature computed over a tampered body", () => {
  const header = `sha256=${computeSignature(SECRET, BODY)}`;
  const tamperedBody = Buffer.from(JSON.stringify({ id: "evt_1", type: "payment.refunded" }));
  assert.equal(verifySignature([SECRET], tamperedBody, header), false);
});

test("rejects a missing signature header", () => {
  assert.equal(verifySignature([SECRET], BODY, undefined), false);
});

test("rejects a malformed signature header", () => {
  assert.equal(verifySignature([SECRET], BODY, "not-a-signature"), false);
});

test("accepts the previous secret during a rotation window", () => {
  const oldSecret = "old-secret";
  const newSecret = "new-secret";
  const header = `sha256=${computeSignature(oldSecret, BODY)}`;
  // Signing secrets are checked in [current, previous] order -- a callback signed just before
  // rotation completed must still verify.
  assert.equal(verifySignature([newSecret, oldSecret], BODY, header), true);
});

test("rejects a secret that has fully retired", () => {
  const retiredSecret = "retired-secret";
  const currentSecret = "current-secret";
  const header = `sha256=${computeSignature(retiredSecret, BODY)}`;
  assert.equal(verifySignature([currentSecret], BODY, header), false);
});
