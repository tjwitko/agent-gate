output "eks_cluster_name" {
  value = aws_eks_cluster.this.name
}

output "eks_cluster_endpoint" {
  value = aws_eks_cluster.this.endpoint
}

output "oidc_provider_arn" {
  value = aws_iam_openid_connect_provider.eks.arn
}

output "webhook_ingest_role_arn" {
  description = "Must match the eks.amazonaws.com/role-arn annotation on the webhook-ingest-sa ServiceAccount."
  value       = aws_iam_role.webhook_ingest.arn
}

output "support_api_role_arn" {
  description = "Must match the eks.amazonaws.com/role-arn annotation on the support-api-sa ServiceAccount."
  value       = aws_iam_role.support_api.arn
}

output "lb_controller_role_arn" {
  description = "Pass to `helm install aws-load-balancer-controller` as serviceAccount.annotations."
  value       = aws_iam_role.lb_controller.arn
}

output "dynamodb_table_name" {
  value = aws_dynamodb_table.callback_audit_log.name
}

output "ecr_repository_url" {
  value = aws_ecr_repository.app.repository_url
}

output "signing_secret_arn" {
  value = aws_secretsmanager_secret.signing_secret.arn
}

output "support_api_key_secret_arn" {
  value = aws_secretsmanager_secret.support_api_key.arn
}
