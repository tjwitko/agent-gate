package webhook

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"webhook-receiver/internal/signature"
	"webhook-receiver/internal/storage"
)

// MockStore implements storage.Store interface for testing
type MockStore struct {
	records map[string]*storage.Record
}

func NewMockStore() *MockStore {
	return &MockStore{
		records: make(map[string]*storage.Record),
	}
}

func (m *MockStore) StoreWebhook(ctx context.Context, record *storage.Record) error {
	if _, exists := m.records[record.EventID]; exists {
		return storage.ErrAlreadyExists
	}
	m.records[record.EventID] = record
	return nil
}

func (m *MockStore) GetWebhook(ctx context.Context, eventID string) (*storage.Record, error) {
	return m.records[eventID], nil
}

func (m *MockStore) Close() error {
	return nil
}

func createSignature(body []byte, secret string) string {
	h := hmac.New(sha256.New, []byte(secret))
	h.Write(body)
	return hex.EncodeToString(h.Sum(nil))
}

func TestReceiveWebhookValidSignature(t *testing.T) {
	secret := "webhook-secret"
	store := NewMockStore()
	handler := NewHandler(signature.NewVerifier(secret, ""), store)

	payload := map[string]interface{}{
		"event_id":  "evt_123",
		"type":      "payment.completed",
		"timestamp": time.Now().Unix(),
		"data": map[string]string{
			"amount":      "100.00",
			"currency":    "USD",
			"customer_id": "cust_456",
		},
	}

	body, _ := json.Marshal(payload)
	signature := createSignature(body, secret)

	req := httptest.NewRequest("POST", "/webhook", bytes.NewReader(body))
	req.Header.Set("X-Webhook-Signature", signature)
	req.Header.Set("Content-Type", "application/json")

	w := httptest.NewRecorder()
	handler.ReceiveWebhook(w, req)

	if w.Code != http.StatusAccepted {
		t.Errorf("expected status 202, got %d", w.Code)
	}

	if _, exists := store.records["evt_123"]; !exists {
		t.Error("webhook not stored")
	}
}

func TestReceiveWebhookInvalidSignature(t *testing.T) {
	secret := "webhook-secret"
	store := NewMockStore()
	handler := NewHandler(signature.NewVerifier(secret, ""), store)

	payload := map[string]interface{}{
		"event_id": "evt_123",
		"type":     "payment.completed",
	}

	body, _ := json.Marshal(payload)

	req := httptest.NewRequest("POST", "/webhook", bytes.NewReader(body))
	req.Header.Set("X-Webhook-Signature", "invalid-signature")

	w := httptest.NewRecorder()
	handler.ReceiveWebhook(w, req)

	if w.Code != http.StatusUnauthorized {
		t.Errorf("expected status 401, got %d", w.Code)
	}

	var resp ErrorResponse
	json.NewDecoder(w.Body).Decode(&resp)
	if resp.Code != "invalid_signature" {
		t.Errorf("expected code 'invalid_signature', got %s", resp.Code)
	}
}

func TestReceiveWebhookDuplicate(t *testing.T) {
	secret := "webhook-secret"
	store := NewMockStore()
	handler := NewHandler(signature.NewVerifier(secret, ""), store)

	payload := map[string]interface{}{
		"event_id": "evt_123",
		"type":     "payment.completed",
	}

	body, _ := json.Marshal(payload)
	signature := createSignature(body, secret)

	// First request
	req1 := httptest.NewRequest("POST", "/webhook", bytes.NewReader(body))
	req1.Header.Set("X-Webhook-Signature", signature)
	w1 := httptest.NewRecorder()
	handler.ReceiveWebhook(w1, req1)

	if w1.Code != http.StatusAccepted {
		t.Fatalf("first request failed: %d", w1.Code)
	}

	// Second request with same event
	req2 := httptest.NewRequest("POST", "/webhook", bytes.NewReader(body))
	req2.Header.Set("X-Webhook-Signature", signature)
	w2 := httptest.NewRecorder()
	handler.ReceiveWebhook(w2, req2)

	if w2.Code != http.StatusInternalServerError {
		t.Errorf("expected status 500 for duplicate, got %d", w2.Code)
	}

	var resp ErrorResponse
	json.NewDecoder(w2.Body).Decode(&resp)
	if resp.Code != "storage_error" {
		t.Errorf("expected code 'storage_error', got %s", resp.Code)
	}
}

func TestReceiveWebhookMissingEventID(t *testing.T) {
	secret := "webhook-secret"
	store := NewMockStore()
	handler := NewHandler(signature.NewVerifier(secret, ""), store)

	payload := map[string]interface{}{
		"type": "payment.completed",
	}

	body, _ := json.Marshal(payload)
	signature := createSignature(body, secret)

	req := httptest.NewRequest("POST", "/webhook", bytes.NewReader(body))
	req.Header.Set("X-Webhook-Signature", signature)

	w := httptest.NewRecorder()
	handler.ReceiveWebhook(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("expected status 400, got %d", w.Code)
	}

	var resp ErrorResponse
	json.NewDecoder(w.Body).Decode(&resp)
	if resp.Code != "missing_event_id" {
		t.Errorf("expected code 'missing_event_id', got %s", resp.Code)
	}
}

func TestReceiveWebhookMethodNotAllowed(t *testing.T) {
	store := NewMockStore()
	handler := NewHandler(signature.NewVerifier("secret", ""), store)

	req := httptest.NewRequest("GET", "/webhook", nil)
	w := httptest.NewRecorder()
	handler.ReceiveWebhook(w, req)

	if w.Code != http.StatusMethodNotAllowed {
		t.Errorf("expected status 405, got %d", w.Code)
	}
}

func TestLookupWebhookFound(t *testing.T) {
	store := NewMockStore()
	handler := NewHandler(signature.NewVerifier("secret", ""), store)

	now := time.Now().UTC()
	payload := []byte(`{"event_id":"evt_123","type":"payment.completed"}`)
	store.records["evt_123"] = &storage.Record{
		EventID:    "evt_123",
		Type:       "payment.completed",
		RawPayload: payload,
		ReceivedAt: now,
	}

	req := httptest.NewRequest("POST", "/api/webhooks/lookup",
		bytes.NewReader([]byte(`{"event_id":"evt_123"}`)))
	w := httptest.NewRecorder()
	handler.LookupWebhook(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected status 200, got %d", w.Code)
	}

	var resp SuccessResponse
	json.NewDecoder(w.Body).Decode(&resp)
	if resp.EventID != "evt_123" {
		t.Errorf("expected event_id evt_123, got %s", resp.EventID)
	}
}

func TestLookupWebhookNotFound(t *testing.T) {
	store := NewMockStore()
	handler := NewHandler(signature.NewVerifier("secret", ""), store)

	req := httptest.NewRequest("POST", "/api/webhooks/lookup",
		bytes.NewReader([]byte(`{"event_id":"nonexistent"}`)))
	w := httptest.NewRecorder()
	handler.LookupWebhook(w, req)

	if w.Code != http.StatusNotFound {
		t.Errorf("expected status 404, got %d", w.Code)
	}

	var resp ErrorResponse
	json.NewDecoder(w.Body).Decode(&resp)
	if resp.Code != "not_found" {
		t.Errorf("expected code 'not_found', got %s", resp.Code)
	}
}
